

#' This is some description of this function.
#' @title to design primers for qRT-PCR.
#'
#' @description By using this package, you could use function of primer.designing.pipeline.for.SNP.and.indel.markers to design primers for qRT-PCR.
#'
#' @details see above
#'
#'#' @param geneName: gene name alone or gene list file, which including two columns, namely, Gene.ID and Type. Type indicates the CDS, promoter, mRNA, gene, five_prime_UTR, three_prime_UTR or all (all types)
#' @param seqEvaluation: seqEvaluation folder.
#' @param gffFile: general feature format of certain genome, it must contain at least Gene.ID, Chr, Start, End, Strand, Type.
#' @param plotting: logical value indicates whether to plot primers or not.
#' @param type: string to indicate whihch type of sequence to be extracted, e.g. mRNA, CDS, gene, five_prime_UTR, and three_prime_UTR. 
#' @param database: folder or file contains genome sequence in fasta format
#' @param geneName: string to specify the name of a SNP or Indel, when input file was missed, 'lociName' is reuquired.
#' @param chr: string or numeric value indicates specific chromosome, when input file was missed, 'chr' is reuquired.
#' @param start: numeric value indicates the start position of Indel, when input file was missed, 'start' is reuquired.
#' @param end: numeric value indicates the end position of Indel, when input file was missed, 'end' is reuquired.
#' @param pos: numeric value indicates the position of SNP, when input file was missed, 'pos' is reuquired.
#' @param leftFlanking: numeric value indicates left flanking region of SNP or Indel, default value is 200bp.
#' @param rightFlanking: numeric value indicates right flanking region of SNP or Indel, default value is 200bp.
#' @param inputFile: parameter setting file in '.csv' or '.xlsx' format. it should contains Type	Name	Chr	Start	End	Strand	Primer_strand	Flanking.left.bp	Flanking.right.bp	Expected.amplicon.length.bp	Aiming	Primer.name	Primer.length.bp	Tm.expected	GC.content	Sequence.specificity.min, details could be found in example input file.
#' @param database: folder contains genome sequence in fasta format
#' @param stepWise: numeric value to indicate stepWise of windows, default value is 3.
#' @param windowSize: numeric value to indicate scope of window size, could be a single number, e.g. 23, or a range, e.g. c(20,25). Default value is c(20, 25)
#' @param blastDir: the path to the local blast.
#' @param promoterLength: numeric value indicate the length of promoter sequence to extract, default is 2000.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param specificityMin: numeric value to indicate the min value of sequence specificity to signify on the diagnostic plot.
#' @param nthreads: numeric value to indicate how many threads used in the analysis, default is 2
#' @param Evalue: numeric value to indicate e-value threshold in local-blast, default is 0.1 (1e-1)
#' @param outFormat: numeric value to specify -outfmt parameter in local blast, default is 6.
#' @param GCShow: logical value. whether to show GC content on the diagnostic plot, default is TRUE
#' @param TmShow: logical value.whether to show Tm value on the diagnostic plot, default is TRUE
#' @param specificiyShow: logical value.whether to show sequence specificity value on the diagnostic plot, default is TRUE
#' @param countShow: logical value.whether to show Counts on the diagnostic plot, default is TRUE
#' @param countMax: numeric value to indicates the maximum counts threshold, by which fragment to be displayed with dashed line.
#' @param segmentLinetype: numeric value indicates which line type to be used. It is inherited from basic line types in the R.
#' @param segmentColor: string indicate the color of geom_segment(), which represent fragment sequence on the chromosome in terms of location.
#' @param segmentSize: numeric value indicates line size of geom_segment(), default value is 0.2
#' @param pointShape: numeric value indicates point shape in geom_point(), default value for pointShape1 and pointShape2 are 19 and 24 respectively.
#' @param pointColor: string indicates color of geom_point(), default value for pointColor1 and pointColor2 are 'red' and 'blue' respectively.
#' @param pointSize: numeric value indicates point size in geom_point(), default value for pointSize, pointSize1, and pointSize2 are 0.5, 0.5, and 0.5 respectively.
#' @param hlineType: numeric value indicates line type in geom_hline(), default value is 2.
#' @param hlineColor: string indicates line color in geom_hline(), default value is 'blue'
#' @param hlineSize: numeric value indicates line size, default value is 0.3.
#' @param pdfWidth: numeric value indicates width of pdf file, default value is 16.
#' @param pdfHeight: numeric value indicates height of pdf file, default value is 10.
#' @param seqEvaluation: seqEvaluation folder.
#' @param plotting: logical value indicates whether to plot primers or not.
#' @param TmScope: numeric scope indicates the min and max of primer Tm, default value is 'c(40, 60)'.
#' @param GCScope: numeric scope indicates the min and max of primer GC content (%), default value is 'c(35, 65)'.
#' @param specificityMin: numeric value indicates the minimum standard of sequence specificity (%), default value is 98%.
#' @param countMax: numeric value indicates the maximum standard of counts of this primer mathched to different position on the chromosome, default value is 2.
#' @param endMatch: logical value indicates whether the primer end (3') matched to genome, default value is TRUE
#' @param GCend: logical value indicates whether the primer end (3') should be G:C or not, default value is TRUE
#' @param lengthScope: numeric scope indicates the expected min and max amplicon length of primer pairs, default value is 'c(70, 150)'.
#' @param primerLength: numeric scope indicates the min and max length of primer, default value is 'c(20, 25)'.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param primerStrand: 'F' or 'R', or c('F', 'R')
#' @param Fcolor: color value for forward primers, default is "#B2182B".
#' @param Rcolor: color value for reverse primers, default is "#2166AC".
#' @param lcolor: color value for line connecting forward and reverse primer pairs, default is 'black'.
#' @param overlapMin: numeric value indicates at least how many base pairs should be acrossing different exons, to eliminate none specific matching to genome DNA. Default is 5bp.
#' @return files and folder
#' @export primer.designing.pipeline.for.qRT.PCR
#' @examples primer.designing.pipeline.for.qRT.PCR(database = "./soybean.genome/", geneName = "Glyma.01G010100", gffFile = "./Wm82.a2.v1.gene.gff", type = "gene", blastDir = "./ncbi-blast-2.12.0+/", For = "Cloning")
#' 
#' 

# promoterLength = NULL; leftFlanking = NULL; rightFlanking = NULL; For = NULL; inputFile = NULL;  windowSize = NULL; stepWise = NULL; TmMethod = NULL; specificityMin = NULL; nthreads = NULL; Evalue = NULL; GCShow = NULL; TmShow = NULL; specificiyShow = NULL; countShow = NULL; TmScope = NULL; GCScope = NULL; countMax = NULL; segmentLinetype = NULL; segmentColor = NULL; segmentSize = NULL; pointShape1 = NULL; pointShape2 = NULL; pointColor1 = NULL; pointColor2 = NULL; pointSize = NULL; pointSize1 = NULL; pointSize2 = NULL; hlineType = NULL; hlineColor = NULL; hlineSize = NULL; pdfWidth = NULL; pdfHeight = NULL; outFormat = NULL; seqEvaluation = NULL; plotting = NULL;  endMatch = NULL; GCend = NULL; primerLength = NULL; primerStrand = NULL; Fcolor = NULL; Rcolor = NULL; lcolor = NULL; leftRegion = NULL; rightRegion = NULL; lengthScope = NULL; overlapMin = NULL

#primer.designing.pipeline.for.qRT.PCR(database = "./soybean.genome/", geneName = "./gene.list.csv", gffFile = "./Wm82.a2.v1.gene.gff", blastDir = "./ncbi-blast-2.12.0+/", For = "qRT-PCR")

primer.designing.pipeline.for.qRT.PCR = function(database = NULL, geneName = NULL, type = NULL, blastDir = NULL, gffFile = NULL, seqType = NULL, promoterLength = NULL, leftFlanking = NULL, rightFlanking = NULL, For = NULL,inputFile = NULL,  windowSize = NULL, stepWise = NULL, TmMethod = NULL, specificityMin = NULL, nthreads = NULL, Evalue = NULL, GCShow = NULL, TmShow = NULL, specificiyShow = NULL, countShow = NULL, TmScope = NULL, GCScope = NULL, countMax = NULL, segmentLinetype = NULL, segmentColor = NULL, segmentSize = NULL, pointShape1 = NULL, pointShape2 = NULL, pointColor1 = NULL, pointColor2 = NULL, pointSize = NULL, pointSize1 = NULL, pointSize2 = NULL, hlineType = NULL, hlineColor = NULL, hlineSize = NULL, pdfWidth = NULL, pdfHeight = NULL, outFormat = NULL, seqEvaluation = NULL, plotting = NULL,  endMatch = NULL, GCend = NULL, primerLength = NULL, primerStrand = NULL, Fcolor = NULL, Rcolor = NULL, lcolor = NULL, leftRegion = NULL, rightRegion = NULL, lengthScope = NULL, overlapMin = NULL, ...){
  
  library(data.table)
  
  if(is.null(For)) For = "qRT-PCR"
  if(is.null(seqType)) seqType = "Gene"
  if(is.null(type)) type = "mRNA"
  
  ## sequence extraction
  if(!is.null(geneName)){
    gene.seq.extraction(database = database, geneName = geneName, gffFile = gffFile, type = type, promoterLength = promoterLength, leftFlanking = leftFlanking, rightFlanking = rightFlanking, For = For)
  }
  
  ## sequence evaluation
  if(is.null(inputFile)){
    if(seqType == "gene" | seqType == "Gene" | seqType == "GENE"){
      if(!file.exists(geneName)){
        dirList = list.files("./Sequence.extraction/Gene/")
        dirList = paste0("./Sequence.extraction/Gene/", dirList)
        dirList = dirList[grep(geneName, dirList)]
        for(i in 1:length(dirList)){
          dirName = strsplit(dirList[i], "/")[[1]][length(strsplit(dirList[i], "/")[[1]])]
          inputFile = paste0(dirList[i], "/")
          if(dir.exists(inputFile)){
            seq.evaluation(database = database, seqType = seqType, inputFile = inputFile, blastDir = blastDir, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
            cat(paste0("\nSequence evaluation of ", dirName, " is DONE!\n"))
            seqEvaluation = paste0("./Sequence.evaluation/Gene/", dirName, "/")
            if(file.exists(seqEvaluation)){
              primer.designing.for.qRT.PCR(seqEvaluation = seqEvaluation, gffFile = gffFile, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend = GCend, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, overlapMin = overlapMin, lengthScope = lengthScope)
              cat(paste0("\nPrimer designing of ", dirName, " for qRT-PCR is DONE!\n"))
            }else{
              warning(paste0("\n", dirName, " does not exist in ./Sequence.evaluation/Gene/\n"))
              next
            }
          }else{
            warning(paste0("\n", dirName, " does not exist in ./Sequence.extraction/Gene/\n"))
            next
          }
        }
      }
      if(file.exists(geneName)){
        if(length(grep(".csv|.txt", geneName)) == 1){
          geneList = fread(file = geneName, header = T, sep = "\t", stringsAsFactors = F, fill = T)
          if(ncol(geneList) == 1){
            geneList = fread(file = geneName, header = T, sep = ",", stringsAsFactors = F, fill = T)
            if(ncol(geneList) == 1){
              geneList = fread(file = geneName, header = T, sep = " ", stringsAsFactors = F, fill = T)
            }
          } 
        }
        if(length(grep(".xlsx", geneName)) == 1){
          geneList = data.frame(read.xlsx(paste0(dir.path, "/", geneName), header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
        }
        dirList = list.files("./Sequence.extraction/Gene/")
        dirList = paste0("./Sequence.extraction/Gene/", dirList)
        # i = 3; j = 1
        for(i in 1:nrow(geneList)){
          dir = dirList[grep(geneList$Gene.ID[i], dirList)]
          if(length(grep("^promoterLength$", names(geneList))) == 1 & !is.na(geneList$promoterLength[i]))  promoterLength = geneList$promoterLength[i]
          if(length(grep("^leftFlanking$", names(geneList))) == 1 & !is.na(geneList$leftFlanking[i]))  leftFlanking = geneList$leftFlanking[i]
          if(length(grep("^rightFlanking$", names(geneList))) == 1 & !is.na(geneList$rightFlanking[i]))  rightFlanking = geneList$rightFlanking[i]
          if(length(grep("^windowSize$", names(geneList))) == 1 & !is.na(geneList$windowSize[i]))  windowSize = geneList$windowSize[i]
          if(length(grep("^stepWise$", names(geneList))) == 1 & !is.na(geneList$stepWise[i]))  stepWise = geneList$stepWise[i]
          if(length(grep("^TmMethod$", names(geneList))) == 1 & !is.na(geneList$TmMethod[i]))  TmMethod = geneList$TmMethod[i]
          if(length(grep("^specificityMin$", names(geneList))) == 1 & !is.na(geneList$specificityMin[i]))  specificityMin = geneList$specificityMin[i]
          if(length(grep("^nthreads$", names(geneList))) == 1 & !is.na(geneList$nthreads[i]))  nthreads = geneList$nthreads[i]
          if(length(grep("^Evalue$", names(geneList))) == 1 & !is.na(geneList$Evalue[i]))  Evalue = geneList$Evalue[i]
          if(length(grep("^GCShow$", names(geneList))) == 1 & !is.na(geneList$GCShow[i]))  GCShow = geneList$GCShow[i]
          if(length(grep("^TmShow$", names(geneList))) == 1 & !is.na(geneList$TmShow[i]))  TmShow = geneList$TmShow[i]
          if(length(grep("^specificiyShow$", names(geneList))) == 1 & !is.na(geneList$specificiyShow[i]))  specificiyShow = geneList$specificiyShow[i]
          if(length(grep("^countShow$", names(geneList))) == 1 & !is.na(geneList$countShow[i]))  countShow = geneList$countShow[i]
          if(length(grep("^TmScope$", names(geneList))) == 1 & !is.na(geneList$TmScope[i]))  TmScope = geneList$TmScope[i]
          if(length(grep("^GCScope$", names(geneList))) == 1 & !is.na(geneList$GCScope[i]))  GCScope = geneList$GCScope[i]
          if(length(grep("^countMax$", names(geneList))) == 1 & !is.na(geneList$countMax[i]))  countMax = geneList$countMax[i]
          if(length(grep("^segmentLinetype$", names(geneList))) == 1 & !is.na(geneList$segmentLinetype[i]))  segmentLinetype = geneList$segmentLinetype[i]
          if(length(grep("^segmentColor$", names(geneList))) == 1 & !is.na(geneList$segmentColor[i]))  segmentColor = geneList$segmentColor[i]
          if(length(grep("^segmentSize$", names(geneList))) == 1 & !is.na(geneList$segmentSize[i]))  segmentSize = geneList$segmentSize[i]
          if(length(grep("^pointShape1$", names(geneList))) == 1 & !is.na(geneList$pointShape1[i]))  pointShape1 = geneList$pointShape1[i]
          if(length(grep("^pointShape2$", names(geneList))) == 1 & !is.na(geneList$pointShape2[i]))  pointShape2 = geneList$pointShape2[i]
          if(length(grep("^pointColor1$", names(geneList))) == 1 & !is.na(geneList$pointColor1[i]))  pointColor1 = geneList$pointColor1[i]
          if(length(grep("^pointColor2$", names(geneList))) == 1 & !is.na(geneList$pointColor2[i]))  pointColor2 = geneList$pointColor2[i]
          if(length(grep("^pointSize$", names(geneList))) == 1 & !is.na(geneList$pointSize[i]))  pointSize = geneList$pointSize[i]
          if(length(grep("^pointSize1$", names(geneList))) == 1 & !is.na(geneList$pointSize1[i]))  pointSize1 = geneList$pointSize1[i]
          if(length(grep("^pointSize2$", names(geneList))) == 1 & !is.na(geneList$pointSize2[i]))  pointSize2 = geneList$pointSize2[i]
          if(length(grep("^hlineType$", names(geneList))) == 1 & !is.na(geneList$hlineType[i]))  hlineType = geneList$hlineType[i]
          if(length(grep("^hlineColor$", names(geneList))) == 1 & !is.na(geneList$hlineColor[i]))  hlineColor = geneList$hlineColor[i]
          if(length(grep("^hlineSize$", names(geneList))) == 1 & !is.na(geneList$hlineSize[i]))  hlineSize = geneList$hlineSize[i]
          if(length(grep("^pdfWidth$", names(geneList))) == 1 & !is.na(geneList$pdfWidth[i]))  pdfWidth = geneList$pdfWidth[i]
          if(length(grep("^pdfHeight$", names(geneList))) == 1 & !is.na(geneList$pdfHeight[i]))  pdfHeight = geneList$pdfHeight[i]
          if(length(grep("^outFormat$", names(geneList))) == 1 & !is.na(geneList$outFormat[i]))  outFormat = geneList$outFormat[i]
          if(length(grep("^plotting$", names(geneList))) == 1 & !is.na(geneList$plotting[i]))  plotting = geneList$plotting[i]
          if(length(grep("^endMatch$", names(geneList))) == 1 & !is.na(geneList$endMatch[i]))  endMatch = geneList$endMatch[i]
          if(length(grep("^GCend$", names(geneList))) == 1 & !is.na(geneList$GCend[i]))  type = geneList$GCend[i]
          if(length(grep("^primerLength$", names(geneList))) == 1 & !is.na(geneList$primerLength[i]))  primerLength = geneList$primerLength[i]
          if(length(grep("^primerStrand$", names(geneList))) == 1 & !is.na(geneList$primerStrand[i]))  primerStrand = geneList$primerStrand[i]
          if(length(grep("^Fcolor$", names(geneList))) == 1 & !is.na(geneList$Fcolor[i]))  Fcolor = geneList$Fcolor[i]
          if(length(grep("^Rcolor$", names(geneList))) == 1 & !is.na(geneList$Rcolor[i]))  Rcolor = geneList$Rcolor[i]
          if(length(grep("^lcolor$", names(geneList))) == 1 & !is.na(geneList$lcolor[i]))  lcolor = geneList$lcolor[i]
          if(length(grep("^leftRegion$", names(geneList))) == 1 & !is.na(geneList$leftRegion[i]))  leftRegion = geneList$leftRegion[i]
          if(length(grep("^rightRegion$", names(geneList))) == 1 & !is.na(geneList$rightRegion[i]))  rightRegion = geneList$rightRegion[i]
          
          if(length(dir) != 0){
            for(j in 1:length(dir)){
              dirName = strsplit(dir[j], "/")[[1]][length(strsplit(dir[j], "/")[[1]])]
              inputFile = paste0(dir[j], "/")
              if(file.exists(inputFile)){
                seq.evaluation(database = database, seqType = seqType, inputFile = inputFile, blastDir = blastDir, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
                cat(paste0("\nSequence evaluation of ", dirName, " is DONE!\n"))
                seqEvaluation = paste0("./Sequence.evaluation/Gene/", dirName, "/")
                if(file.exists(seqEvaluation)){
                  primer.designing.for.qRT.PCR(seqEvaluation = seqEvaluation, gffFile = gffFile, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend = GCend, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, overlapMin = overlapMin, lengthScope = lengthScope)
                  cat(paste0("\nPrimer designing of ", dirName, " for qRT-PCR is DONE!\n"))
                }else{
                  warning(paste0("\n", dirName, " does not exist in ./Sequence.evaluation/Gene/\n"))
                  next
                }
              }else{
                warning(paste0("\n", dirName, " does not exist in ./Sequence.extraction/Gene/\n"))
                next
              }
            }
          }else{
            warning(paste0("\n", dirName, " does not exist!\n"))
            next
          }
        }
      }
    }else{warning("\nOnly gene could be used to design qRT-PCR primers!\n")}
  }
  cat(paste0("\nPrimer designing of ", geneName, " is/are ALL DONE!\n")) 
}












