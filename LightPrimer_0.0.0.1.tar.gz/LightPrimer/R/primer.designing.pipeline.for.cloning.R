

#' This is some description of this function.
#' @title to design primers for gene and fragment cloning.
#'
#' @description By using this package, you could use function of primer.designing.pipeline.for.cloning to design primers for gene and fragment cloning.
#'
#' @details see above


#' @param seqType: string to indicate type of sequence, which could one of 'Gene', "fragment'.
#' @param fragmentName: fragment name
#' @param fragmentFile: fragment file, including at least 'Fragment.ID', 'Chr', 'Start', 'End', 'Strand', 'Length', 'leftFlanking', 'rightFlanking', of which 'Fragment.ID', 'Chr', 'Start' and 'End' are required to be specified. The program would assign default value of '+', 'end - start', 200, and 200 for 'Strand', 'Length', 'leftFlanking', and 'rightFlanking' respectively. This file could be in format of *.csv, .txt, .xlsx, if .xlsx format was used parameters should be put in 'Sheet1' as default.
#' @param geneName: gene name alone or gene list file, which including two columns, namely, Gene.ID and Type. Type indicates the CDS, promoter, mRNA, gene, five_prime_UTR, three_prime_UTR or all (all types)
#' @param type: string to indiate SNP or Indel, varied format is also accepted, e.g. snp, SNP, indel, Indel, and INDEL
#' @param database: folder or file contains genome sequence in fasta format
#' @param lociName: string to specify the name of a SNP or Indel, when input file was missed, 'lociName' is reuquired.
#' @param chr: string or numeric value indicates specific chromosome, when input file was missed, 'chr' is reuquired.
#' @param start: numeric value indicates the start position of Indel, when input file was missed, 'start' is reuquired.
#' @param end: numeric value indicates the end position of Indel, when input file was missed, 'end' is reuquired.
#' @param pos: numeric value indicates the position of SNP, when input file was missed, 'pos' is reuquired.
#' @param leftFlanking: numeric value indicates left flanking region of SNP or Indel, default value is 200bp.
#' @param rightFlanking: numeric value indicates right flanking region of SNP or Indel, default value is 200bp.
#' @param inputFile: parameter setting file in '.csv' or '.xlsx' format. it should contains Type	Name	Chr	Start	End	Strand	Primer_strand	Flanking.left.bp	Flanking.right.bp	Expected.amplicon.length.bp	Aiming	Primer.name	Primer.length.bp	Tm.expected	GC.content	Sequence.specificity.min, details could be found in example input file.
#' @param database: folder contains genome sequence in fasta format
#' @param stepWise: numeric value to indicate stepWise of windows, default value is 3.
#' @param windowSize: numeric value to indicate scope of window size, could be a single number, e.g. 23, or a range, e.g. c(20,25). Default value is c(20, 25)
#' @param blastDir: the path to the local blast.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param specificityMin: numeric value to indicate the min value of sequence specificity to signify on the diagnostic plot.
#' @param nthreads: numeric value to indicate how many threads used in the analysis, default is 2
#' @param Evalue: numeric value to indicate e-value threshold in local-blast, default is 0.1 (1e-1)
#' @param outFormat: numeric value to specify -outfmt parameter in local blast, default is 6.
#' @param GCShow: logical value. whether to show GC content on the diagnostic plot, default is TRUE
#' @param TmShow: logical value.whether to show Tm value on the diagnostic plot, default is TRUE
#' @param specificiyShow: logical value.whether to show sequence specificity value on the diagnostic plot, default is TRUE
#' @param countShow: logical value.whether to show Counts on the diagnostic plot, default is TRUE
#' @param countMax: numeric value to indicates the maximum counts threshold, by which fragment to be displayed with dashed line.
#' @param segmentLinetype: numeric value indicates which line type to be used. It is inherited from basic line types in the R.
#' @param segmentColor: string indicate the color of geom_segment(), which represent fragment sequence on the chromosome in terms of location.
#' @param segmentSize: numeric value indicates line size of geom_segment(), default value is 0.2
#' @param pointShape: numeric value indicates point shape in geom_point(), default value for pointShape1 and pointShape2 are 19 and 24 respectively.
#' @param pointColor: string indicates color of geom_point(), default value for pointColor1 and pointColor2 are 'red' and 'blue' respectively.
#' @param pointSize: numeric value indicates point size in geom_point(), default value for pointSize, pointSize1, and pointSize2 are 0.5, 0.5, and 0.5 respectively.
#' @param hlineType: numeric value indicates line type in geom_hline(), default value is 2.
#' @param hlineColor: string indicates line color in geom_hline(), default value is 'blue'
#' @param hlineSize: numeric value indicates line size, default value is 0.3.
#' @param pdfWidth: numeric value indicates width of pdf file, default value is 16.
#' @param pdfHeight: numeric value indicates height of pdf file, default value is 10.
#' @param seqEvaluation: seqEvaluation folder.
#' @param plotting: logical value indicates whether to plot primers or not.
#' @param TmScope: numeric scope indicates the min and max of primer Tm, default value is 'c(40, 60)'.
#' @param GCScope: numeric scope indicates the min and max of primer GC content (%), default value is 'c(35, 65)'.
#' @param specificityMin: numeric value indicates the minimum standard of sequence specificity (%), default value is 98%.
#' @param countMax: numeric value indicates the maximum standard of counts of this primer mathched to different position on the chromosome, default value is 2.
#' @param endMatch: logical value indicates whether the primer end (3') matched to genome, default value is TRUE
#' @param GCend: logical value indicates whether the primer end (3') should be G:C or not, default value is TRUE
#' @param primerLength: numeric scope indicates the min and max length of primer, default value is 'c(20, 25)'.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param primerStrand: 'F' or 'R', or c('F', 'R')
#' @param Fcolor: color value for forward primers, default is "#B2182B".
#' @param Rcolor: color value for reverse primers, default is "#2166AC".
#' @param lcolor: color value for line connecting forward and reverse primer pairs, default is 'black'.
#' @param leftRegion: the position scope for left primer.
#' @param rightRegion: the position scope for right primer.
#' @return files and folder
#' @export primer.designing.pipeline.for.cloning
#' @examples primer.designing.pipeline.for.cloning(database = "./soybean.genome/", geneName = "Glyma.01G010100", gffFile = "./Wm82.a2.v1.gene.gff", type = "gene", blastDir = "./ncbi-blast-2.12.0+/", For = "Cloning")
#' 
#' 

# primer.designing.pipeline.for.cloning(database = "./soybean.genome/", geneName = "Glyma.01G010200", gffFile = "./Wm82.a2.v1.gene.gff", seqType = "Gene", type = "gene", blastDir = "./ncbi-blast-2.12.0+/", For = "Cloning")

primer.designing.pipeline.for.cloning = function(database = NULL, geneName = NULL, blastDir = NULL, seqType = NULL, gffFile = NULL, type = NULL, promoterLength = NULL, leftFlanking = NULL, rightFlanking = NULL, For = NULL,fragmentFile = NULL, fragmentName = NULL, chr = NULL, start = NULL, end = NULL, strand = NULL, length = NULL, inputFile = NULL,  windowSize = NULL, stepWise = NULL, TmMethod = NULL, specificityMin = NULL, nthreads = NULL, Evalue = NULL, GCShow = NULL, TmShow = NULL, specificiyShow = NULL, countShow = NULL, TmScope = NULL, GCScope = NULL, countMax = NULL, segmentLinetype = NULL, segmentColor = NULL, segmentSize = NULL, pointShape1 = NULL, pointShape2 = NULL, pointColor1 = NULL, pointColor2 = NULL, pointSize = NULL, pointSize1 = NULL, pointSize2 = NULL, hlineType = NULL, hlineColor = NULL, hlineSize = NULL, pdfWidth = NULL, pdfHeight = NULL, outFormat = NULL, seqEvaluation = NULL, plotting = NULL,  endMatch = NULL, GCend = NULL, primerLength = NULL, primerStrand = NULL, Fcolor = NULL, Rcolor = NULL, lcolor = NULL, leftRegion = NULL, rightRegion = NULL, ...){

  library(data.table)
  library(xlsx)
  if(is.null(For)) For = "Cloning"
  if(is.null(seqType)) stop("'seqType' is required!")
  if(is.null(type)) stop("'type' is required!")
  
  dir.path = getwd()
  
  ## sequence extraction
  if(!is.null(geneName)){
    gene.seq.extraction(database = database, geneName = geneName, gffFile = gffFile, type = type, promoterLength = promoterLength, leftFlanking = leftFlanking, rightFlanking = rightFlanking, For = For)
  }
  if(!is.null(fragmentFile)){
    fragment.seq.extraction.1(database = database, fragmentFile = fragmentFile, For = For)
  }
  if(!is.null(fragmentName)){
    fragment.seq.extraction.2(database = database, fragmentName = fragmentName, chr = chr, start = start, end = end, strand = strand, length = length, leftFlanking = leftFlanking, rightFlanking = rightFlanking, For = For)
  }
  
  ## sequence evaluation
  if(is.null(inputFile)){
    if(seqType == "gene" | seqType == "Gene" | seqType == "GENE"){
      if(!file.exists(geneName)){
        dirList = list.files("./Sequence.extraction/Gene/")
        dirList = paste0("./Sequence.extraction/Gene/", dirList)
        dirList = dirList[grep(geneName, dirList)]
        if(length(dirList) >= 1){
          for(i in 1:length(dirList)){
            dirName = strsplit(dirList[i], "/")[[1]][length(strsplit(dirList[i], "/")[[1]])]
            inputFile = paste0(dirList[i], "/")
            if(file.exists(inputFile)){
              seq.evaluation(database = database, inputFile = inputFile, blastDir = blastDir, seqType = seqType, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
              cat(paste0("\nSequence evaluation of ", dirName, " is DONE!\n"))
              seqEvaluation = paste0("./Sequence.evaluation/Gene/", dirName, "/") 
              if(dir.exists(seqEvaluation)){
                primer.designing.for.cloning(seqEvaluation = seqEvaluation, gffFile = gffFile, seqType = seqType, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend = GCend, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, leftRegion = leftRegion, rightRegion = rightRegion)
                cat(paste0("\nPrimer designing of ", dirName, " for cloning is DONE!\n"))
              }else{
                warning(paste0("\n", dirName, " does not exist in ./Sequence.evaluation/Gene/\n"))
                next
              }
            }else{
              warning(paste0("\n", dirName, " does not exist in ./Sequence.extraction/Gene/\n"))
              next
            }
          }
        }else{
          warning(paste0("\n", geneName, " does not exist in ./Sequence.extraction/Gene/\n"))
        }
      }
      if(file.exists(geneName)){
        if(length(grep(".csv|.txt", geneName)) == 1){
          geneList = fread(file = geneName, header = T, sep = "\t", stringsAsFactors = F, fill = T)
          if(ncol(geneList) == 1){
            geneList = fread(file = geneName, header = T, sep = ",", stringsAsFactors = F, fill = T)
            if(ncol(geneList) == 1){
              geneList = fread(file = geneName, header = T, sep = " ", stringsAsFactors = F, fill = T)
            }
          }
        }
        if(length(grep(".xlsx|.xls", geneName)) == 1){
          geneList = data.frame(read.xlsx(paste0(dir.path, "/", geneName), header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
        }
        dirList = list.files("./Sequence.extraction/Gene/")
        dirList = paste0("./Sequence.extraction/Gene/", dirList)
        # i = 1;j = 1
        for(i in 1:nrow(geneList)){
          dir = dirList[grep(geneList$Gene.ID[i], dirList)]
          
          ## parameter assignment if defined by input file
          if(length(grep("^Type$", names(geneList))) == 1 & !is.na(geneList$Type[i])){
            type = geneList$Type[i]
          }else{if(is.null(type)) type = "all"}
          if(length(grep("^promoterLength$", names(geneList))) == 1 & !is.na(geneList$promoterLength[i]))  promoterLength = geneList$promoterLength[i]
          if(length(grep("^leftFlanking$", names(geneList))) == 1 & !is.na(geneList$leftFlanking[i]))  leftFlanking = geneList$leftFlanking[i]
          if(length(grep("^rightFlanking$", names(geneList))) == 1 & !is.na(geneList$rightFlanking[i]))  rightFlanking = geneList$rightFlanking[i]
          if(length(grep("^windowSize$", names(geneList))) == 1 & !is.na(geneList$windowSize[i]))  windowSize = geneList$windowSize[i]
          if(length(grep("^stepWise$", names(geneList))) == 1 & !is.na(geneList$stepWise[i]))  stepWise = geneList$stepWise[i]
          if(length(grep("^TmMethod$", names(geneList))) == 1 & !is.na(geneList$TmMethod[i]))  TmMethod = geneList$TmMethod[i]
          if(length(grep("^specificityMin$", names(geneList))) == 1 & !is.na(geneList$specificityMin[i]))  specificityMin = geneList$specificityMin[i]
          if(length(grep("^nthreads$", names(geneList))) == 1 & !is.na(geneList$nthreads[i]))  nthreads = geneList$nthreads[i]
          if(length(grep("^Evalue$", names(geneList))) == 1 & !is.na(geneList$Evalue[i]))  Evalue = geneList$Evalue[i]
          if(length(grep("^GCShow$", names(geneList))) == 1 & !is.na(geneList$GCShow[i]))  GCShow = geneList$GCShow[i]
          if(length(grep("^TmShow$", names(geneList))) == 1 & !is.na(geneList$TmShow[i]))  TmShow = geneList$TmShow[i]
          if(length(grep("^specificiyShow$", names(geneList))) == 1 & !is.na(geneList$specificiyShow[i]))  specificiyShow = geneList$specificiyShow[i]
          if(length(grep("^countShow$", names(geneList))) == 1 & !is.na(geneList$countShow[i]))  countShow = geneList$countShow[i]
          if(length(grep("^TmScope$", names(geneList))) == 1 & !is.na(geneList$TmScope[i]))  TmScope = geneList$TmScope[i]
          if(length(grep("^GCScope$", names(geneList))) == 1 & !is.na(geneList$GCScope[i]))  GCScope = geneList$GCScope[i]
          if(length(grep("^countMax$", names(geneList))) == 1 & !is.na(geneList$countMax[i]))  countMax = geneList$countMax[i]
          if(length(grep("^segmentLinetype$", names(geneList))) == 1 & !is.na(geneList$segmentLinetype[i]))  segmentLinetype = geneList$segmentLinetype[i]
          if(length(grep("^segmentColor$", names(geneList))) == 1 & !is.na(geneList$segmentColor[i]))  segmentColor = geneList$segmentColor[i]
          if(length(grep("^segmentSize$", names(geneList))) == 1 & !is.na(geneList$segmentSize[i]))  segmentSize = geneList$segmentSize[i]
          if(length(grep("^pointShape1$", names(geneList))) == 1 & !is.na(geneList$pointShape1[i]))  pointShape1 = geneList$pointShape1[i]
          if(length(grep("^pointShape2$", names(geneList))) == 1 & !is.na(geneList$pointShape2[i]))  pointShape2 = geneList$pointShape2[i]
          if(length(grep("^pointColor1$", names(geneList))) == 1 & !is.na(geneList$pointColor1[i]))  pointColor1 = geneList$pointColor1[i]
          if(length(grep("^pointColor2$", names(geneList))) == 1 & !is.na(geneList$pointColor2[i]))  pointColor2 = geneList$pointColor2[i]
          if(length(grep("^pointSize$", names(geneList))) == 1 & !is.na(geneList$pointSize[i]))  pointSize = geneList$pointSize[i]
          if(length(grep("^pointSize1$", names(geneList))) == 1 & !is.na(geneList$pointSize1[i]))  pointSize1 = geneList$pointSize1[i]
          if(length(grep("^pointSize2$", names(geneList))) == 1 & !is.na(geneList$pointSize2[i]))  pointSize2 = geneList$pointSize2[i]
          if(length(grep("^hlineType$", names(geneList))) == 1 & !is.na(geneList$hlineType[i]))  hlineType = geneList$hlineType[i]
          if(length(grep("^hlineColor$", names(geneList))) == 1 & !is.na(geneList$hlineColor[i]))  hlineColor = geneList$hlineColor[i]
          if(length(grep("^hlineSize$", names(geneList))) == 1 & !is.na(geneList$hlineSize[i]))  hlineSize = geneList$hlineSize[i]
          if(length(grep("^pdfWidth$", names(geneList))) == 1 & !is.na(geneList$pdfWidth[i]))  pdfWidth = geneList$pdfWidth[i]
          if(length(grep("^pdfHeight$", names(geneList))) == 1 & !is.na(geneList$pdfHeight[i]))  pdfHeight = geneList$pdfHeight[i]
          if(length(grep("^outFormat$", names(geneList))) == 1 & !is.na(geneList$outFormat[i]))  outFormat = geneList$outFormat[i]
          if(length(grep("^plotting$", names(geneList))) == 1 & !is.na(geneList$plotting[i]))  plotting = geneList$plotting[i]
          if(length(grep("^endMatch$", names(geneList))) == 1 & !is.na(geneList$endMatch[i]))  endMatch = geneList$endMatch[i]
          if(length(grep("^GCend$", names(geneList))) == 1 & !is.na(geneList$GCend[i]))  type = geneList$GCend[i]
          if(length(grep("^primerLength$", names(geneList))) == 1 & !is.na(geneList$primerLength[i]))  primerLength = geneList$primerLength[i]
          if(length(grep("^primerStrand$", names(geneList))) == 1 & !is.na(geneList$primerStrand[i]))  primerStrand = geneList$primerStrand[i]
          if(length(grep("^Fcolor$", names(geneList))) == 1 & !is.na(geneList$Fcolor[i]))  Fcolor = geneList$Fcolor[i]
          if(length(grep("^Rcolor$", names(geneList))) == 1 & !is.na(geneList$Rcolor[i]))  Rcolor = geneList$Rcolor[i]
          if(length(grep("^lcolor$", names(geneList))) == 1 & !is.na(geneList$lcolor[i]))  lcolor = geneList$lcolor[i]
          if(length(grep("^leftRegion$", names(geneList))) == 1 & !is.na(geneList$leftRegion[i]))  leftRegion = geneList$leftRegion[i]
          if(length(grep("^rightRegion$", names(geneList))) == 1 & !is.na(geneList$rightRegion[i]))  rightRegion = geneList$rightRegion[i]
          
          #####
          if(length(dir) >= 1){
            for(j in 1:length(dir)){
              dirName = strsplit(dir[j], "/")[[1]][length(strsplit(dir[j], "/")[[1]])]
              inputFile = paste0(dir[j], "/")
              if(file.exists(inputFile)){
                seq.evaluation(database = database, inputFile = inputFile, blastDir = blastDir, seqType = seqType, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
                cat(paste0("\nSequence evaluation of ", dirName, " is DONE!\n"))
                seqEvaluation = paste0("./Sequence.evaluation/Gene/", dirName, "/")
                if(dir.exists(seqEvaluation)){
                  primer.designing.for.cloning(seqEvaluation = seqEvaluation, gffFile = gffFile, seqType = seqType, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend = GCend, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, leftRegion = leftRegion, rightRegion = rightRegion)
                  cat(paste0("\nPrimer designing of ", dirName, " for cloning is DONE!\n"))
                }else{
                  warning(paste0("\n",dirName, " does not exist in ./Sequence.evaluation/Gene/\n"))
                  next
                }
              }else{
                warning(paste0("\n", dirName, " does not exist in ./Sequence.extraction/Gene/"))
                next
              }
            }
          }else{
            warning(paste0("\n", geneList$Gene.ID[i], " does not exist!"))
            next
          }
        }
      }
    }
    if(seqType == "fragment" | seqType == "Fragment" | seqType == "FRAGMENT"){
      if(!is.null(fragmentName)){
        dirList = list.files("./Sequence.extraction/Fragment/")
        dirList = paste0("./Sequence.extraction/Fragment/", dirList)
        dirList = dirList[grep(fragmentName, dirList)]
        if(length(dirList) >= 1){
          for(i in 1:length(dirList)){
            dirName = strsplit(dirList[i], "/")[[1]][length(strsplit(dirList[i], "/")[[1]])]
            inputFile = paste0(dirList[i], "/")
            if(file.exists(inputFile)){
              seq.evaluation(database = database, inputFile = inputFile, blastDir = blastDir, seqType = seqType, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
              cat(paste0("\nSequence evaluation of ", dirName, " is DONE!\n"))
              seqEvaluation = paste0("./Sequence.evaluation/Fragment/", dirName, "/")
              if(dir.exists(seqEvaluation)){
                primer.designing.for.cloning(seqEvaluation = seqEvaluation, gffFile = gffFile, seqType = seqType, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend = GCend, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, leftRegion = leftRegion, rightRegion = rightRegion)
                cat(paste0("\nPrimer designing of ", dirName, " for cloning is DONE!\n"))
              }else{
                warning(paste0("\n", dirName, " does not exist in ./Sequence.evaluation/Fragment/\n"))
                next
              }
            }else{
              warning(paste0("\n", dirName, " does not exist in ./Sequence.extraction/Fragment/\n"))
              next
            }
          }
        }
      }
      
      if(!is.null(fragmentFile)){
        if(length(grep(".csv|.txt", fragmentFile)) == 1){
          fragmentList = fread(file = fragmentFile, header = T, sep = "\t", stringsAsFactors = F, fill = T)
          if(ncol(fragmentList) == 1){
            fragmentList = fread(file = fragmentFile, header = T, sep = ",", stringsAsFactors = F, fill = T)
            if(ncol(fragmentList) == 1){
              fragmentList = fread(file = fragmentFile, header = T, sep = " ", stringsAsFactors = F, fill = T)
            }
          }
        }
        if(length(grep(".xlsx|.xls", fragmentFile)) == 1){
          fragmentList = data.frame(read.xlsx(paste0(dir.path, "/", fragmentFile), header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
        }
        
        dirList = list.files("./Sequence.extraction/Fragment/")
        dirList = paste0("./Sequence.extraction/Fragment/", dirList)
        for(i in 1:nrow(fragmentList)){
          dir = dirList[grep(fragmentList$Fragment.ID[i], dirList)]
          ## parameter assignment if defined by input file
          #if(length(grep("^Type$", names(fragmentList))) == 1 & !is.na(fragmentList$Type[i]))  type = fragmentList$Type[i]
          if(length(grep("^Length$", names(fragmentList))) == 1 & !is.na(fragmentList$Length[i]))  length = fragmentList$Length[i]
          if(length(grep("^leftFlanking$", names(fragmentList))) == 1 & !is.na(fragmentList$leftFlanking[i]))  leftFlanking = fragmentList$leftFlanking[i]
          if(length(grep("^rightFlanking$", names(fragmentList))) == 1 & !is.na(fragmentList$rightFlanking[i]))  rightFlanking = fragmentList$rightFlanking[i]
          if(length(grep("^windowSize$", names(fragmentList))) == 1 & !is.na(fragmentList$windowSize[i]))  windowSize = fragmentList$windowSize[i]
          if(length(grep("^stepWise$", names(fragmentList))) == 1 & !is.na(fragmentList$stepWise[i]))  stepWise = fragmentList$stepWise[i]
          if(length(grep("^TmMethod$", names(fragmentList))) == 1 & !is.na(fragmentList$TmMethod[i]))  TmMethod = fragmentList$TmMethod[i]
          if(length(grep("^specificityMin$", names(fragmentList))) == 1 & !is.na(fragmentList$specificityMin[i]))  specificityMin = fragmentList$specificityMin[i]
          if(length(grep("^nthreads$", names(fragmentList))) == 1 & !is.na(fragmentList$nthreads[i]))  nthreads = fragmentList$nthreads[i]
          if(length(grep("^Evalue$", names(fragmentList))) == 1 & !is.na(fragmentList$Evalue[i]))  Evalue = fragmentList$Evalue[i]
          if(length(grep("^GCShow$", names(fragmentList))) == 1 & !is.na(fragmentList$GCShow[i]))  GCShow = fragmentList$GCShow[i]
          if(length(grep("^TmShow$", names(fragmentList))) == 1 & !is.na(fragmentList$TmShow[i]))  TmShow = fragmentList$TmShow[i]
          if(length(grep("^specificiyShow$", names(fragmentList))) == 1 & !is.na(fragmentList$specificiyShow[i]))  specificiyShow = fragmentList$specificiyShow[i]
          if(length(grep("^countShow$", names(fragmentList))) == 1 & !is.na(fragmentList$countShow[i]))  countShow = fragmentList$countShow[i]
          if(length(grep("^TmScope$", names(fragmentList))) == 1 & !is.na(fragmentList$TmScope[i]))  TmScope = fragmentList$TmScope[i]
          if(length(grep("^GCScope$", names(fragmentList))) == 1 & !is.na(fragmentList$GCScope[i]))  GCScope = fragmentList$GCScope[i]
          if(length(grep("^countMax$", names(fragmentList))) == 1 & !is.na(fragmentList$countMax[i]))  countMax = fragmentList$countMax[i]
          if(length(grep("^segmentLinetype$", names(fragmentList))) == 1 & !is.na(fragmentList$segmentLinetype[i]))  segmentLinetype = fragmentList$segmentLinetype[i]
          if(length(grep("^segmentColor$", names(fragmentList))) == 1 & !is.na(fragmentList$segmentColor[i]))  segmentColor = fragmentList$segmentColor[i]
          if(length(grep("^segmentSize$", names(fragmentList))) == 1 & !is.na(fragmentList$segmentSize[i]))  segmentSize = fragmentList$segmentSize[i]
          if(length(grep("^pointShape1$", names(fragmentList))) == 1 & !is.na(fragmentList$pointShape1[i]))  pointShape1 = fragmentList$pointShape1[i]
          if(length(grep("^pointShape2$", names(fragmentList))) == 1 & !is.na(fragmentList$pointShape2[i]))  pointShape2 = fragmentList$pointShape2[i]
          if(length(grep("^pointColor1$", names(fragmentList))) == 1 & !is.na(fragmentList$pointColor1[i]))  pointColor1 = fragmentList$pointColor1[i]
          if(length(grep("^pointColor2$", names(fragmentList))) == 1 & !is.na(fragmentList$pointColor2[i]))  pointColor2 = fragmentList$pointColor2[i]
          if(length(grep("^pointSize$", names(fragmentList))) == 1 & !is.na(fragmentList$pointSize[i]))  pointSize = fragmentList$pointSize[i]
          if(length(grep("^pointSize1$", names(fragmentList))) == 1 & !is.na(fragmentList$pointSize1[i]))  pointSize1 = fragmentList$pointSize1[i]
          if(length(grep("^pointSize2$", names(fragmentList))) == 1 & !is.na(fragmentList$pointSize2[i]))  pointSize2 = fragmentList$pointSize2[i]
          if(length(grep("^hlineType$", names(fragmentList))) == 1 & !is.na(fragmentList$hlineType[i]))  hlineType = fragmentList$hlineType[i]
          if(length(grep("^hlineColor$", names(fragmentList))) == 1 & !is.na(fragmentList$hlineColor[i]))  hlineColor = fragmentList$hlineColor[i]
          if(length(grep("^hlineSize$", names(fragmentList))) == 1 & !is.na(fragmentList$hlineSize[i]))  hlineSize = fragmentList$hlineSize[i]
          if(length(grep("^pdfWidth$", names(fragmentList))) == 1 & !is.na(fragmentList$pdfWidth[i]))  pdfWidth = fragmentList$pdfWidth[i]
          if(length(grep("^pdfHeight$", names(fragmentList))) == 1 & !is.na(fragmentList$pdfHeight[i]))  pdfHeight = fragmentList$pdfHeight[i]
          if(length(grep("^outFormat$", names(fragmentList))) == 1 & !is.na(fragmentList$outFormat[i]))  outFormat = fragmentList$outFormat[i]
          if(length(grep("^plotting$", names(fragmentList))) == 1 & !is.na(fragmentList$plotting[i]))  plotting = fragmentList$plotting[i]
          if(length(grep("^endMatch$", names(fragmentList))) == 1 & !is.na(fragmentList$endMatch[i]))  endMatch = fragmentList$endMatch[i]
          if(length(grep("^GCend$", names(fragmentList))) == 1 & !is.na(fragmentList$GCend[i]))  type = fragmentList$GCend[i]
          if(length(grep("^primerLength$", names(fragmentList))) == 1 & !is.na(fragmentList$primerLength[i]))  primerLength = fragmentList$primerLength[i]
          if(length(grep("^primerStrand$", names(fragmentList))) == 1 & !is.na(fragmentList$primerStrand[i]))  primerStrand = fragmentList$primerStrand[i]
          if(length(grep("^Fcolor$", names(fragmentList))) == 1 & !is.na(fragmentList$Fcolor[i]))  Fcolor = fragmentList$Fcolor[i]
          if(length(grep("^Rcolor$", names(fragmentList))) == 1 & !is.na(fragmentList$Rcolor[i]))  Rcolor = fragmentList$Rcolor[i]
          if(length(grep("^lcolor$", names(fragmentList))) == 1 & !is.na(fragmentList$lcolor[i]))  lcolor = fragmentList$lcolor[i]
          if(length(grep("^leftRegion$", names(fragmentList))) == 1 & !is.na(fragmentList$leftRegion[i]))  leftRegion = fragmentList$leftRegion[i]
          if(length(grep("^rightRegion$", names(fragmentList))) == 1 & !is.na(fragmentList$rightRegion[i]))  rightRegion = fragmentList$rightRegion[i]
          
          
          if(length(dir) >= 1){
            for(j in 1:length(dir)){
              dirName = strsplit(dir[j], "/")[[1]][length(strsplit(dir[j], "/")[[1]])]
              inputFile = paste0(dir[j], "/")
              if(file.exists(inputFile)){
                seq.evaluation(database = database, inputFile = inputFile, blastDir = blastDir, seqType = seqType, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
                cat(paste0("\nSequence evaluation of ", dirName, " is DONE!\n"))
                seqEvaluation = paste0("./Sequence.evaluation/Fragment/", dirName, "/")
                if(dir.exists(seqEvaluation)){
                  primer.designing.for.cloning(seqEvaluation = seqEvaluation, gffFile = gffFile, seqType = seqType, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend = GCend, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, leftRegion = leftRegion, rightRegion = rightRegion)
                  cat(paste0("\nPrimer designing of ", dirName, " for cloning is DONE!\n"))
                }else{
                  warning(paste0("\n", dirName, " does not exist in ./Sequence.evaluation/Fragment/\n"))
                  next
                }
              }else{
                warning(paste0("\n", dirName, " does not exist in ./Sequence.extraction/Fragment/\n"))
                next
              }
            }
          }
        }
      }
    }
  }
  cat(paste0("\nPrimer designing of ", ifelse(!is.null(geneName), geneName, ifelse(!is.null(fragmentName), fragmentName, fragmentFile)),  " is/are ALL DONE!\n")) 
}


