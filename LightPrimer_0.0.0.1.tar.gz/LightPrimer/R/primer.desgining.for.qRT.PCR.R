
#' This is some description of this function.
#' @title to design primers for qRT-PCR primers of certain gene.
#'
#' @description By using this package, you could use function of primer.designing.for.qRT.PCR to design primers for qRT-PCR primers of certain gene.
#'
#' @details see above
#'
#' @param seqEvaluation: seqEvaluation folder.
#' @param gffFile: general feature format of certain genome, it must contain at least Gene.ID, Chr, Start, End, Strand, Type.
#' @param plotting: logical value indicates whether to plot primers or not.
#' @param TmScope: numeric scope indicates the min and max of primer Tm, default value is 'c(40, 60)'.
#' @param GCScope: numeric scope indicates the min and max of primer GC content (%), default value is 'c(35, 65)'.
#' @param specificityMin: numeric value indicates the minimum standard of sequence specificity (%), default value is 98%.
#' @param countMax: numeric value indicates the maximum standard of counts of this primer mathched to different position on the chromosome, default value is 2.
#' @param endMatch: logical value indicates whether the primer end (3') matched to genome, default value is TRUE
#' @param GCend: logical value indicates whether the primer end (3') should be G:C or not, default value is TRUE
#' @param lengthScope: numeric scope indicates the expected min and max amplicon length of primer pairs, default value is 'c(70, 150)'.
#' @param primerLength: numeric scope indicates the min and max length of primer, default value is 'c(20, 25)'.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X4+(T+C)X2, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param primerStrand: 'F' or 'R', or c('F', 'R')
#' @param Fcolor: color value for forward primers, default is "#B2182B".
#' @param Rcolor: color value for reverse primers, default is "#2166AC".
#' @param lcolor: color value for line connecting forward and reverse primer pairs, default is 'black'.
#' @param overlapMin: numeric value indicates at least how many base pairs should be acrossing different exons, to eliminate none specific matching to genome DNA. Default is 5bp.
#' @return files and folder
#' @export primer.designing.for.qRT.PCR
#' @examples primer.designing.for.qRT.PCR(seqEvaluation = "./Sequence.evaluation/", gffFile = "./Wm82.a2.v1.gene.gff")
#' 

# primer.designing.for.qRT.PCR(seqEvaluation = "./Sequence.evaluation/", gffFile = "./Wm82.a2.v1.gene.gff")

primer.designing.for.qRT.PCR = function(seqEvaluation = NULL, gffFile = NULL, plotting = NULL, TmScope = NULL, GCScope = NULL, specificityMin = NULL, countMax = NULL, endMatch = NULL, GCend = NULL, lengthScope = NULL, primerLength = NULL, TmMethod = NULL, primerStrand = NULL, Fcolor = NULL, Rcolor = NULL, lcolor = NULL, overlapMin = NULL, ...){
  
  library(stringr)
  library(seqinr)
  library(Biostrings)
  library(tidyr)
  library(xlsx)
  library(WriteXLS)
  library(data.table)
  library(ggplot2)
  
  dir.path = getwd()
  
  if(!dir.exists(paste0(dir.path, "/", "Designed.primers"))){
    dir.create(paste0(dir.path, "/", "Designed.primers"))
  }
  if(!dir.exists(paste0(dir.path, "/", "Designed.primers/", "qRT.primers"))){
    dir.create(paste0(dir.path, "/", "Designed.primers/", "qRT.primers"))
  }
  
  if(is.null(seqEvaluation)) stop("'seqEvaluation' is required!")
  if(is.null(gffFile)) stop("'gffFile' is required!")
  if(is.null(plotting)) plotting = TRUE
  if(is.null(TmScope)) TmScope = c(40, 60)
  if(is.null(GCScope)) GCScope = c(35, 65)
  if(is.null(countMax)) countMax = 2
  if(is.null(specificityMin)) specificityMin = 98
  if(is.null(endMatch)) endMatch = TRUE
  if(is.null(GCend)) GCend = TRUE
  if(is.null(lengthScope)) lengthScope = c(70, 150)
  if(is.null(primerLength)) primerLength = c(20, 25)
  if(is.null(overlapMin)) overlapMin = 5
  if(is.null(TmMethod)) TmMethod = "both"
  if(is.null(primerStrand)) primerStrand = c('F', 'R')
  if(is.null(plotting)) plotting = TRUE
  if(is.null(Fcolor)) Fcolor = "#B2182B"
  if(is.null(Rcolor)) Rcolor = "#2166AC"
  if(is.null(lcolor)) lcolor = "black"
  
  if(!dir.exists(seqEvaluation)){
    stop("'seqEvaluation' should be a folder contains 'Blast.output', 'Splitted.seq', 'window.size.by.*' etc., please perform seq.evaluation() analysis before primer designing!\n")
  }
  
  gff = fread(gffFile, header = T, sep = "\t", fill = TRUE)
  if(ncol(gff) == 1){
    gff = fread(gffFile, header = T, sep = ",", fill = TRUE)
    if(ncol(gff) == 1){
      gff = fread(gffFile, header = T, sep = " ", fill = TRUE)
    }
  }
  setkeyv(gff, names(gff))
  if(length(grep("(Gene.ID|Chr|Start|End|Strand|Type)", names(gff))) == 6){
    gff = gff[,c("Gene.ID", "Chr", "Start", "End", "Strand", "Type")]
    type.length = length(unique(gff$Type))
    types = unique(gff$Type)[1]
    for(i in 2:length(unique(gff$Type))){
      types = paste0(types, ", ", unique(gff$Type)[i])
    }
    # cat(paste0("gffFile contains ", nrow(gff), " rows, ", type.length, " types, including ", types))
  }else{
    stop("gff file should contain at least the following columns: 'Gene.ID', 'Chr', 'Start', 'End', 'Strand', and 'Type'! Please check your gff file format!\n")
  }
  
  # file merging function
  data.merging = function(fileList = NULL, header = NULL, skipRow = NULL, ...){
    library(data.table)
    if(is.null(fileList)) stop("'fileList' in 'data.merging' is required!")
    if(is.null(header)) header = T
    if(is.null(skipRow)) skipRow = 0
    data = fread(fileList[1], header = header, stringsAsFactors = F, sep = "\t", skip = skipRow, fill = T)
    if(ncol(data) == 1){
      data = fread(fileList[1], header = header, stringsAsFactors = F, sep = ",", skip = skipRow, fill = T)
      if(ncol(data) == 1){
        data = fread(fileList[1], header = header, stringsAsFactors = F, sep = " ", skip = skipRow, fill = T)
      }
    }
    for(i in 2:length(fileList)){
      temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = "\t", skip = skipRow, fill = T)
      if(ncol(temp) == 1){
        temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = ",", skip = skipRow, fill = T)
        if(ncol(temp) == 1){
          temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = " ", skip = skipRow, fill = T)
        }
      }
      data = rbind(data, temp)
    }
    return(data)
  }
  
  ### fasta sequence merging
  seq.merging = function(seqDir){
    seq = readDNAStringSet(seqDir[1], format = "fasta")
    for(i in 2:length(seqDir)){
      temp = readDNAStringSet(seqDir[i], format = "fasta")
      seq = append(seq, temp)
    }
    return(seq)
  }
  
  file.list = list.files(paste0(dir.path, "/", seqEvaluation), recursive = TRUE)
  dir = paste0(dir.path, "/", seqEvaluation, file.list)
  dir = dir[-grep(".pdf", dir)]
  blast.dir = dir[grep("blast.out.csv", dir)]
  dir = dir[-grep("blast.out.csv", dir)]
  seqEval.dir = dir[grep("sequence.evaluation.csv", dir)]
  split.dir = dir[grep("split.seq.fasta", dir)]
  mRNA.cds.dir = seqEval.dir[grep("mRNA", seqEval.dir)]
  mRNA.blast.dir = blast.dir[grep("mRNA", blast.dir)]
  mRNA.blast.dir = mRNA.blast.dir[grep("qRT-PCR|qRT.PCR", mRNA.blast.dir)]
  mRNA.cds.dir.name = c()

  for(i in 1:length(mRNA.cds.dir)){
    temp = strsplit(strsplit(mRNA.cds.dir[i], "/")[[1]][length(strsplit(mRNA.cds.dir[i], "/")[[1]])], "_")[[1]]
    temp = paste0(temp[1], "_", temp[2])
    mRNA.cds.dir.name = c(mRNA.cds.dir.name, temp)
  }
  mRNA.list = unique(mRNA.cds.dir.name)
  # i = 1
  for(i in 1:length(mRNA.list)){
    #######
    dir.temp = mRNA.cds.dir[grep(mRNA.list[i], mRNA.cds.dir)]
    overall = data.merging(fileList = dir.temp)
    overall = overall[!duplicated(overall),]
    type = str_extract_all(mRNA.cds.dir[i], "(mRNA)")[[1]]
    names(overall) = gsub("\\(.?\\)|\\(5'-3'\\)", "", names(overall))
    setkeyv(overall, names(overall))
    overall.NA = overall[is.na(overall$To),]
    overall = overall[!is.na(overall$From),]
    
    #######
    split.dir.temp = split.dir[grep(mRNA.list[i], split.dir)]
    split.dir.temp = split.dir.temp[grep("qRT-PCR|qRT.PCR", split.dir.temp)]
    split.seq = seq.merging(seqDir = split.dir.temp)
    split.seq = data.table(cbind(names(split.seq), data.frame(split.seq[names(split.seq)])))
    names(split.seq) = c("Name", "Seq")
    setkeyv(split.seq, names(split.seq))
    split.seq$From = NA
    split.seq$To = NA
    split.seq$Length = NA
    # j = 1
    for(j in 1:nrow(split.seq)){
      split.seq$From[j] = as.numeric(strsplit(split.seq$Name[j], "_")[[1]][9])
      split.seq$To[j] = as.numeric(strsplit(split.seq$Name[j], "_")[[1]][11])
      split.seq$Length[j] = as.numeric(split.seq$To[j]) - as.numeric(split.seq$From[j]) + 1
    }
    # split.seq[, c('From') := as.numeric(unlist(strsplit(split.seq$Name, "_"))[seq(9, nrow(split.seq)*11, by = 11)])]
    # split.seq[, c('To') := as.numeric(unlist(strsplit(split.seq$Name, "_"))[seq(11, nrow(split.seq)*11, by = 11)])]
    # split.seq[, c('Length') := To - From + 1]
    split.seq = as.data.table(split.seq)
    setkeyv(split.seq, names(split.seq))
    
    
    #######
    Chr = strsplit(strsplit(dir.temp[1], "/")[[1]][length(strsplit(dir.temp[1], "/")[[1]])], "_")[[1]][3]
    region = strsplit(strsplit(dir.temp[1], "/")[[1]][length(strsplit(dir.temp[1], "/")[[1]])], "_")[[1]][4]
    region = as.numeric(strsplit(region, "\\..")[[1]])
    leftFlanking = strsplit(strsplit(dir.temp[1], "/")[[1]][length(strsplit(dir.temp[1], "/")[[1]])], "_")[[1]][5]
    leftFlanking = as.numeric(strsplit(leftFlanking, "\\.")[[1]][2])
    rightFlanking = strsplit(strsplit(dir.temp[1], "/")[[1]][length(strsplit(dir.temp[1], "/")[[1]])], "_")[[1]][6]
    rightFlanking = as.numeric(strsplit(rightFlanking, "\\.")[[1]][2])
    
    #######
    mRNAName = strsplit(mRNA.list[i], "_")[[1]][1]
    mRNA.gff = gff[which(gff$Gene.ID == mRNAName & gff$Type != "mRNA"),]
    Strand = unique(mRNA.gff$Strand)
    if(leftFlanking >= 0 & rightFlanking >= 0){
      flanking = data.table(matrix(nrow = 2, ncol = ncol(mRNA.gff)))
      names(flanking) = names(mRNA.gff)
      flanking$Type[1] = "leftFlanking"; flanking$Type[2] = "rightFlanking"
      if(Strand == "+"){
        flanking$Start[1] = min(mRNA.gff$Start) - leftFlanking
        flanking$End[1] = min(mRNA.gff$Start) - 1
        flanking$Start[2] = max(mRNA.gff$End) + 1
        flanking$End[2] = max(mRNA.gff$End) + rightFlanking
      }else{
        flanking$End[1] = max(mRNA.gff$End) + leftFlanking
        flanking$Start[1] = max(mRNA.gff$End) + 1
        flanking$Start[2] = min(mRNA.gff$Start) - rightFlanking
        flanking$End[2] = min(mRNA.gff$Start) - 1
      }
      mRNA.gff = rbind(mRNA.gff, flanking)
      mRNA.gff[,c(1,2,5)] = mRNA.gff[1,c(1,2,5)]
    }
    
    mRNA.gff = mRNA.gff[order(mRNA.gff$Start),]
    mRNA.gff$From = 0;mRNA.gff$To = 0
    #######
    if(Strand == "+"){
      mRNA.gff$fragmentLength = mRNA.gff$End - mRNA.gff$Start + 1
      for(j in 1:nrow(mRNA.gff)){
        if(j == 1){
          mRNA.gff$From[j] = 1; mRNA.gff$To[j] = mRNA.gff$fragmentLength[j]
        }
        if(j > 1){
          mRNA.gff$From[j] = mRNA.gff$To[j-1] + 1; mRNA.gff$To[j] = mRNA.gff$From[j] + mRNA.gff$fragmentLength[j] - 1
        }
      }
    }else{
      Start = mRNA.gff$End
      End = mRNA.gff$Start
      mRNA.gff$Start = Start
      mRNA.gff$End = End
      mRNA.gff = mRNA.gff[order(mRNA.gff$End, decreasing = T),]
      mRNA.gff$fragmentLength = mRNA.gff$Start - mRNA.gff$End + 1
      for(j in 1:nrow(mRNA.gff)){
        if(j == 1){
          mRNA.gff$From[j] = 1; mRNA.gff$To[j] = mRNA.gff$fragmentLength[j]
        }
        if(j > 1){
          mRNA.gff$From[j] = mRNA.gff$To[j-1] + 1; mRNA.gff$To[j] = mRNA.gff$From[j] + mRNA.gff$fragmentLength[j] - 1
        }
      }
    }

    ###
    split.seq$Start = NA
    split.seq$End = NA
    split.seq$gffStart1 = NA
    split.seq$gffEnd1 = NA
    split.seq$gffStart2 = NA
    split.seq$gffEnd2 = NA
    split.seq$Left = NA
    split.seq$Right = NA
    split.seq$bridge = "No"
    split.seq = as.data.table(split.seq)
    setkeyv(split.seq, names(split.seq))
    split.seq = split.seq[order(split.seq$From),]
    # j = 6; k = 1
    for(j in 1:nrow(split.seq)){
      window.temp = split.seq$To[j] - split.seq$From[j] + 1
      if(Strand == "+"){
        for(k in 1:nrow(mRNA.gff)){
          if(split.seq$From[j] <= mRNA.gff$To[k] & split.seq$From[j] >= mRNA.gff$From[k]){
            split.seq$Start[j] = mRNA.gff$Start[k] + split.seq$From[j] - ifelse(k >= 2, mRNA.gff$To[k-1], 0) -1
            split.seq$gffStart1[j] = mRNA.gff$Start[k]
            split.seq$gffEnd1[j] = mRNA.gff$End[k]
            if(split.seq$To[j] <= mRNA.gff$To[k]){
              split.seq$End[j] = mRNA.gff$Start[k] + split.seq$From[j] - ifelse(k >= 2, mRNA.gff$To[k-1], 0) + window.temp - 2
              split.seq$gffStart2[j] = mRNA.gff$Start[k]
              split.seq$gffEnd2[j] = mRNA.gff$End[k]
            }else{
              split.seq$gffStart2[j] = mRNA.gff$Start[k+1]
              split.seq$gffEnd2[j] = mRNA.gff$End[k+1]
              left = mRNA.gff$To[k] - split.seq$From[j] + 1
              right = split.seq$To[j] - mRNA.gff$To[k]
              split.seq$End[j] = mRNA.gff$Start[k+1]  + right - 1
              split.seq$Left[j] = left
              split.seq$Right[j] = right
              split.seq$bridge[j] = "Yes"
            }
          }
        }
      }
      if(Strand == "-"){
        for(k in 1:nrow(mRNA.gff)){
          if(split.seq$From[j] <= mRNA.gff$To[k] & split.seq$From[j] >= mRNA.gff$From[k]){
            split.seq$Start[j] = mRNA.gff$Start[k] - split.seq$From[j] + ifelse(k >= 2, mRNA.gff$To[k-1], 0) + 1
            split.seq$gffStart1[j] = mRNA.gff$End[k]
            split.seq$gffEnd1[j] = mRNA.gff$Start[k]
            if(split.seq$To[j] <= mRNA.gff$To[k]){
              split.seq$End[j] = mRNA.gff$Start[k] - split.seq$From[j] + ifelse(k >= 2, mRNA.gff$To[k-1], 0) + 2 - window.temp
              split.seq$gffStart2[j] = mRNA.gff$End[k]
              split.seq$gffEnd2[j] = mRNA.gff$Start[k]
            }else{
                split.seq$gffStart2[j] = mRNA.gff$End[k+1]
                split.seq$gffEnd2[j] = mRNA.gff$Start[k+1]
                left = mRNA.gff$From[k+1] - split.seq$From[j]
                right = split.seq$To[j] - mRNA.gff$To[k]
                split.seq$End[j] = mRNA.gff$Start[k+1]  - right + 1
                split.seq$Left[j] = left
                split.seq$Right[j] = right
                split.seq$bridge[j] = "Yes"
              }
            }
         }
      }
    }
    split.seq = as.data.table(split.seq)
    setkeyv(split.seq, names(split.seq))

    #######
    blast.dir.temp = mRNA.blast.dir[grep(mRNA.list[i], mRNA.blast.dir)]
    blast.out = data.merging(fileList = blast.dir.temp)
    setkeyv(blast.out, names(blast.out))
    blast.out$From = NA
    blast.out$To = NA
    blast.out$Length = NA
    # j = 1
    for(j in 1:nrow(blast.out)){
      blast.out$From[j] = as.numeric(strsplit(blast.out$Query[j], "_")[[1]][9])
      blast.out$To[j] = as.numeric(strsplit(blast.out$Query[j], "_")[[1]][11])
      blast.out$Length[j] = as.numeric(blast.out$To[j]) - as.numeric(blast.out$From[j]) + 1
    }
    # blast.out[, c('From') := as.numeric(unlist(strsplit(blast.out$Query, "_"))[seq(9, nrow(blast.out)*11, by = 11)])]
    # blast.out[, c('To') := as.numeric(unlist(strsplit(blast.out$Query, "_"))[seq(11, nrow(blast.out)*11, by = 11)])]
    # blast.out[, c('Length') := To - From + 1]
    blast.out = as.data.table(blast.out)
    setkeyv(data.table(blast.out), names(blast.out))
    window = sort(unique(blast.out$Length))
    
    ## selection of overlaped primers
    overlap.select = split.seq[which(split.seq$bridge == "Yes" & split.seq$Left >= overlapMin & split.seq$Right >= overlapMin),]
    blast.select = blast.out[which(blast.out$Query %in% overlap.select$Name & blast.out$Length %in% overlap.select$Length),]
    if(nrow(blast.out) >= 1){
      overlap.select.1 = overlap.select[is.na(match(overlap.select$Name, blast.select$Query)),]
    }else{
      overlap.select.1 = overlap.select
    }
    
    if(Strand == "+"){
      overlap.select.1 = overlap.select.1[which(overlap.select.1$Start >= (min(c(mRNA.gff$Start,mRNA.gff$End)) + leftFlanking) & overlap.select.1$End <= (max(c(mRNA.gff$Start,mRNA.gff$End)) - rightFlanking)),]
    }else{
      overlap.select.1 = overlap.select.1[which(overlap.select.1$End >= (min(c(mRNA.gff$Start,mRNA.gff$End)) + rightFlanking) & overlap.select.1$Start <= (max(c(mRNA.gff$Start,mRNA.gff$End)) - leftFlanking)),]
    }
    
    overlap.select = overlap.select.1
    if(nrow(overlap.select) >= 1){
      for(j in 1:nrow(overlap.select)){
        if(overlap.select$Start[j] >= overlap.select$End[j]){
          temp = overlap.select$Start[j]
          overlap.select$Start[j] = overlap.select$End[j]
          overlap.select$End[j] = temp
        }
      }
    }else{
      cat("There is no primer identified across different exons for qRT-PCR!")
    }
    
    ## primer selection
    ## Tm filtration
    if(TmMethod == "both"){
      overall.temp1 = overall[which((overall$Tm1 >= TmScope[1] & overall$Tm1 <= TmScope[2]) | (overall$Tm2 >= TmScope[2] & overall$Tm2 <= TmScope[2])),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("\nThe TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation.\n"))
        next
      }
    }
    if(TmMethod == 1){
      overall.temp1 = overall[which(overall$Tm1 >= TmScope[1] & overall$Tm1 <= TmScope[2]),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("\nThe TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation.\n"))
        next
      }
    }
    if(TmMethod == 2){
      overall.temp1 = overall[which(overall$Tm2 >= TmScope[2] & overall$Tm2 <= TmScope[2]),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("\nThe TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation.\n"))
        next()
      }
    }
    
    ## GC content filtration
    overall.temp2 = overall.temp1[which(overall.temp1$GC.content >= GCScope[1] & overall.temp1$GC.content <= GCScope[2]),]
    if(nrow(overall.temp2) == 0){
      warning(paste0("\nThe GCScope between ", GCScope[1], " and ", GCScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation.\n"))
      next()
    }
    
    ## count filtration
    if(!is.null(countMax)){
      overall.temp3 = overall.temp2[which(overall.temp2$Counts <= countMax),]
    }else{
      overall.temp3 = overall.temp2
    }
    
    ## sequence specificity
    if(!is.null(specificityMin)){
      overall.temp4 = overall.temp3[which(overall.temp3$Seq.specificity >= specificityMin),]
    }else{
      overall.temp4 = overall.temp3
    }
    overall.temp4 = overall.temp4[order(overall.temp4$From),]
    for(j in 1:nrow(overall.temp4)){
      if(overall.temp4$From[j] >= overall.temp4$To[j]){
        temp = overall.temp4$From[j]
        overall.temp4$From[j] = overall.temp4$To[j]
        overall.temp4$To[j] = temp
      }
    }
    
    overall.temp4 = as.data.table(overall.temp4)
    setkeyv(overall.temp4, names(overall.temp4))
    if(Strand == "+"){
      overall.temp4 = overall.temp4[which(overall.temp4$From >= (min(c(mRNA.gff$Start,mRNA.gff$End)) + leftFlanking) & overall.temp4$To <= (max(c(mRNA.gff$Start,mRNA.gff$End)) - rightFlanking)),]
    }else{
      overall.temp4 = overall.temp4[which(overall.temp4$From >= (min(c(mRNA.gff$Start,mRNA.gff$End)) + rightFlanking) & overall.temp4$To <= (max(c(mRNA.gff$Start,mRNA.gff$End)) - leftFlanking)),]
    }

    fwrite(overall.temp4, file = paste0(dir.path, "/", "Designed.primers/qRT.primers/", mRNA.list[i], "_", overall$Chr[1], "_", min(c(mRNA.gff$Start,mRNA.gff$End)), "..", max(c(mRNA.gff$Start,mRNA.gff$End)), ".primers.passed.filtration.csv"), row.names = F, col.names = T, sep = "\t", na = "NA")
    
    ###################
    ## length selection
    ## overlapped primer as Forward
    if(nrow(overlap.select) >= 1 & nrow(overall.temp4) >= 1){
      length.select.1 = data.table(matrix(nrow = 0, ncol = 11))
      names(length.select.1) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
      ## overlapped primer as Reverse
      length.select.2 = data.table(matrix(nrow = 0, ncol = 11))
      names(length.select.2) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
      if(Strand == "+"){
        for(j in 1:nrow(overall.temp4)){
          for(k in 1:nrow(overlap.select)){
            distance1 = overlap.select$Start[k] - overall.temp4$To[j]
            if(distance1 >= lengthScope[1] & distance1 <= lengthScope[2]){
              temp1 = data.table(matrix(nrow = 1, ncol = 11))
              names(temp1) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
              temp1$seqName2[1] = overlap.select$Name[k]
              temp1$seq2[1] = overlap.select$Seq[k]
              temp1$seqStart2[1] = overlap.select$Start[k]
              temp1$seqEnd2[1] = overlap.select$End[k]
              temp1$primerStrand2[1] = "R"
              temp1$seqName1[1] = overall.temp4$Name[j]
              temp1$seq1[1] = overall.temp4$Seq[j]
              temp1$seqStart1[1] = overall.temp4$From[j]
              temp1$seqEnd1[1] = overall.temp4$To[j]
              temp1$primerStrand1[1] = "F"
              temp1$Distance[1] = distance1
              length.select.1 = rbind(length.select.1, temp1)
            }
            distance2 = overall.temp4$From[j] - overlap.select$End[k]
            if(distance2 >= lengthScope[1] & distance2 <= lengthScope[2]){
              temp2 = data.table(matrix(nrow = 1, ncol = 11))
              names(temp2) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
              temp2$seqName2[1] = overall.temp4$Name[j]
              temp2$seq2[1] = overall.temp4$Seq[j]
              temp2$seqStart2[1] = overall.temp4$From[j]
              temp2$seqEnd2[1] = overall.temp4$To[j]
              temp2$primerStrand2[1] = "R"
              temp2$seqName1[1] = overlap.select$Name[k]
              temp2$seq1[1] = overlap.select$Seq[k]
              temp2$seqStart1[1] = overlap.select$Start[k]
              temp2$seqEnd1[1] = overlap.select$End[k]
              temp2$primerStrand1[1] = "F"
              temp2$Distance[1] = distance2
              length.select.2 = rbind(length.select.2, temp2)
            }
          }
        }
      }
      # j = 80; k = 14
      if(Strand == "-"){
        for(j in 1:nrow(overall.temp4)){
          for(k in 1:nrow(overlap.select)){
            distance1 = overlap.select$Start[k] - overall.temp4$To[j]
            if(distance1 >= lengthScope[1] & distance1 <= lengthScope[2]){
              temp1 = data.table(matrix(nrow = 1, ncol = 11))
              names(temp1) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
              temp1$seqName2[1] = overlap.select$Name[k]
              temp1$seq2[1] = overlap.select$Seq[k]
              temp1$seqStart2[1] = overlap.select$Start[k]
              temp1$seqEnd2[1] = overlap.select$End[k]
              temp1$primerStrand2[1] = "R"
              temp1$seqName1[1] = overall.temp4$Name[j]
              temp1$seq1[1] = overall.temp4$Seq[j]
              temp1$seqStart1[1] = overall.temp4$From[j]
              temp1$seqEnd1[1] = overall.temp4$To[j]
              temp1$primerStrand1[1] = "F"
              temp1$Distance[1] = distance1
              length.select.1 = rbind(length.select.1, temp1)
            }
            distance2 = overall.temp4$From[j] - overlap.select$End[k]
            if(distance2 >= lengthScope[1] & distance2 <= lengthScope[2]){
              temp2 = data.table(matrix(nrow = 1, ncol = 11))
              names(temp2) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
              temp2$seqName2[1] = overall.temp4$Name[j]
              temp2$seq2[1] = overall.temp4$Seq[j]
              temp2$seqStart2[1] = overall.temp4$From[j]
              temp2$seqEnd2[1] = overall.temp4$To[j]
              temp2$primerStrand2[1] = "R"
              temp2$seqName1[1] = overlap.select$Name[k]
              temp2$seq1[1] = overlap.select$Seq[k]
              temp2$seqStart1[1] = overlap.select$Start[k]
              temp2$seqEnd1[1] = overlap.select$End[k]
              temp2$primerStrand1[1] = "F"
              temp2$Distance[1] = distance2
              length.select.2 = rbind(length.select.2, temp2)
            }
          }
        }
      }
      
      if(nrow(length.select.1) == 0 | nrow(length.select.2) == 0){
        warning(paste0("The lengthScope between ", lengthScope[1], " and ", lengthScope[2], " for ", mRNA.list[i], " is too stringent, please try other values for this parameter."))
        GCend.select.1 = length.select.1
        GCend.select.2 = length.select.2
      }else{
        GCend.select.1 = length.select.1
        GCend.select.2 = length.select.2
      }
      
      ## primer length filtration
      if(nrow(GCend.select.1) >= 1){
        GCend.select.1$seq1Length = nchar(GCend.select.1$seq1)
        GCend.select.1$seq2Length = nchar(GCend.select.1$seq2)
        GCend.select.1 = data.table(GCend.select.1)
        setkeyv(GCend.select.1, names(GCend.select.1))
        GCend.select.1 = GCend.select.1[which(GCend.select.1$seq1Length >= primerLength[1] & GCend.select.1$seq1Length <= primerLength[2] & GCend.select.1$seq2Length >= primerLength[1] & GCend.select.1$seq2Length <= primerLength[2]),]
        GCend.select.1 = GCend.select.1[,-c(grep('seq1Length', names(GCend.select.1)), grep('seq2Length', names(GCend.select.1)))]
      }
      if(nrow(GCend.select.2) >= 2){
        GCend.select.2$seq1Length = nchar(GCend.select.2$seq1)
        GCend.select.2$seq2Length = nchar(GCend.select.2$seq2)
        GCend.select.2 = data.table(GCend.select.2)
        setkeyv(GCend.select.2, names(GCend.select.2))
        GCend.select.2 = GCend.select.2[which(GCend.select.2$seq1Length >= primerLength[1] & GCend.select.2$seq1Length <= primerLength[2] & GCend.select.2$seq2Length >= primerLength[1] & GCend.select.2$seq2Length <= primerLength[2]),]
        GCend.select.2 = GCend.select.2[,-c(grep('seq1Length', names(GCend.select.2)), grep('seq2Length', names(GCend.select.2)))]
      }
      
      if(nrow(GCend.select.1) == 0 | nrow(GCend.select.2) == 0){
        warning(paste0("\nThe primerLenth between ", primerLength[1], " and ", primerLength[2], " for ", mRNA.list[i], " is too stringent, please try other values for this parameter.\n"))
      }else{
        GCend.select.1 = GCend.select.1
        GCend.select.2 = GCend.select.2
      }
      
      ## endMatch
      if(GCend == TRUE){
        if(nrow(GCend.select.1) >= 1){
          GCend.select.1$seq1endBase = NA
          GCend.select.1$seq2startBase = NA
          for(j in 1:nrow(GCend.select.1)){
            GCend.select.1$seq1endBase[j] = strsplit(GCend.select.1$seq1[j], "")[[1]][length(strsplit(GCend.select.1$seq1[j], "")[[1]])]
            GCend.select.1$seq2startBase[j] = strsplit(GCend.select.1$seq2[j], "")[[1]][1]
          }
          setkeyv(GCend.select.1, names(GCend.select.1))
          GCend.select.1 = GCend.select.1[which((GCend.select.1$seq1endBase == "G" | GCend.select.1$seq1endBase == "C") & (GCend.select.1$seq2startBase == "G" | GCend.select.1$seq2startBase== "C")),]
        }
      }else{
        GCend.select.1 = GCend.select.1
      }
      
      ## 
      if(GCend == TRUE){
        if(nrow(GCend.select.2) >= 1){
          GCend.select.2$seq1endBase = NA
          GCend.select.2$seq2startBase = NA
          for(j in 1:nrow(GCend.select.2)){
            GCend.select.2$seq1endBase[j] = strsplit(GCend.select.2$seq1[j], "")[[1]][length(strsplit(GCend.select.2$seq1[j], "")[[1]])]
            GCend.select.2$seq2startBase[j] = strsplit(GCend.select.2$seq2[j], "")[[1]][1]
          }
          setkeyv(GCend.select.2, names(GCend.select.2))
          GCend.select.2 = GCend.select.2[which((GCend.select.2$seq1endBase == "G" | GCend.select.2$seq1endBase == "C") & (GCend.select.2$seq2startBase == "G" | GCend.select.2$seq2startBase== "C")),]
        }
      }else{
        GCend.select.2 = GCend.select.2
      }
      
      ## reversing R primers
      if(nrow(GCend.select.1) >= 1){
        GCend.select.1$seq2 = as.character(reverseComplement(DNAStringSet(GCend.select.1$seq2)))
        names(GCend.select.1) = gsub("seq2", "revc.seq2", names(GCend.select.1))
        GCend.select.1 = GCend.select.1[,-c(12,13)]
      }
      if(nrow(GCend.select.2) >= 1){
        GCend.select.2$seq2 = as.character(reverseComplement(DNAStringSet(GCend.select.2$seq2)))
        names(GCend.select.2) = gsub("seq2", "revc.seq2", names(GCend.select.2))
        GCend.select.2 = GCend.select.2[,-c(12,13)]
      }
      
      if(nrow(GCend.select.2) >= 1 & nrow(GCend.select.1) >= 1){
        primer.select = rbind(GCend.select.1, GCend.select.2)
      }else{
        if(nrow(GCend.select.2) >= 1 & nrow(GCend.select.1) == 0){
          primer.select = GCend.select.2
        }else{
          primer.select = GCend.select.1
        }
      }
      
      if(nrow(primer.select) >= 1){
        for(j in 1:nrow(primer.select)){
          if(primer.select$seqStart1[j] >= primer.select$seqEnd1[j]){
            temp = primer.select$seqStart1[j]
            primer.select$seqStart1[j] = primer.select$seqEnd1[j]
            primer.select$seqEnd1[j] = temp
          }
          if(primer.select$seqStart2[j] >= primer.select$seqEnd2[j]){
            temp = primer.select$seqStart2[j]
            primer.select$seqStart2[j] = primer.select$seqEnd2[j]
            primer.select$seqEnd2[j] = temp
          }
        }
      }else{
        warning(paste0("\nNo primers selected for ", mRNA.list[i], "!\n"))
      }
      
      ## outputting
      fwrite(primer.select, file = paste0(dir.path, "/", "Designed.primers/qRT.primers/", mRNA.list[i], "_", overall$Chr[1], "_", min(c(mRNA.gff$Start,mRNA.gff$End)), "..", max(c(mRNA.gff$Start,mRNA.gff$End)), ".primers.final.csv"), row.names = F, col.names = T, sep = "\t", na = "NA")
      
      ## plotting
      if((plotting == TRUE | plotting == T) & nrow(primer.select) >= 1){
        SIname = strsplit(primer.select$seqName1[1], "_")[[1]][1]
        type = strsplit(primer.select$seqName1[1], "_")[[1]][2]
        chr = str_extract_all(primer.select$seqName1[1], "(Chr[0-9][0-9])")[[1]]
        Start = strsplit(strsplit(primer.select$seqName1[1], "_")[[1]][4], "\\..")[[1]][1]
        End = strsplit(strsplit(primer.select$seqName1[1], "_")[[1]][4], "\\..")[[1]][2]
        primer.select$order = seq(1:nrow(primer.select))/10
        primer.select$primerPair = paste0("Pair_", seq(1:nrow(primer.select)), "(", primer.select$Distance, "bp)")
        
        p = ggplot(primer.select, aes(x = seqStart1, y = 0.1*nrow(primer.select))) +
          labs(title = paste0(SIname, " ", type, " ", chr, ":", Start, "..", End, " qRT-PCR primers distribution")) +
          xlab(paste0(chr, ":", min(c(mRNA.gff$Start,mRNA.gff$End)), "..", max(c(mRNA.gff$Start,mRNA.gff$End)))) +
          theme(axis.ticks.y.left = element_blank(),
                axis.ticks.y = element_blank(),
                axis.line.y = element_blank(),
                axis.line.x.top = element_blank(),
                panel.grid = element_blank(),
                axis.text.y = element_blank(),
                plot.background = element_blank(),
                panel.background = element_blank(),
                axis.title.y = element_blank(),
                axis.line = element_line(colour = "black",size = 0.5))+
          xlim(c(min(c(mRNA.gff$Start,mRNA.gff$End)), max(c(mRNA.gff$Start,mRNA.gff$End)))) + ylim(c(-0.1, 0.1*nrow(primer.select) + 0.1)) +
          geom_segment(data = mRNA.gff, 
                       mapping = aes(x = Start, xend = End, y = -0.1, yend = -0.1, color = Type), 
                       #arrow = arrow(length = unit(0.1,"cm")),
                       size = 4) + 
          geom_segment(data = primer.select,
                       mapping = aes(x = seqEnd1, xend = seqStart2, y = order, yend = order),
                       size = 0.1, color = lcolor) +
          geom_segment(data = primer.select,
                       mapping = aes(x = seqStart1, xend = seqEnd1, y = order, yend = order),
                       arrow = arrow(length = unit(ifelse(nrow(primer.select) <= 2, 0.2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 0.5/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 5/nrow(primer.select), ifelse(nrow(primer.select) > 100, 10/nrow(primer.select), 10/nrow(primer.select))))),"cm")),
                       size = ifelse(nrow(primer.select) <= 2, 2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 3/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 100/nrow(primer.select), ifelse(nrow(primer.select) > 100, 120/nrow(primer.select), 200/nrow(primer.select))))), color = Fcolor) + 
          geom_segment(data = primer.select,
                       mapping = aes(x = seqEnd2, xend = seqStart2, y = order, yend = order),
                       arrow = arrow(length = unit(ifelse(nrow(primer.select) <= 2, 0.2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 0.5/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 5/nrow(primer.select), ifelse(nrow(primer.select) > 100, 10/nrow(primer.select), 10/nrow(primer.select))))),"cm")),
                       size = ifelse(nrow(primer.select) <= 2, 2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 3/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 100/nrow(primer.select), ifelse(nrow(primer.select) > 100, 120/nrow(primer.select), 200/nrow(primer.select))))), color = Rcolor) +
          geom_text(data = primer.select, mapping = aes(x = seqEnd2, y = order, label = primerPair),
                    check_overlap = TRUE, 
                    nudge_x = ifelse(nrow(primer.select) <= 2, 80, ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 75, ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 70, ifelse(nrow(primer.select) > 100, 65, 60)))), 
                    size = ifelse(nrow(primer.select) <= 2, 2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 10/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 50/nrow(primer.select), ifelse(nrow(primer.select) > 100, 80/nrow(primer.select), 100/nrow(primer.select))))))
        p = p + theme(plot.margin=unit(rep(2,4),'lines'))
        pdf(paste0(dir.path, "/", "Designed.primers/qRT.primers/", mRNA.list[i], "_", overall$Chr[1], "_", min(c(mRNA.gff$Start,mRNA.gff$End)), "..", max(c(mRNA.gff$Start,mRNA.gff$End)), ".primers.final.plot.pdf"), width = 10, height = ifelse(nrow(primer.select) <= 2, 3, ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 5, ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 10, ifelse(nrow(primer.select) > 100, 15, 20)))))
        print(p)
        dev.off()
      }
    }

###### if there is no primer identified across different exons, alternative primers would be selected.
    if((nrow(overlap.select) == 0 & nrow(overall.temp4) >= 1) | (nrow(primer.select) == 0 & nrow(overlap.select) >=1 & nrow(overall.temp4) >= 1)){
      length.select = data.table(matrix(nrow = 0, ncol = 11))
      names(length.select) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
      for(j in 1:(nrow(overall.temp4)-1)){
        for(k in (j+1):nrow(overall.temp4)){
          distance = overall.temp4$From[k] - overall.temp4$To[j]
          if(distance >= lengthScope[1] & distance <= lengthScope[2]){
            temp1 = data.table(matrix(nrow = 1, ncol = 11))
            names(temp1) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
            temp1$seqName1[1] = overall.temp4$Name[j]
            temp1$seq1[1] = overall.temp4$Seq[j]
            temp1$seqStart1[1] = overall.temp4$From[j]
            temp1$seqEnd1[1] = overall.temp4$To[j]
            temp1$primerStrand1[1] = overall.temp4$primerStrand[j]
            temp1$seqName2[1] = overall.temp4$Name[k]
            temp1$seq2[1] = overall.temp4$Seq[k]
            temp1$seqStart2[1] = overall.temp4$From[k]
            temp1$seqEnd2[1] = overall.temp4$To[k]
            temp1$primerStrand2[1] = overall.temp4$primerStrand[k]
            temp1$Distance[1] = distance
            length.select = rbind(length.select, temp1)
          }
        }
      }
      length.select = length.select[primerStrand1 != primerStrand2]
      if(nrow(length.select) == 0){
        warning(paste0("\nThe lengthScope between ", lengthScope[1], " and ", lengthScope[2], " for ", mRNA.list[i], " is too stringent, please try other values for this parameter.\n"))
        GCend.select = length.select
      }else{
        GCend.select = length.select
      }
      
      ## primer length filtration
      if(nrow(GCend.select) >= 1){
        GCend.select$seq1Length = nchar(GCend.select$seq1)
        GCend.select$seq2Length = nchar(GCend.select$seq2)
        GCend.select = GCend.select[seq1Length >= primerLength[1] & seq1Length <= primerLength[2] & seq2Length >= primerLength[1] & seq2Length <= primerLength[2]]
        if(nrow(GCend.select) == 0){
          warning(paste0("\nThe primerLenth between ", primerLength[1], " and ", primerLength[2], " for ", para.temp[1,2], " is too stringent, please try other values for this parameter.\n"))
        }else{
          GCend.select = GCend.select
        }
        GCend.select = GCend.select[,-c('seq1Length', 'seq2Length')]
      }
      
      ## endMatch
      if(GCend == TRUE & nrow(GCend.select) >= 1){
        GCend.select$seq1endBase = NA
        GCend.select$seq2startBase = NA
        for(j in 1:nrow(GCend.select)){
          GCend.select$seq1endBase[j] = strsplit(GCend.select$seq1[j], "")[[1]][length(strsplit(GCend.select$seq1[j], "")[[1]])]
          GCend.select$seq2startBase[j] = strsplit(GCend.select$seq2[j], "")[[1]][1]
        }
        setkeyv(GCend.select, names(GCend.select))
        GCend.select = GCend.select[(seq1endBase == "G" | seq1endBase == "C") & (seq2startBase == "G" | seq2startBase== "C")]
      }else{
        GCend.select = GCend.select
      }
      
      ## reversing R primers
      if(nrow(GCend.select) >= 1){
        GCend.select$seq2 = as.character(reverseComplement(DNAStringSet(GCend.select$seq2)))
        names(GCend.select) = gsub("seq2", "revc.seq2", names(GCend.select))
        GCend.select = GCend.select[,-c(12,13)]
        fwrite(GCend.select, file = paste0(dir.path, "/", "Designed.primers/qRT.primers/", mRNA.list[i], "_", overall$Chr[1], "_", min(c(mRNA.gff$Start,mRNA.gff$End)), "..", max(c(mRNA.gff$Start,mRNA.gff$End)), ".primers.final.csv"), row.names = F, col.names = T, sep = "\t", na = "NA")
      }
      
      ## plotting
      if((plotting == TRUE | plotting == T) & nrow(GCend.select) >= 1){
        SIname = strsplit(GCend.select$seqName1[1], "_")[[1]][1]
        type = strsplit(GCend.select$seqName1[1], "_")[[1]][2]
        chr = str_extract_all(GCend.select$seqName1[1], "(Chr[0-9][0-9])")[[1]]
        Start = strsplit(strsplit(GCend.select$seqName1[1], "_")[[1]][4], "\\..")[[1]][1]
        End = strsplit(strsplit(GCend.select$seqName1[1], "_")[[1]][4], "\\..")[[1]][2]
        GCend.select$order = seq(1:nrow(GCend.select))/10
        GCend.select$primerPair = paste0("Pair_", seq(1:nrow(GCend.select)), "(", GCend.select$Distance, "bp)")
      
        p = ggplot(primer.select, aes(x = seqStart1, y = 0.1*nrow(primer.select))) +
          labs(title = paste0(SIname, " ", type, " ", chr, ":", Start, "..", End, " qRT-PCR primers distribution")) +
          xlab(paste0(chr, ":", min(c(mRNA.gff$Start,mRNA.gff$End)), "..", max(c(mRNA.gff$Start,mRNA.gff$End)))) +
          theme(axis.ticks.y.left = element_blank(),
                axis.ticks.y = element_blank(),
                axis.line.y = element_blank(),
                axis.line.x.top = element_blank(),
                panel.grid = element_blank(),
                axis.text.y = element_blank(),
                plot.background = element_blank(),
                panel.background = element_blank(),
                axis.title.y = element_blank(),
                axis.line = element_line(colour = "black",size = 0.5))+
          xlim(c(min(c(mRNA.gff$Start,mRNA.gff$End)), max(c(mRNA.gff$Start,mRNA.gff$End)))) + ylim(c(-0.1, 0.1*nrow(primer.select) + 0.1)) +
          geom_segment(data = mRNA.gff, 
                       mapping = aes(x = Start, xend = End, y = -0.1, yend = -0.1, color = Type), 
                       size = 4) + 
          geom_segment(data = primer.select,
                       mapping = aes(x = seqEnd1, xend = seqStart2, y = order, yend = order),
                       size = 0.1, color = lcolor) +
          geom_segment(data = primer.select,
                       mapping = aes(x = seqStart1, xend = seqEnd1, y = order, yend = order),
                       arrow = arrow(length = unit(ifelse(nrow(primer.select) <= 2, 0.2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 0.5/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 5/nrow(primer.select), ifelse(nrow(primer.select) > 100, 10/nrow(primer.select), 10/nrow(primer.select))))),"cm")),
                       size = ifelse(nrow(primer.select) <= 2, 2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 3/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 100/nrow(primer.select), ifelse(nrow(primer.select) > 100, 120/nrow(primer.select), 200/nrow(primer.select))))), color = Fcolor) + 
          geom_segment(data = primer.select,
                       mapping = aes(x = seqEnd2, xend = seqStart2, y = order, yend = order),
                       arrow = arrow(length = unit(ifelse(nrow(primer.select) <= 2, 0.2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 0.5/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 5/nrow(primer.select), ifelse(nrow(primer.select) > 100, 10/nrow(primer.select), 10/nrow(primer.select))))),"cm")),
                       size = ifelse(nrow(primer.select) <= 2, 2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 3/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 100/nrow(primer.select), ifelse(nrow(primer.select) > 100, 120/nrow(primer.select), 200/nrow(primer.select))))), color = Rcolor) +
          geom_text(data = primer.select, mapping = aes(x = seqEnd2, y = order, label = primerPair),
                    check_overlap = TRUE, 
                    nudge_x = ifelse(nrow(primer.select) <= 2, 80, ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 75, ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 70, ifelse(nrow(primer.select) > 100, 65, 60)))), 
                    size = ifelse(nrow(primer.select) <= 2, 10/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 50/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 100/nrow(primer.select), ifelse(nrow(primer.select) > 100, 120/nrow(primer.select), 200/nrow(primer.select))))))
        p = p + theme(plot.margin=unit(rep(2,4),'lines'))
        pdf(paste0(dir.path, "/", "Designed.primers/qRT.primers/", mRNA.list[i], "_", overall$Chr[1], "_", min(c(mRNA.gff$Start,mRNA.gff$End)), "..", max(c(mRNA.gff$Start,mRNA.gff$End)), ".primers.final.plot.pdf"), width = 10, height = ifelse(nrow(primer.select) <= 2, 3, ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 5, ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 10, ifelse(nrow(primer.select) > 100, 15, 20)))))
        print(p)
        dev.off()
        }
      }
  }
  #cat("\n primer.designing.for.qRT.PCT is DONE!")
}
  
  
  
