

#' This is some description of this function.
#' @title to design primers for SNP- or indel- based marker development.
#'
#' @description By using this package, you could use function of primer.designing.pipeline.for.SNP.and.indel.markers to design primers for SNP- or indel- based marker development.
#'
#' @details see above
#'
#' @param SNPFile: SNP locus file, including at least 'Fragment.ID', 'Chr', 'Start', 'End', 'Strand', 'Length', 'leftFlanking', 'rightFlanking', of which 'Fragment.ID', 'Chr', 'Start' and 'End' are required to be specified. The program would assign default value of '+', 'end - start', 200, and 200 for 'Strand', 'Length', 'leftFlanking', and 'rightFlanking' respectively. This file could be in format of *.csv, .txt, .xlsx, if .xlsx format was used parameters should be put in 'Sheet1' as default.
#' @param IndelFile: 
#' @param type: string to indiate SNP or Indel, varied format is also accepted, e.g. snp, SNP, indel, Indel, and INDEL
#' @param database: folder or file contains genome sequence in fasta format
#' @param lociName: string to specify the name of a SNP or Indel, when input file was missed, 'lociName' is reuquired.
#' @param chr: string or numeric value indicates specific chromosome, when input file was missed, 'chr' is reuquired.
#' @param start: numeric value indicates the start position of Indel, when input file was missed, 'start' is reuquired.
#' @param end: numeric value indicates the end position of Indel, when input file was missed, 'end' is reuquired.
#' @param pos: numeric value indicates the position of SNP, when input file was missed, 'pos' is reuquired.
#' @param leftFlanking: numeric value indicates left flanking region of SNP or Indel, default value is 200bp.
#' @param rightFlanking: numeric value indicates right flanking region of SNP or Indel, default value is 200bp.
#' @param inputFile: parameter setting file in '.csv' or '.xlsx' format. it should contains Type	Name	Chr	Start	End	Strand	Primer_strand	Flanking.left.bp	Flanking.right.bp	Expected.amplicon.length.bp	Aiming	Primer.name	Primer.length.bp	Tm.expected	GC.content	Sequence.specificity.min, details could be found in example input file.
#' @param database: folder contains genome sequence in fasta format
#' @param stepWise: numeric value to indicate stepWise of windows, default value is 3.
#' @param windowSize: numeric value to indicate scope of window size, could be a single number, e.g. 23, or a range, e.g. c(20,25). Default value is c(20, 25)
#' @param blastDir: the path to the local blast.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param specificityMin: numeric value to indicate the min value of sequence specificity to signify on the diagnostic plot.
#' @param nthreads: numeric value to indicate how many threads used in the analysis, default is 2
#' @param Evalue: numeric value to indicate e-value threshold in local-blast, default is 0.1 (1e-1)
#' @param outFormat: numeric value to specify -outfmt parameter in local blast, default is 6.
#' @param GCShow: logical value. whether to show GC content on the diagnostic plot, default is TRUE
#' @param TmShow: logical value.whether to show Tm value on the diagnostic plot, default is TRUE
#' @param specificiyShow: logical value.whether to show sequence specificity value on the diagnostic plot, default is TRUE
#' @param countShow: logical value.whether to show Counts on the diagnostic plot, default is TRUE
#' @param countMax: numeric value to indicates the maximum counts threshold, by which fragment to be displayed with dashed line.
#' @param segmentLinetype: numeric value indicates which line type to be used. It is inherited from basic line types in the R.
#' @param segmentColor: string indicate the color of geom_segment(), which represent fragment sequence on the chromosome in terms of location.
#' @param segmentSize: numeric value indicates line size of geom_segment(), default value is 0.2
#' @param pointShape: numeric value indicates point shape in geom_point(), default value for pointShape1 and pointShape2 are 19 and 24 respectively.
#' @param pointColor: string indicates color of geom_point(), default value for pointColor1 and pointColor2 are 'red' and 'blue' respectively.
#' @param pointSize: numeric value indicates point size in geom_point(), default value for pointSize, pointSize1, and pointSize2 are 0.5, 0.5, and 0.5 respectively.
#' @param hlineType: numeric value indicates line type in geom_hline(), default value is 2.
#' @param hlineColor: string indicates line color in geom_hline(), default value is 'blue'
#' @param hlineSize: numeric value indicates line size, default value is 0.3.
#' @param pdfWidth: numeric value indicates width of pdf file, default value is 16.
#' @param pdfHeight: numeric value indicates height of pdf file, default value is 10.
#' @param seqEvaluation: seqEvaluation folder.
#' @param plotting: logical value indicates whether to plot primers or not.
#' @param TmScope: numeric scope indicates the min and max of primer Tm, default value is 'c(40, 60)'.
#' @param GCScope: numeric scope indicates the min and max of primer GC content (%), default value is 'c(35, 65)'.
#' @param specificityMin: numeric value indicates the minimum standard of sequence specificity (%), default value is 98%.
#' @param countMax: numeric value indicates the maximum standard of counts of this primer mathched to different position on the chromosome, default value is 2.
#' @param endMatch: logical value indicates whether the primer end (3') matched to genome, default value is TRUE
#' @param GCend: logical value indicates whether the primer end (3') should be G:C or not, default value is TRUE
#' @param lengthScope: numeric scope indicates the expected min and max amplicon length of primer pairs, default value is 'c(70, 150)'.
#' @param primerLength: numeric scope indicates the min and max length of primer, default value is 'c(20, 25)'.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param primerStrand: 'F' or 'R', or c('F', 'R')
#' @param Fcolor: color value for forward primers, default is "#B2182B".
#' @param Rcolor: color value for reverse primers, default is "#2166AC".
#' @param lcolor: color value for line connecting forward and reverse primer pairs, default is 'black'.
#' @param rectFill: color value for rect shade indicating the position of SNP or Indel, default is '#FF3300'.
#' @return files and folder
#' @export primer.designing.pipeline.for.SNP.and.Indel.markers
#' @examples primer.designing.pipeline.for.SNP.and.Indel.markers(database = "./soybean.genome/", IndelFile = "./IndelList.xlsx", blastDir = "./ncbi-blast-2.12.0+/")
#' 
#' 

#primer.designing.pipeline.for.SNP.and.Indel.markers(database = "./soybean.genome/", lociName = "Indel3", type = "Indel", chr = 8, pos = 12345, start = 13246, end = 13248, blastDir = "./ncbi-blast-2.12.0+/")

#primer.designing.pipeline.for.SNP.and.Indel.markers(database = "./soybean.genome/", SNPFile = "./SNPList.xlsx", blastDir = "./ncbi-blast-2.12.0+/")

#primer.designing.pipeline.for.SNP.and.Indel.markers(database = "./soybean.genome/", IndelFile = "./IndelList.xlsx", blastDir = "./ncbi-blast-2.12.0+/")

primer.designing.pipeline.for.SNP.and.Indel.markers = function(database = NULL, SNPFile = NULL, IndelFile = NULL, seqType = NULL, type = NULL, lociName = NULL, chr = NULL, start = NULL, end = NULL, pos = NULL, leftFlanking = NULL, rightFlanking = NULL, inputFile = NULL, blastDir = NULL, windowSize = NULL, stepWise = NULL, TmMethod = NULL, specificityMin = NULL, nthreads = NULL, Evalue = NULL, GCShow = NULL, TmShow = NULL, specificiyShow = NULL, countShow = NULL, TmScope = NULL, GCScope = NULL, countMax = NULL, segmentLinetype = NULL, segmentColor = NULL, segmentSize = NULL, pointShape1 = NULL, pointShape2 = NULL, pointColor1 = NULL, pointColor2 = NULL, pointSize = NULL, pointSize1 = NULL, pointSize2 = NULL, hlineType = NULL, hlineColor = NULL, hlineSize = NULL, pdfWidth = NULL, pdfHeight = NULL, outFormat = NULL, seqEvaluation = NULL, plotting = NULL, endMatch = NULL, GCend = NULL, lengthScope = NULL, primerLength = NULL, primerStrand = NULL, Fcolor = NULL, Rcolor = NULL, lcolor = NULL, rectFill = NULL, ...){
  
  library(data.table)
  library(xlsx)
  dir.path = getwd()
  
  if(!is.null(SNPFile)){
    if(is.null(seqType)) seqType = "SNP"
    if(is.null(type)) type = "SNP"
    SNP.and.Indel.flanking.seq.extraction(database = database, SNPFile = SNPFile, IndelFile = IndelFile, type = type, lociName = lociName, chr = chr, start = start, end = end, pos = pos, leftFlanking = leftFlanking, rightFlanking = rightFlanking)
    if(length(grep(".csv|.txt", SNPFile)) == 1){
      SNP = fread(SNPFile, header = T, stringsAsFactors = F, fill = T, sep = "\t")
      if(ncol(SNP) == 1){
        SNP = fread(SNPFile, header = T, stringsAsFactors = F, fill = T, sep = ",")
        if(ncol(SNP) == 1){
          SNP = fread(SNPFile, header = T, stringsAsFactors = F, fill = T, sep = " ")
        }
      }
    }
    if(length(grep(".xlsx|.xls", SNPFile)) == 1){
      SNP = as.data.table(read.xlsx(SNPFile, header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
    }
    SNPList = list.files("./Sequence.extraction/SNP/")
    SNPList = paste0("./Sequence.extraction/SNP/", SNPList)
    for(i in 1:nrow(SNP)){
      SNPName = SNP$SNP.Name[i]
      if(length(grep("^Chr$", names(SNP))) == 1 & !is.na(SNP$Chr[i]))  chr = SNP$Chr[i]
      if(length(grep("^Pos$", names(SNP))) == 1 & !is.na(SNP$Pos[i]))  pos = SNP$Pos[i]
      if(length(grep("^rectFill$", names(SNP))) == 1 & !is.na(SNP$rectFill[i]))  type = SNP$rectFill[i]
      if(length(grep("^leftFlanking$", names(SNP))) == 1 & !is.na(SNP$leftFlanking[i]))  leftFlanking = SNP$leftFlanking[i]
      if(length(grep("^rightFlanking$", names(SNP))) == 1 & !is.na(SNP$rightFlanking[i]))  rightFlanking = SNP$rightFlanking[i]
      if(length(grep("^windowSize$", names(SNP))) == 1 & !is.na(SNP$windowSize[i]))  windowSize = SNP$windowSize[i]
      if(length(grep("^stepWise$", names(SNP))) == 1 & !is.na(SNP$stepWise[i]))  stepWise = SNP$stepWise[i]
      if(length(grep("^TmMethod$", names(SNP))) == 1 & !is.na(SNP$TmMethod[i]))  TmMethod = SNP$TmMethod[i]
      if(length(grep("^specificityMin$", names(SNP))) == 1 & !is.na(SNP$specificityMin[i]))  specificityMin = SNP$specificityMin[i]
      if(length(grep("^nthreads$", names(SNP))) == 1 & !is.na(SNP$nthreads[i]))  nthreads = SNP$nthreads[i]
      if(length(grep("^Evalue$", names(SNP))) == 1 & !is.na(SNP$Evalue[i]))  Evalue = SNP$Evalue[i]
      if(length(grep("^GCShow$", names(SNP))) == 1 & !is.na(SNP$GCShow[i]))  GCShow = SNP$GCShow[i]
      if(length(grep("^TmShow$", names(SNP))) == 1 & !is.na(SNP$TmShow[i]))  TmShow = SNP$TmShow[i]
      if(length(grep("^specificiyShow$", names(SNP))) == 1 & !is.na(SNP$specificiyShow[i]))  specificiyShow = SNP$specificiyShow[i]
      if(length(grep("^countShow$", names(SNP))) == 1 & !is.na(SNP$countShow[i]))  countShow = SNP$countShow[i]
      if(length(grep("^TmScope$", names(SNP))) == 1 & !is.na(SNP$TmScope[i]))  TmScope = SNP$TmScope[i]
      if(length(grep("^GCScope$", names(SNP))) == 1 & !is.na(SNP$GCScope[i]))  GCScope = SNP$GCScope[i]
      if(length(grep("^countMax$", names(SNP))) == 1 & !is.na(SNP$countMax[i]))  countMax = SNP$countMax[i]
      if(length(grep("^segmentLinetype$", names(SNP))) == 1 & !is.na(SNP$segmentLinetype[i]))  segmentLinetype = SNP$segmentLinetype[i]
      if(length(grep("^segmentColor$", names(SNP))) == 1 & !is.na(SNP$segmentColor[i]))  segmentColor = SNP$segmentColor[i]
      if(length(grep("^segmentSize$", names(SNP))) == 1 & !is.na(SNP$segmentSize[i]))  segmentSize = SNP$segmentSize[i]
      if(length(grep("^pointShape1$", names(SNP))) == 1 & !is.na(SNP$pointShape1[i]))  pointShape1 = SNP$pointShape1[i]
      if(length(grep("^pointShape2$", names(SNP))) == 1 & !is.na(SNP$pointShape2[i]))  pointShape2 = SNP$pointShape2[i]
      if(length(grep("^pointColor1$", names(SNP))) == 1 & !is.na(SNP$pointColor1[i]))  pointColor1 = SNP$pointColor1[i]
      if(length(grep("^pointColor2$", names(SNP))) == 1 & !is.na(SNP$pointColor2[i]))  pointColor2 = SNP$pointColor2[i]
      if(length(grep("^pointSize$", names(SNP))) == 1 & !is.na(SNP$pointSize[i]))  pointSize = SNP$pointSize[i]
      if(length(grep("^pointSize1$", names(SNP))) == 1 & !is.na(SNP$pointSize1[i]))  pointSize1 = SNP$pointSize1[i]
      if(length(grep("^pointSize2$", names(SNP))) == 1 & !is.na(SNP$pointSize2[i]))  pointSize2 = SNP$pointSize2[i]
      if(length(grep("^hlineType$", names(SNP))) == 1 & !is.na(SNP$hlineType[i]))  hlineType = SNP$hlineType[i]
      if(length(grep("^hlineColor$", names(SNP))) == 1 & !is.na(SNP$hlineColor[i]))  hlineColor = SNP$hlineColor[i]
      if(length(grep("^hlineSize$", names(SNP))) == 1 & !is.na(SNP$hlineSize[i]))  hlineSize = SNP$hlineSize[i]
      if(length(grep("^pdfWidth$", names(SNP))) == 1 & !is.na(SNP$pdfWidth[i]))  pdfWidth = SNP$pdfWidth[i]
      if(length(grep("^pdfHeight$", names(SNP))) == 1 & !is.na(SNP$pdfHeight[i]))  pdfHeight = SNP$pdfHeight[i]
      if(length(grep("^outFormat$", names(SNP))) == 1 & !is.na(SNP$outFormat[i]))  outFormat = SNP$outFormat[i]
      if(length(grep("^plotting$", names(SNP))) == 1 & !is.na(SNP$plotting[i]))  plotting = SNP$plotting[i]
      if(length(grep("^endMatch$", names(SNP))) == 1 & !is.na(SNP$endMatch[i]))  endMatch = SNP$endMatch[i]
      if(length(grep("^GCend$", names(SNP))) == 1 & !is.na(SNP$GCend[i]))  type = SNP$GCend[i]
      if(length(grep("^primerLength$", names(SNP))) == 1 & !is.na(SNP$primerLength[i]))  primerLength = SNP$primerLength[i]
      if(length(grep("^primerStrand$", names(SNP))) == 1 & !is.na(SNP$primerStrand[i]))  primerStrand = SNP$primerStrand[i]
      if(length(grep("^Fcolor$", names(SNP))) == 1 & !is.na(SNP$Fcolor[i]))  Fcolor = SNP$Fcolor[i]
      if(length(grep("^Rcolor$", names(SNP))) == 1 & !is.na(SNP$Rcolor[i]))  Rcolor = SNP$Rcolor[i]
      if(length(grep("^lcolor$", names(SNP))) == 1 & !is.na(SNP$lcolor[i]))  lcolor = SNP$lcolor[i]
      if(length(grep("^leftRegion$", names(SNP))) == 1 & !is.na(SNP$leftRegion[i]))  leftRegion = SNP$leftRegion[i]
      if(length(grep("^rightRegion$", names(SNP))) == 1 & !is.na(SNP$rightRegion[i]))  rightRegion = SNP$rightRegion[i]
      
      inputFile = paste0("./Sequence.extraction/SNP/", SNPName, "/")
      if(file.exists(inputFile)){
        seq.evaluation(database = database, inputFile = inputFile, blastDir = blastDir, seqType = seqType, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
        cat(paste0("\nSequence evaluation of ", SNPName, " is DONE!\n"))
        seqEvaluation = paste0("./Sequence.evaluation/SNP/", SNPName, "/")
        if(file.exists(seqEvaluation)){
          primer.designing.for.SNP.and.Indel.markers(seqEvaluation = seqEvaluation, seqType = seqType, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend =  GCend, lengthScope = lengthScope, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, rectFill = rectFill)
          cat(paste0("\nPrimer desgining of ", SNPName, " for SNP marker development is DONE!\n"))
        }else{
          warning(paste0("\n", SNPName, " does not exist in ./Sequence.evaluation/SNP/\n"))
          next
        }
      }else{
        warning(paste0("\n", SNPName, " does not exist in ./Sequence.extraction/SNP/\n"))
        next
      }
    }
  }
  if(!is.null(IndelFile)){
    if(is.null(seqType)) seqType = "Indel"
    if(is.null(type)) type = "Indel"
    SNP.and.Indel.flanking.seq.extraction(database = database, SNPFile = SNPFile, IndelFile = IndelFile, type = type, lociName = lociName, chr = chr, start = start, end = end, pos = pos, leftFlanking = leftFlanking, rightFlanking = rightFlanking)
    if(length(grep(".csv|.txt", SNPFile)) == 1){
      Indel = fread(IndelFile, header = T, stringsAsFactors = F, fill = T, sep = "\t")
      if(ncol(Indel) == 1){
        Indel = fread(IndelFile, header = T, stringsAsFactors = F, fill = T, sep = ",")
        if(ncol(Indel) == 1){
          Indel = fread(IndelFile, header = T, stringsAsFactors = F, fill = T, sep = " ")
        }
      }
    }
    if(length(grep(".xlsx|.xls", IndelFile)) == 1){
      Indel = as.data.table(read.xlsx(IndelFile, header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
    }
    IndelList = list.files("./Sequence.extraction/Indel/")
    IndelList = paste0("./Sequence.extraction/Indel/", IndelList)
    for(i in 1:nrow(Indel)){
      IndelName = Indel$Indel.Name[i]
      if(length(grep("^Chr$", names(Indel))) == 1 & !is.na(Indel$Chr[i]))  chr = Indel$Chr[i]
      if(length(grep("^Start$", names(Indel))) == 1 & !is.na(Indel$Start[i]))  start = Indel$Start[i]
      if(length(grep("^End$", names(Indel))) == 1 & !is.na(Indel$End[i]))  end = Indel$End[i]
      if(length(grep("^rectFill$", names(Indel))) == 1 & !is.na(Indel$rectFill[i]))  type = Indel$rectFill[i]
      if(length(grep("^leftFlanking$", names(Indel))) == 1 & !is.na(Indel$leftFlanking[i]))  leftFlanking = Indel$leftFlanking[i]
      if(length(grep("^rightFlanking$", names(Indel))) == 1 & !is.na(Indel$rightFlanking[i]))  rightFlanking = Indel$rightFlanking[i]
      if(length(grep("^windowSize$", names(Indel))) == 1 & !is.na(Indel$windowSize[i]))  windowSize = Indel$windowSize[i]
      if(length(grep("^stepWise$", names(Indel))) == 1 & !is.na(Indel$stepWise[i]))  stepWise = Indel$stepWise[i]
      if(length(grep("^TmMethod$", names(Indel))) == 1 & !is.na(Indel$TmMethod[i]))  TmMethod = Indel$TmMethod[i]
      if(length(grep("^specificityMin$", names(Indel))) == 1 & !is.na(Indel$specificityMin[i]))  specificityMin = Indel$specificityMin[i]
      if(length(grep("^nthreads$", names(Indel))) == 1 & !is.na(Indel$nthreads[i]))  nthreads = Indel$nthreads[i]
      if(length(grep("^Evalue$", names(Indel))) == 1 & !is.na(Indel$Evalue[i]))  Evalue = Indel$Evalue[i]
      if(length(grep("^GCShow$", names(Indel))) == 1 & !is.na(Indel$GCShow[i]))  GCShow = Indel$GCShow[i]
      if(length(grep("^TmShow$", names(Indel))) == 1 & !is.na(Indel$TmShow[i]))  TmShow = Indel$TmShow[i]
      if(length(grep("^specificiyShow$", names(Indel))) == 1 & !is.na(Indel$specificiyShow[i]))  specificiyShow = Indel$specificiyShow[i]
      if(length(grep("^countShow$", names(Indel))) == 1 & !is.na(Indel$countShow[i]))  countShow = Indel$countShow[i]
      if(length(grep("^TmScope$", names(Indel))) == 1 & !is.na(Indel$TmScope[i]))  TmScope = Indel$TmScope[i]
      if(length(grep("^GCScope$", names(Indel))) == 1 & !is.na(Indel$GCScope[i]))  GCScope = Indel$GCScope[i]
      if(length(grep("^countMax$", names(Indel))) == 1 & !is.na(Indel$countMax[i]))  countMax = Indel$countMax[i]
      if(length(grep("^segmentLinetype$", names(Indel))) == 1 & !is.na(Indel$segmentLinetype[i]))  segmentLinetype = Indel$segmentLinetype[i]
      if(length(grep("^segmentColor$", names(Indel))) == 1 & !is.na(Indel$segmentColor[i]))  segmentColor = Indel$segmentColor[i]
      if(length(grep("^segmentSize$", names(Indel))) == 1 & !is.na(Indel$segmentSize[i]))  segmentSize = Indel$segmentSize[i]
      if(length(grep("^pointShape1$", names(Indel))) == 1 & !is.na(Indel$pointShape1[i]))  pointShape1 = Indel$pointShape1[i]
      if(length(grep("^pointShape2$", names(Indel))) == 1 & !is.na(Indel$pointShape2[i]))  pointShape2 = Indel$pointShape2[i]
      if(length(grep("^pointColor1$", names(Indel))) == 1 & !is.na(Indel$pointColor1[i]))  pointColor1 = Indel$pointColor1[i]
      if(length(grep("^pointColor2$", names(Indel))) == 1 & !is.na(Indel$pointColor2[i]))  pointColor2 = Indel$pointColor2[i]
      if(length(grep("^pointSize$", names(Indel))) == 1 & !is.na(Indel$pointSize[i]))  pointSize = Indel$pointSize[i]
      if(length(grep("^pointSize1$", names(Indel))) == 1 & !is.na(Indel$pointSize1[i]))  pointSize1 = Indel$pointSize1[i]
      if(length(grep("^pointSize2$", names(Indel))) == 1 & !is.na(Indel$pointSize2[i]))  pointSize2 = Indel$pointSize2[i]
      if(length(grep("^hlineType$", names(Indel))) == 1 & !is.na(Indel$hlineType[i]))  hlineType = Indel$hlineType[i]
      if(length(grep("^hlineColor$", names(Indel))) == 1 & !is.na(Indel$hlineColor[i]))  hlineColor = Indel$hlineColor[i]
      if(length(grep("^hlineSize$", names(Indel))) == 1 & !is.na(Indel$hlineSize[i]))  hlineSize = Indel$hlineSize[i]
      if(length(grep("^pdfWidth$", names(Indel))) == 1 & !is.na(Indel$pdfWidth[i]))  pdfWidth = Indel$pdfWidth[i]
      if(length(grep("^pdfHeight$", names(Indel))) == 1 & !is.na(Indel$pdfHeight[i]))  pdfHeight = Indel$pdfHeight[i]
      if(length(grep("^outFormat$", names(Indel))) == 1 & !is.na(Indel$outFormat[i]))  outFormat = Indel$outFormat[i]
      if(length(grep("^plotting$", names(Indel))) == 1 & !is.na(Indel$plotting[i]))  plotting = Indel$plotting[i]
      if(length(grep("^endMatch$", names(Indel))) == 1 & !is.na(Indel$endMatch[i]))  endMatch = Indel$endMatch[i]
      if(length(grep("^GCend$", names(Indel))) == 1 & !is.na(Indel$GCend[i]))  type = Indel$GCend[i]
      if(length(grep("^primerLength$", names(Indel))) == 1 & !is.na(Indel$primerLength[i]))  primerLength = Indel$primerLength[i]
      if(length(grep("^primerStrand$", names(Indel))) == 1 & !is.na(Indel$primerStrand[i]))  primerStrand = Indel$primerStrand[i]
      if(length(grep("^Fcolor$", names(Indel))) == 1 & !is.na(Indel$Fcolor[i]))  Fcolor = Indel$Fcolor[i]
      if(length(grep("^Rcolor$", names(Indel))) == 1 & !is.na(Indel$Rcolor[i]))  Rcolor = Indel$Rcolor[i]
      if(length(grep("^lcolor$", names(Indel))) == 1 & !is.na(Indel$lcolor[i]))  lcolor = Indel$lcolor[i]
      if(length(grep("^leftRegion$", names(Indel))) == 1 & !is.na(Indel$leftRegion[i]))  leftRegion = Indel$leftRegion[i]
      if(length(grep("^rightRegion$", names(Indel))) == 1 & !is.na(Indel$rightRegion[i]))  rightRegion = Indel$rightRegion[i]
      
      inputFile = paste0("./Sequence.extraction/Indel/", IndelName, "/")
      if(file.exists(inputFile)){
        seq.evaluation(database = database, inputFile = inputFile, blastDir = blastDir, seqType = seqType, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
        cat(paste0("\nSequence evaluation of ", IndelName, " is DONE!\n"))
        seqEvaluation = paste0("./Sequence.evaluation/Indel/", IndelName, "/")
        if(file.exists(seqEvaluation)){
          primer.designing.for.SNP.and.Indel.markers(seqEvaluation = seqEvaluation, seqType = seqType, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend =  GCend, lengthScope = lengthScope, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, rectFill = rectFill)
          cat(paste0("\nPrimer desgining of ", IndelName, " for Indel marker development is DONE!\n"))
        }else{
          warning(paste0("\n", SNPName, " does not exist in ./Sequence.evaluation/Indel/\n"))
          next
        }
      }else{
        warning(paste0("\n", SNPName, " does not exist in ./Sequence.extraction/Indel/\n"))
        next
      }
    }
  }
  if(is.null(IndelFile) & is.null(SNPFile) & !is.null(lociName)){
    if(is.null(type)) stop("\n'type' is required when NO SNPFile, NO IndelFile, and lociName as input!\n")
    if(type == "SNP" | type == "snp"){
      seqType = "SNP"
    }
    if(type == "Indel" | type == "indel" | type == "INDEL"){
      seqType = "Indel"
    }
    SNP.and.Indel.flanking.seq.extraction(database = database, SNPFile = SNPFile, IndelFile = IndelFile, type = type, lociName = lociName, chr = chr, start = start, end = end, pos = pos, leftFlanking = leftFlanking, rightFlanking = rightFlanking)
    LocusName = lociName
    inputFile = paste0("./Sequence.extraction/", seqType, "/", LocusName, "/")
    if(file.exists(inputFile)){
      seq.evaluation(database = database, inputFile = inputFile, blastDir = blastDir, seqType = seqType, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
      cat(paste0("\nSequence evaluation of ", LocusName, " is DONE!\n"))
      seqEvaluation = paste0("./Sequence.evaluation/", seqType, "/", LocusName, "/")
      if(file.exists(seqEvaluation)){
        primer.designing.for.SNP.and.Indel.markers(seqEvaluation = seqEvaluation, seqType = seqType, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend =  GCend, lengthScope = lengthScope, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, rectFill = rectFill)
        cat(paste0("\nPrimer designing of ", LocusName, " for ", seqType, " is DONE!\n"))
      }else{
        warning(paste0("\n", LocusName, " does not exist in ./Sequence.evaluation/", LocusName, "/\n"))
      }
    }else{
      warning(paste0("\n", LocusName, " does not exist in ./Sequence.extraction/", LocusName, "/\n"))
    }
  }
  cat(paste0("\nPrimer designing of ", ifelse(!is.null(SNPFile), SNPFile, ifelse(!is.null(IndelFile), IndelFile, lociName)), " for SNP and Indel marker development is/are ALL DONE!\n"))
}


