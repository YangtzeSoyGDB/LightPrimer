

#' This is some description of this function.
#' @title to create essential folders and template files. 
#'
#' @description By using this package, you could use function of LightPrimer.preparation to create essential folders(./Sequence.extraction, ./Sequence.valuation, ./Designed.primers, ./Input.files, ./gff.file) and template files (GeneList.template.csv, FragmentList.template.csv, IndelList.template.csv, SNPList.template.csv, Template.Instruction.txt). 
#' @details see above
#'
#' @param folderCreation: logical value indicates whether to create essential folder or not, default is TRUE.
#' @param templateCreation: logical value indicates whether to create template files or not, default is TRUE.
#' @return files and folders
#' @export LightPrimer.preparation
#' @examples LightPrimer.preparation()


LightPrimer.preparation = function(folderCreation = NULL, templateCreation = NULL){
  
  library(data.table)
  library(xlsx)
  if(is.null(folderCreation)) folderCreation = TRUE
  if(is.null(templateCreation)) templateCreation = TRUE
  dir.path = getwd()
  
  if(folderCreation == TRUE){
    if(!dir.exists(paste0(dir.path, "/", "Input.files/"))){
      dir.create(paste0(dir.path, "/", "Input.files/"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Basic.files/"))){
      dir.create(paste0(dir.path, "/", "Basic.files/"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Basic.files/gff.file/"))){
      dir.create(paste0(dir.path, "/", "Basic.files/gff.file/"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Basic.files/Genome/"))){
      dir.create(paste0(dir.path, "/", "Basic.files/Genome/"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/"))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/Fragment"))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/Fragment"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/Gene"))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/Gene"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/SNP"))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/SNP"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/Indel"))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/Indel"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/"))){
      dir.create(paste0(dir.path, "/", "Sequence.evaluation/"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/Fragment"))){
      dir.create(paste0(dir.path, "/", "Sequence.evaluation/Fragment"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/Gene"))){
      dir.create(paste0(dir.path, "/", "Sequence.evaluation/Gene"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/SNP"))){
      dir.create(paste0(dir.path, "/", "Sequence.evaluation/SNP"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/Indel"))){
      dir.create(paste0(dir.path, "/", "Sequence.evaluation/Indel"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Designed.primers/"))){
      dir.create(paste0(dir.path, "/", "Designed.primers/"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Designed.primers/Cloning.primers"))){
      dir.create(paste0(dir.path, "/", "Designed.primers/Cloning.primers"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Designed.primers/qRT.primers"))){
      dir.create(paste0(dir.path, "/", "Designed.primers/qRT.primers"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Designed.primers/SNP.and.Indel.primers"))){
      dir.create(paste0(dir.path, "/", "Designed.primers/SNP.and.Indel.primers"))
    }
  }
  
  sink(file = paste0(dir.path, "/Input.files/Template.Instruction.txt"), type = "output", append = T)
  writeLines("\n#########  LightPrimer  #########\n")
  writeLines("VERSION: LightPrimer_0.0.0.1")
  writeLines(paste0("DATE: ", date()))
  writeLines("CITATION: \n\n")
  writeLines("###########")
  writeLines("## NOTES ##")
  writeLines("###########\n")
  writeLines("Sequences in 'LightPrimer' package are classified into 'fragment', 'gene', 'SNP' and 'Indel' respectively, which is defined by 'seqType'. 'seqType' is required for primer designing pipeline for different purpose.")
  writeLines("\tFragment: sequence not related to any annotated gene, it could be used for 'Cloning'.")
  writeLines("\tGene: sequence annotated as gene, it could be used for 'Cloning', and 'qRT-PCR' (only mRNA).")
  writeLines("\tSNP and Indel: position or range of gap to indicate where there is a SNP or Indel. it could be used for 'Cloning', and 'marker.development'.\n\n")
  sink(type = "output")
  
  ## template generation
  if(templateCreation == TRUE){
    ## GeneList template
    geneList = data.frame(matrix(nrow = 10, ncol = 51))
    names(geneList) = c("Serial.No", "Gene.ID", "Type", "For", "Chr", "Start", "End", "Strand", "promoterLength", "leftFlanking", "rightFlanking", "windowSize", "stepWise", "TmMethod", "specificityMin", "nthreads", "Evalue", "TmScope", "GCScope", "countMax", "endMatch", "GCend", "primerLength", "primerStrand", "GCShow", "TmShow", "specificiyShow", "countShow", "segmentLinetype", "segmentColor", "segmentSize", "pointShape1", "pointShape2", "pointColor1", "pointColor2", "pointSize", "pointSize1", "pointSize2", "hlineType", "hlineColor", "hlineSize", "pdfWidth", "pdfHeight", "outFormat", "seqEvaluation", "plotting", "Fcolor", "Rcolor", "lcolor", "leftRegion", "rightRegion")
    geneList$Serial.No = seq(1:nrow(geneList))
    fwrite(geneList, file = paste0(dir.path, "/Input.files/GeneList.template.csv"), col.names = T, row.names = F, quote = F, sep = "\t")
    sink(file = paste0(dir.path, "/Input.files/Template.Instruction.txt"), type = "output", append = T)
    writeLines("######################################")
    writeLines("##### Instructions for Templates #####")
    writeLines("######################################\n\n")
    writeLines("#######################")
    writeLines("## GeneList Template ##")
    writeLines("#######################\n")
    writeLines("# REQUIRED parameters: 'Gene.ID', 'Type', and 'For'.")
    writeLines("\tSerial.No: numerical order to indicate the serial number of each gene, usually start from 1, and should NOT contain rows with Serial.No but NO Gene.ID.")
    writeLines("\tGene.ID: the gene identifier in the genome annotation file (GFF: general feature format) of certain species, e.g. Glyma.01G000100 in soybean. The Gene.ID should be exactly the gene identifier itself rather than its transcripts id (Glyma.01G000100.1)")
    writeLines("\tType: the type of features, e.g. 'CDS', 'promoter', 'gene', 'mRNA', 'five_prime_UTR', 'three_prime_UTR'.")
    writeLines("\tFor: the purpose of this analysis, could be one of 'Cloning', 'qRT-PCR', 'marker.development'.")
    writeLines("\n\n")
    sink(type = "output")
    
    ## FragmentList template
    fragmentList = data.frame(matrix(nrow = 10, ncol = 50))
    names(fragmentList) = c("Serial.No", "Fragment.ID", "For", "Chr", "Start", "End", "Strand", "Length", "leftFlanking", "rightFlanking", "windowSize", "stepWise", "TmMethod", "specificityMin", "nthreads", "Evalue", "TmScope", "GCScope", "countMax", "endMatch", "GCend", "primerLength", "primerStrand", "GCShow", "TmShow", "specificiyShow", "countShow", "segmentLinetype", "segmentColor", "segmentSize", "pointShape1", "pointShape2", "pointColor1", "pointColor2", "pointSize", "pointSize1", "pointSize2", "hlineType", "hlineColor", "hlineSize", "pdfWidth", "pdfHeight", "outFormat", "seqEvaluation", "plotting", "Fcolor", "Rcolor", "lcolor", "leftRegion", "rightRegion")
    fragmentList$Serial.No = seq(1:nrow(fragmentList))
    fwrite(fragmentList, file = paste0(dir.path, "/Input.files/FragmentList.template.csv"), col.names = T, row.names = F, quote = F, sep = "\t")
    
    
    sink(file = paste0(dir.path, "/Input.files/Template.Instruction.txt"), type = "output", append = T)
    writeLines("###########################")
    writeLines("## FragmentList Template ##")
    writeLines("###########################\n")
    writeLines("# REQUIRED parameters: 'Fragment.ID', 'Chr', 'Start', and 'End'.")
    writeLines("\tSerial.No: numerical order to indicate the serial number of each fragment, usually start from 1, and should NOT contain rows with Serial.No but NO Fragment.ID.")
    writeLines("\tFragment.ID: a string indicates the fragment identifier, in which underline ('_') should be avoided as it has been used in the file names.")
    writeLines("\tChr: numeric value indicates chromosome number, e.g. 1, 2, 3, ...")
    writeLines("\tStart: numeric value indicates start position of the fragment.")
    writeLines("\tEnd: numeric value indicates end position of the fragment.")
    writeLines("\n\n")
    sink(type = "output")
    


    
    ## Indel template
    IndelList = data.frame(matrix(nrow = 10, ncol = 50))
    names(IndelList) = c("Serial.No", "Indel.Name", "For", "Chr", "Start", "End", "Strand", "leftFlanking", "rightFlanking", "windowSize", "stepWise", "TmMethod", "specificityMin", "nthreads", "Evalue", "TmScope", "GCScope", "countMax", "endMatch", "GCend", "primerLength", "primerStrand", "GCShow", "TmShow", "specificiyShow", "countShow", "segmentLinetype", "segmentColor", "segmentSize", "pointShape1", "pointShape2", "pointColor1", "pointColor2", "pointSize", "pointSize1", "pointSize2", "hlineType", "hlineColor", "hlineSize", "pdfWidth", "pdfHeight", "outFormat", "seqEvaluation", "plotting", "Fcolor", "Rcolor", "lcolor", "leftRegion", "rightRegion", "rectFill")
    IndelList$Serial.No = seq(1:nrow(IndelList))
    fwrite(IndelList, file = paste0(dir.path, "/Input.files/IndelList.template.csv"), col.names = T, row.names = F, quote = F, sep = "\t")
    
    
    sink(file = paste0(dir.path, "/Input.files/Template.Instruction.txt"), type = "output", append = T)
    writeLines("########################")
    writeLines("## IndelList Template ##")
    writeLines("########################\n")
    writeLines("# REQUIRED parameters: 'Indel.Name', 'Chr', 'Start', and 'End'.")
    writeLines("\tSerial.No: numerical order to indicate the serial number of each Indel, usually start from 1, and should NOT contain rows with Serial.No but NO Indel.Name.")
    writeLines("\tIndel.Name: a string indicates the Indel identifier, in which underline ('_') should be avoided as it has been used in the file names.")
    writeLines("\tChr: numeric value indicates chromosome number, e.g. 1, 2, 3, ...")
    writeLines("\tStart: numeric value indicates start position of the Indel.")
    writeLines("\tEnd: numeric value indicates end position of the Indel.")
    writeLines("\n\n")
    sink(type = "output")
    
    ## SNP template
    SNPList = data.frame(matrix(nrow = 10, ncol = 48))
    names(SNPList) = c("Serial.No", "SNP.Name", "For", "Chr", "Pos", "leftFlanking", "rightFlanking", "windowSize", "stepWise", "TmMethod", "specificityMin", "nthreads", "Evalue", "TmScope", "GCScope", "countMax", "endMatch", "GCend", "primerLength", "primerStrand", "GCShow", "TmShow", "specificiyShow", "countShow", "segmentLinetype", "segmentColor", "segmentSize", "pointShape1", "pointShape2", "pointColor1", "pointColor2", "pointSize", "pointSize1", "pointSize2", "hlineType", "hlineColor", "hlineSize", "pdfWidth", "pdfHeight", "outFormat", "seqEvaluation", "plotting", "Fcolor", "Rcolor", "lcolor", "leftRegion", "rightRegion", "rectFill")
    SNPList$Serial.No = seq(1:nrow(SNPList))
    fwrite(SNPList, file = paste0(dir.path, "/Input.files/SNPList.template.csv"), col.names = T, row.names = F, quote = F, sep = "\t")
    
    
    sink(file = paste0(dir.path, "/Input.files/Template.Instruction.txt"), type = "output", append = T)
    writeLines("######################")
    writeLines("## SNPList Template ##")
    writeLines("######################\n")
    writeLines("# REQUIRED parameters: 'SNP.Name', 'Chr', and 'Pos'")
    writeLines("\tSerial.No: numerical order to indicate the serial number of each SNP, usually start from 1, and should NOT contain rows with Serial.No but NO SNP.Name.")
    writeLines("\tSNP.Name: a string indicates the SNP identifier, in which underline ('_') should be avoided as it has been used in the file names.")
    writeLines("\tChr: numeric value indicates chromosome number, e.g. 1, 2, 3, ...")
    writeLines("\tPos: numeric value indicates the position of the SNP.")
    writeLines("\n\n")
    sink(type = "output")
    
    
    sink(file = paste0(dir.path, "/Input.files/Template.Instruction.txt"), type = "output", append = T)
    writeLines("############################")
    writeLines("## ALTERNATIVE parameters ##")
    writeLines("############################\n")
    writeLines("\t'Chr', 'Start', 'End', 'Strand' of a gene would be defined by gffFile, 'Strand' is meaningless to SNP and Indel, ")
    writeLines("\tStrand: '+' or '-' to indicate the strand of the fragment, If it is blank, '+' would be assigned to the fragment as default. 'Strand' is meaningless to SNP and Indel.")
    writeLines("\tLength: numeric vlaue indicates the length of fragment, which could be left blank. default 'Length' is defined as 'end' - 'start'. ")
    writeLines("\tpromoterLength: numeric value indicates the length of promoter sequence to extract, default is 2000 (bp). Promoter is defined as the upstream sequence to the start of mRNA.")
    writeLines("\tleftFlanking: numeric value indicates the left flanking region, default value is 200 (bp).")
    writeLines("\trightFlanking: numeric value indicates the right flanking region, default value is 200 (bp).")
    writeLines("\twindowSize: numeric value indicates scope of window size, could be a single number, e.g. 23, or a range, e.g. c(20,25). Default value is c(20, 25).")
    writeLines("\tstepWise: numeric value indicates stepWise of windows when sequence is fragmented, default value is 3.")
    writeLines("\tTmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X4+(T+C)X2, while 2 represents 81.5 + 0.41XGC.content - 600/seqLength. Default is 'both', including both 1 and 2.")
    writeLines("\tspecificityMin: numeric value indicates the min value of sequence specificity to signify on the diagnostic plot, and for the final primer selection as well. Default is 95 (%).")
    writeLines("\tnthreads: numeric value indicates how many threads used in the Local-blast, default is 2.")
    writeLines("\tEvalue: numeric value indicates the e value threshold for Local-blast, default is 1e-1 (0.1).")
    writeLines("\tTmScope: numeric range indicates the min and max of primer Tm, default value is 'c(40, 60)'.")
    writeLines("\tGCScope: numeric range indicates the min and max of primer GC content (%), default value is 'c(35, 65)'.")
    writeLines("\toutFormat: numeric value to specify -outfmt parameter in Local-blast, default is 6.")
    writeLines("\tcountMax: numeric value indicates the maximum counts threshold, by which fragment to be displayed with dashed line. Default is 2.")
    writeLines("\tendMatch: logical value indicates whether the primer end (3') matched to genome, default value is TRUE.")
    writeLines("\tGCend: logical value indicates whether the primer end (3') is G:C or not, default value is TRUE.")
    writeLines("\tprimerLength: numeric scope indicates the min and max length of primer, default value is 'c(20, 25)', which is exactly the same as windowSize.")
    writeLines("\tprimerStrand: which primer to be designed, default is 'F' (forward) and 'R' (reverse).")
    writeLines("\tGCShow: logical value. whether to show GC content on the diagnostic plot, default is TRUE.")
    writeLines("\tTmShow: logical value.whether to show Tm value on the diagnostic plot, default is TRUE.")
    writeLines("\tspecificiyShow: logical value.whether to show sequence specificity value on the diagnostic plot, default is TRUE.")
    writeLines("\tcountShow: logical value.whether to show Counts on the diagnostic plot, default is TRUE.")
    writeLines("\tsegmentLinetype: numeric value indicates which line type to be used. It is inherited from basic line types in the R.")
    writeLines("\tsegmentColor: string indicate the color of geom_segment(), which represent fragment sequence on the chromosome in terms of location.")
    writeLines("\tsegmentSize: numeric value indicates line size of geom_segment(), default value is 0.2.")
    writeLines("\tpointShape: numeric value indicates point shape in geom_point(), default value for pointShape1 and pointShape2 are 19 and 24 respectively.")
    writeLines("\tpointColor: string indicates color of geom_point(), default value for pointColor1 and pointColor2 are 'red' and 'blue' respectively.")
    writeLines("\tpointSize: numeric value indicates point size in geom_point(), default value for pointSize, pointSize1, and pointSize2 are 0.5, 0.5, and 0.5 respectively.")
    writeLines("\thlineType: numeric value indicates line type in geom_hline(), default value is 2.")
    writeLines("\thlineColor: string indicates line color in geom_hline(), default value is 'blue'.")
    writeLines("\thlineSize: numeric value indicates line size, default value is 0.3.")
    writeLines("\tpdfWidth: numeric value indicates width of pdf file, default value is 16.")
    writeLines("\tpdfHeight: numeric value indicates height of pdf file, default value is 10.")
    writeLines("\tplotting: logical value indicates whether to plot primers or not. Default is TRUE.")
    writeLines("\tFcolor: color value for forward primers, default is '#B2182B'.")
    writeLines("\tRcolor: color value for reverse primers, default is '#2166AC'.")
    writeLines("\tlcolor: color value for line connecting forward and reverse primer pairs, default is 'black'.")
    writeLines("\toverlapMin: numeric value indicates at least how many base pairs acrossing different exons, to eliminate none specific matching to genome DNA. Default is 5 (bp).")
    writeLines("\tleftRegion: the position scope for left primer.")
    writeLines("\trightRegion: the position scope for right primer.")
    writeLines("\trectFill: color value for rect shade indicating the position of SNP or Indel, default is '#FF3300'.")
    writeLines("\n")
    writeLines("######### THE END #########")
    sink(type = "output")
  }
}

