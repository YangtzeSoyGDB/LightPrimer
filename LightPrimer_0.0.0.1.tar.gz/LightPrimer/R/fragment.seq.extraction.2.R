
#' This is some description of this function.
#' @title to extract fragment sequence from genome based on parameters inputted manually. 
#'
#' @description By using this package, you could use function of fragment.seq.extraction.2 to extract fragment sequence from genome based on parameters inputted manually. 'fragment' is defined as a fragment sequence other than annotated gene, however a annotated gene could be regarded as a fragment as well.
#'
#' @details see above
#'
#' @param fragmentName: fragment name
#' @param database: folder or file contains genome sequence in fasta format
#' @param chr: numeric value or string, e.g 15, Chr15, and Gm15, indicates chromosome ID
#' @param start: numeric value indicates the start position of a fragment
#' @param end: numeric value indicates the end position of a fragment
#' @param strand: "+", or "-" indicates the direction of a fragment
#' @param length: numeric value indicates how many base pairs contained by a fragment, length of end - start would be calculated as default if length is missing.
#' @param leftFlanking: numeric value indicates left flanking region of a fragment, default value is 200, please specify 0 to this parameter if no left flanking region is to be extracted.
#' @param rightFlanking: numeric value indicates right flanking region of a fragment, default value is 200, please specify 0 to this parameter if no right flanking region is to be extracted.
#' @param For: string to indicate the purpose of sequence extraction. Default value is 'Cloning'.
#' @return fasta files, log file stored in ".../Sequence.extraction/Fragment/"
#' @export fragment.seq.extraction.2
#' @examples # fragment.seq.extraction.2(database = "./soybean.genome/Gmax_275_v2.0.fa", fragmentName = "hello", chr = 15, start = 12345, end = 12435)
#' 


###### NOTES ######
# fragment.seq.extraction.2.R is to extract sequence from database based on parameters input manually
######  END  ######


# fragment.seq.extraction.2(database = "./soybean.genome/Gmax_275_v2.0.fa", fragmentName = "hello", chr = 15, start = 12345, end = 12435)

fragment.seq.extraction.2 = function(database = NULL, fragmentName = NULL, chr = NULL, start = NULL, end = NULL, strand = NULL, length = NULL, leftFlanking = NULL, rightFlanking = NULL, For = NULL, ...){
  
  library(data.table)
  library(Biostrings)
  library(stringr)
  
  dir.path = getwd()
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction"))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction"))
  }
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Fragment"))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Fragment"))
  }
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", fragmentName))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", fragmentName))
  }
  
  sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
  writeLines("\n######## Fragment Sequence Extraction  ########")
  writeLines(paste0("\nDate: ", date()))
  writeLines(paste0("Information source: parameters input manually\n"))
  sink(type = "output")
  
  
  if(is.null(fragmentName)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0('Program is stopped! fragmentName is required!'))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'fragmentName' is required!\n")
  } 
  if(is.null(database)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0('Program is stopped! Database is required!'))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'database' is required!\n")
  } 
  if(is.null(start)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0('Program is stopped!', " 'start' is required!"))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'start' is required!\n")
  } 
  if(is.null(end)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0('Program is stopped!', " 'end' is required!"))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'end' is required!\n")
  } 

  if(is.null(strand)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Warning: ", " 'strand' is missing!", ". Default of '+' is assigned to 'strand'!"))
    sink(type = "output")
    strand = "+"
  }
  if(is.null(length)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Warning: ", " 'length' is missing!", ". value calculated by end - start is assgined as default value for 'length'!"))
    sink(type = "output")
    length = end - start
  } 
  if(is.null(leftFlanking)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Warning: ", " 'leftFlanking' is missing!", ". Default of 200 is assigned to 'leftFlanking'!"))
    sink(type = "output")
    leftFlanking = 200
  } 
  if(is.null(rightFlanking)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Warning: ", " 'rightFlanking' is missing!", ". Default of 200 is assigned to 'rightFlanking'!"))
    sink(type = "output")
    rightFlanking = 200
  } 
  if(is.null(For)) For = "Cloning"
  
  
  ## database read in 
  if(dir.exists(database)){
    database.dir = paste0(dir.path, "/", database, list.files(paste0(dir.path, "/", database)))
    if(length(database.dir) == 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
    }
    if(length(database.dir) > 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
      for(i in 2:length(database.dir)){
        temp = readDNAStringSet(database.dir[i], format = "fasta")
        DNAseq = append(DNAseq, temp)
      }
    }
  }
  if(!dir.exists(database)){
    DNAseq = readDNAStringSet(database, format = "fasta")
  }
  
  if(is.null(chr)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0('Program is stopped!', " 'chr' is required!"))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'chr' is required!\n")
  }else{
    chr.format = names(DNAseq)[1]
    chr.format = str_extract_all(chr.format, "(Chr|Gm)")[[1]]
    if(length(grep(chr.format, chr)) == 0){
      if(is.numeric(chr)){
        chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
      }else{
        chr = as.numeric(gsub("Chr|Gm", "", chr))
        chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
      }
    }
  }
  
  ### 
  DNAseq.chr = DNAseq[chr]
  seq = as.character(subseq(DNAseq.chr, start = start - leftFlanking, end = end + rightFlanking))
  seq = DNAStringSet(seq)
  if(strand == "-"){
    seq = reverseComplement(seq)
  }
  names(seq) = paste0(fragmentName, "_", chr, "_", start, "..", end, "_leftFlanking.", leftFlanking,"_rightFlanking.", rightFlanking, "_length.", length, "_for.", For)
  writeXStringSet(seq, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", fragmentName, "/", fragmentName, "_", chr, "_", start, "..", end, "_leftFlanking.", leftFlanking,"_rightFlanking.", rightFlanking,  "_length.", length, "_strand(", strand, ")", "_for.", For, ".fasta"), compress = FALSE)
  
  sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
  writeLines(paste0("\nSequence extraction parameters for ", fragmentName, ":"))
  writeLines(paste0("\tChr: ", chr))
  writeLines(paste0("\tStart: ", start))
  writeLines(paste0("\tEnd: ", end))
  writeLines(paste0("\tStrand: ", strand))
  writeLines(paste0("\tLength: ", length))
  writeLines(paste0("\tleftFlanking: ", leftFlanking))
  writeLines(paste0("\trightFlanking: ", rightFlanking))
  writeLines(paste0("\tFor: ", For, "\n"))
  writeLines("\n######## THE END  ########")
  sink(type = "output")
  cat("Congratulation! fragment.seq.extraction is DONE!\n")
}




