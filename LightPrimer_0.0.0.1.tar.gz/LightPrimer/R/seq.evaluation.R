

#' This is some description of this function.
#' @title figure out the chromosomal location of a gene or fragment on specific genome
#'
#' @description By using this package, you could use function of seq.evaluation to perform local-blast for location of a gene or fragment on specific genome
#'
#' @details see above
#' @param seqType: string to indicate type of sequence, which could one of 'Gene', "fragment', 'SNP', 'Indel'.
#' @param inputFile: parameter setting file in '.csv' or '.xlsx' format. it should contains Type	Name	Chr	Start	End	Strand	Primer_strand	Flanking.left.bp	Flanking.right.bp	Expected.amplicon.length.bp	Aiming	Primer.name	Primer.length.bp	Tm.expected	GC.content	Sequence.specificity.min, details could be found in example input file.
#' @param database: folder contains genome sequence in fasta format
#' @param stepWise: numeric value to indicate stepWise of windows, default value is 3.
#' @param windowSize: numeric value to indicate scope of window size, could be a single number, e.g. 23, or a range, e.g. c(20,25). Default value is c(20, 25)
#' @param blastDir: the path to the local blast.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, while 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param specificityMin: numeric value to indicate the min value of sequence specificity to signify on the diagnostic plot.
#' @param nthreads: numeric value to indicate how many threads used in the analysis, default is 2
#' @param Evalue: numeric value to indicate e-value threshold in local-blast, default is 0.1 (1e-1)
#' @param TmScope: numeric scope indicates the min and max of primer Tm, default value is 'c(40, 65)'.
#' @param outFormat: numeric value to specify -outfmt parameter in local blast, default is 6.
#' @param GCShow: logical value. whether to show GC content on the diagnostic plot, default is TRUE
#' @param TmShow: logical value.whether to show Tm value on the diagnostic plot, default is TRUE
#' @param specificiyShow: logical value.whether to show sequence specificity value on the diagnostic plot, default is TRUE
#' @param countShow: logical value.whether to show Counts on the diagnostic plot, default is TRUE
#' @param countMax: numeric value to indicates the maximum counts threshold, by which fragment to be displayed with dashed line.
#' @param segmentLinetype: numeric value indicates which line type to be used. It is inherited from basic line types in the R.
#' @param segmentColor: string indicate the color of geom_segment(), which represent fragment sequence on the chromosome in terms of location.
#' @param segmentSize: numeric value indicates line size of geom_segment(), default value is 0.2
#' @param pointShape: numeric value indicates point shape in geom_point(), default value for pointShape1 and pointShape2 are 19 and 24 respectively.
#' @param pointColor: string indicates color of geom_point(), default value for pointColor1 and pointColor2 are 'red' and 'blue' respectively.
#' @param pointSize: numeric value indicates point size in geom_point(), default value for pointSize, pointSize1, and pointSize2 are 0.5, 0.5, and 0.5 respectively.
#' @param hlineType: numeric value indicates line type in geom_hline(), default value is 2.
#' @param hlineColor: string indicates line color in geom_hline(), default value is 'blue'
#' @param hlineSize: numeric value indicates line size, default value is 0.3.
#' @param pdfWidth: numeric value indicates width of pdf file, default value is 16.
#' @param pdfHeight: numeric value indicates height of pdf file, default value is 10.
#' @return files and folder
#' @export seq.evaluation
#' @examples seq.evaluation(database = "./soybean.genome/", seqType = "Gene", inputFile = "./Sequence.extraction/Gene/Glyma.01G010100.1/Glyma.01G010100.1_mRNA_Chr01_980614..987593_leftFlanking.200_rightFlanking.200_strand(-)_for.qRT-PCR.fasta", blastDir = "./ncbi-blast-2.12.0+/")
#' 


# seq.evaluation(database = "./soybean.genome/", seqType = "SNP", inputFile = "./Sequence.extraction/SNP.flanking.sequence.extraction/SNP.4.15638972/", blastDir = "./ncbi-blast-2.12.0+/")

# windowSize = NULL; stepWise = NULL;TmMethod = NULL; specificityMin = NULL; nthreads = NULL;Evalue = NULL; GCShow = NULL; TmShow = NULL; specificiyShow = NULL;countShow = NULL; TmScope = NULL; GCScope = NULL; countMax = NULL; segmentLinetype = NULL; segmentColor = NULL; segmentSize = NULL; pointShape1 = NULL; pointShape2 = NULL; pointColor1 = NULL; pointColor2 = NULL; pointSize = NULL; pointSize1 = NULL; pointSize2 = NULL; hlineType = NULL; hlineColor = NULL; hlineSize = NULL; pdfWidth = NULL;pdfHeight = NULL;outFormat = NULL

############# NOTES #################
# Basic steps of seq.evaluation are: 1. fragmented sequence generation by specific window size and stepWise; 2. perform Local-Blast for all fragmented sequence; 3. statistic analysis of all fragmented sequences and diagnostic plotting showing GC.content (%), Tm, sequence specificy (%), and mapping counts.
# * sequence specificity: defined as the average identity percentage (%) of all fragments (sequence generated 
#   based on specific window size and stepWise) matched to genome when using Local-Blast. The formula is: sum(identity percentage)/counts. Sequence specificity less than 5% were all assigned as 5% for convenience, as too low of specificity is meaningless in selection of region with high sequence specificity for primer designing.
# * counts: means how many sequence fragment (subject) were matched with input sequence (query), counts which is larger than 100 were all assigned as 100 for convienience in plotting, as too many counts corresponding to low sequence specificity, which would not be selected as candidate primers.
########## END of NOTES ##############

seq.evaluation = function(database = NULL, seqType = NULL, inputFile = NULL, blastDir = NULL, windowSize = NULL, stepWise = NULL, TmMethod = NULL, specificityMin = NULL, nthreads = NULL, Evalue = NULL, GCShow = NULL, TmShow = NULL, specificiyShow = NULL, countShow = NULL, TmScope = NULL, GCScope = NULL, countMax = NULL, segmentLinetype = NULL, segmentColor = NULL, segmentSize = NULL, pointShape1 = NULL, pointShape2 = NULL, pointColor1 = NULL, pointColor2 = NULL, pointSize = NULL, pointSize1 = NULL, pointSize2 = NULL, hlineType = NULL, hlineColor = NULL, hlineSize = NULL, pdfWidth = NULL, pdfHeight = NULL, outFormat = NULL, ...){
  
  ## loading required packages
  library(stringr) # 
  library(Biostrings) # 
  library(tidyr)
  library(xlsx)
  library(WriteXLS)
  #library(tidyverse)
  library(sangerseqR)
  library(data.table)
  library(RColorBrewer)
  library(ggplot2)
  library(cowplot)
  
  ### default value assignment
  if(is.null(database)) stop("'database' is required!")
  if(is.null(inputFile)) stop("'inputFile' is required!")
  if(is.null(blastDir)) stop("'blastDir' is required!")
  if(is.null(seqType)) stop("'seqType' is required!")
  if(is.null(windowSize)) windowSize = c(20,25)
  if(is.null(stepWise)) stepWise = 3
  if(is.null(specificityMin)) specificityMin = 95
  if(is.null(Evalue)) Evalue = 1e-1
  if(is.null(outFormat)) outFormat = 6
  if(is.null(nthreads)) nthreads = 2
  if(is.null(GCShow)) GCShow = TRUE
  if(is.null(TmShow)) TmShow = TRUE
  if(is.null(specificiyShow)) specificiyShow = TRUE
  if(is.null(countShow)) countShow = TRUE
  if(is.null(TmMethod)) TmMethod = "both"
  if(is.null(TmScope)) TmScope = c(40, 65)
  if(is.null(GCScope)) GCScope = c(35, 65)
  if(is.null(countMax)) countMax = 2
  if(is.null(segmentLinetype)) segmentLinetype = 2
  if(is.null(segmentColor)) segmentColor = "red"
  if(is.null(segmentSize)) segmentSize = 0.2
  if(is.null(pointShape1)) pointShape1 = 19
  if(is.null(pointShape2)) pointShape2 = 24
  if(is.null(pointColor1)) pointColor1 = "red"
  if(is.null(pointColor2)) pointColor2 = "blue"
  if(is.null(pointSize)) pointSize = 0.5
  if(is.null(pointSize1)) pointSize1 = 0.5
  if(is.null(pointSize2)) pointSize2 = 0.5
  if(is.null(hlineType)) hlineType = 2
  if(is.null(hlineColor)) hlineColor = "blue"
  if(is.null(hlineSize)) hlineSize = 0.3
  if(is.null(pdfWidth)) pdfWidth = 16
  if(is.null(pdfHeight)) pdfHeight = 10

  ## current directory
  dir.path = getwd()
  
  if(!dir.exists(database)){
    stop("Parameter 'database' should be a folder, in which *.fasta file could be defined as a database for LOCAL-BLAST!\n")
  }
  
  if(!is.numeric(windowSize)){
    stop("Please check windowSize input, this parameter give a number region by which input sequence would be freamented, it should be numeric, default input is 'c(20, 25)' other formats of input would not be accepted!\n")
  }
  window.size = seq(windowSize[1], windowSize[2])
  if(window.size[length(window.size)] > 30 | window.size[length(window.size)] < 18){
    warning(paste0("\nThe shortest and longest window size are ", window.size[1], "bp and ", window.size[length(window.size)], "bp respectively, which are too small or too large for providing meaningfull information for further analysis!\n"))
  }
  if(!is.numeric(stepWise)){
    stop("The parameter 'stepWise' should be a numeric vector! the default unit for 'stepWise' is 'bp' as default.\n")
  }
  if(stepWise >= 10){
    warning(paste0("\nThe current stepWise is: ", stepWise, ". A number between 1-10 is prefered, too large stepWise would result in missing information.\n"))
  }
  
  ## folder creation
  if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation"))){
    dir.create(paste0(dir.path, "/", "Sequence.evaluation"))
  }
  if(seqType == "Gene" | seqType == "gene" | seqType == "GENE"){
    folderName1 = "Gene"
  }
  if(seqType == "fragment" | seqType == "Fragment" | seqType == "FRAGMENT"){
    folderName1 = "Fragment"
  }
  if(seqType == "SNP" | seqType == "snp"){
    folderName1 = "SNP"
  }
  if(seqType == "Indel" | seqType == "INDEL" | seqType == "indel"){
    folderName1 = "Indel"
  }
  if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/", folderName1))){
    dir.create(paste0(dir.path, "/", "Sequence.evaluation/", folderName1))
  }
  
  ## make database if its not ready for use
  if(!dir.exists(paste0(dir.path, "/", blastDir, "db"))){
    dir.create(paste0(dir.path, "/", blastDir, "db"))
  }
  if(length(dir(paste0(dir.path, "/", blastDir, "db"))) == 0){
    files = dir(database)
    for(i in 1:length(files)){
      file.copy(from = paste0(dir.path,"/", database, files[i]),
                to = paste0(dir.path, "/", blastDir, "db/", files[i]))
    }
    makeblastdb.dir = paste0(dir.path, "/", blastDir, "bin/makeblastdb")
    db.files = paste0(dir.path, "/", blastDir, "db/", list.files(paste0(dir.path, "/", blastDir, "db/")))
    for(i in 1:length(db.files)){
      seq.name = strsplit(db.files[i], "/")[[1]][length(strsplit(db.files[i], "/")[[1]])]
      seq.name = gsub(".fasta", "", seq.name)
      system2(command = makeblastdb.dir,
              args= c("-in", db.files[i],
                      "-parse_seqids ",
                      "-hash_index ",
                      "-dbtype nucl",
                      "-out", seq.name,
                      "-num_threads", nthreads),
              wait = TRUE,
              stdout = FALSE
      )
      files.1 = dir(dir.path)
      for(j in 1:length(files.1)){
        if(!dir.exists(files.1[j])) {
          file.copy(from = paste0(dir.path,"/",files.1[j]),
                    to = paste0(dir.path,"/",blastDir, "db/", files.1[j]))
          file.remove(paste0(dir.path,"/",files.1[j]))
        }
      }
    }
    rm(seq.name, files, makeblastdb.dir)
  }
  
  ## function 1
  seq.splitting = function(data, window.size, step){
    seq.split = c()
    if(nchar(as.character(data[1])) >= window.size + step){
      for(i in 1:length(data)){
        seq = seq(from = 1, to = nchar(as.character(data[i])), by = step)
        for(j in seq){
          if(j+window.size < nchar(as.character(data[i]))){
            sub_seq <- subseq(data[i], start = j, end = j + window.size - 1)
            names(sub_seq) <- paste0(names(data[i]), "_from_", j, "_to_", j + window.size -1 )
            seq.split = append(seq.split, sub_seq)
          }
        }
      }
    }
    return(seq.split)
  }
  
  blastn.dir = paste0(dir.path, "/", blastDir, "bin/blastn")
  blast_out_col <- c("Query", "Subject", "Identity_percentage",
                     "Length_bp", "Mismatch_bp", "Gap_bp",
                     "Query_start", "Query_end", "Subject_start", "Subject_end",
                     "E_value", "Bit_score")
  
  file.list = list.files(paste0(dir.path, "/", database))
  dir = paste0(dir.path, "/", database, file.list)
  # i = 1
  for(i in 1:length(dir)){
    seq.name = strsplit(dir[i], "/")[[1]][length(strsplit(dir[i], "/")[[1]])]
    seq.path = paste0(dir.path, "/", blastDir, "db/", seq.name)
    DNAseq = readDNAStringSet(dir[i], format = "fasta")
    if(!dir.exists(inputFile)){
      input.file.path = paste0(dir.path, "/", inputFile)
      input = readDNAStringSet(input.file.path, format = "fasta")
      input.name = strsplit(input.file.path, "/")[[1]][length(strsplit(input.file.path, "/")[[1]])]
      input.name = gsub(".fasta", "", input.name)
      input.name = gsub("\\(+\\)|\\(-\\)|_strand", "", input.name)
      For = gsub("\\.", "", strsplit(input.name, "for")[[1]][2])
      if(length(str_extract_all(seqType, "Gene|gene|GENE|Fragment|fragment|FRAGMENT")[[1]]) == 1){
        folderName = strsplit(input.file.path, "/")[[1]][length(strsplit(input.file.path, "/")[[1]]) - 1]
        if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))){
          dir.create(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))
        }
      }
      if(length(str_extract_all(seqType, "SNP|snp|Indel|indel|INDEL")[[1]]) == 1){
        folderName = folderName = strsplit(input.file.path, "/")[[1]][length(strsplit(input.file.path, "/")[[1]])]
        folderName = strsplit(folderName, "_")[[1]][1]
        if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))){
          dir.create(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))
        }
      }
      # j = 2
      for(j in 1:length(window.size)){
        split.seq = seq.splitting(data = input, window.size = window.size[j], step = stepWise)
        if(!is.null(split.seq)){
          writeXStringSet(split.seq, filepath = paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[j], "_for.", For, "_split.seq.fasta"), compress = FALSE)
          split.seq.path = paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[j], "_for.", For, "_split.seq.fasta")
          blast_out <- data.frame(system2(command = blastn.dir, 
                                          args = c("-db", seq.path, 
                                                   "-task blastn",
                                                   "-query", split.seq.path, 
                                                   "-outfmt", outFormat,
                                                   "-evalue", Evalue,
                                                   "-num_threads", nthreads),
                                          wait = TRUE,
                                          stdout = TRUE)) 
          names(blast_out) = c("original")
          blast_out <- blast_out %>% separate(original, blast_out_col, "\t")
          fwrite(blast_out, file = paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_against_", seq.name, "_Evalue.", Evalue, "_window.size.by.", window.size[j], "_for.", For, "_blast.out.csv"), row.names = F, col.names = T, quote = F, sep = "\t")
          for(m in 3:ncol(blast_out)){
            blast_out[,m] = as.numeric(blast_out[,m])
          }
          ### sequence specificity calculation
          seq.spec.m = data.frame(matrix(nrow = 0, ncol = 15))
          names(seq.spec.m) = c("Name", "Seq", "Chr", "From", "To", "Percentage", "Count", "GC.content", "Tm1", "Tm2", "Percentage.color", "Count.color", "GC.color", "Tm.color", "Tm2.color")
          query.list = unique(blast_out$Query)
          Count.colorset = c("red", colorRampPalette(c('blue','black'))(99))
          Tm.colorset = colorRampPalette(c('green','red',"black"))(60)
          GC.colorset = colorRampPalette(c('green','red', "black"))(100)
          Specific.colorset = colorRampPalette(c('black','red'))(100)
          # k = 1
          for(k in 1:length(query.list)){
            loc.temp = strsplit(query.list[k], "_")[[1]]
            start.end = grep("\\.\\.", loc.temp)
            Pos.left = as.numeric(strsplit(loc.temp[start.end], "\\..")[[1]][1])
            Pos.right = as.numeric(strsplit(loc.temp[start.end], "\\..")[[1]][2])
            if(seqType == "Gene" | seqType == "fragment" | seqType == "gene" | seqType == "Fragment"){
              leftFlanking = as.numeric(strsplit(loc.temp[grep("leftFlanking", loc.temp)], "\\.")[[1]][2])
              rightFlanking = as.numeric(strsplit(loc.temp[grep("rightFlanking", loc.temp)], "\\.")[[1]][2])
            }
            if(seqType == "Indel" | seqType == "SNP" | seqType == "INDEL" | seqType == "snp" | seqType == "indel"){
              if(length(grep("leftFlanking", loc.temp)) == 1){
                leftFlanking = as.numeric(strsplit(loc.temp[grep("leftFlanking", loc.temp)], "\\.")[[1]][2])
                rightFlanking = 0
              }
              if(length(grep("rightFlanking", loc.temp)) == 1){
                leftFlanking = 0
                rightFlanking = as.numeric(strsplit(loc.temp[grep("rightFlanking", loc.temp)], "\\.")[[1]][2])
              }
            }
            
            Chr = loc.temp[grep("Chr|Gm", loc.temp)]
            seq.spec.temp = data.frame(matrix(nrow = 1, ncol = 15))
            names(seq.spec.temp) = c("Name", "Seq", "Chr", "From", "To", "Percentage", "Count", "GC.content", "Tm1", "Tm2", "Percentage.color", "Count.color", "GC.color", "Tm1.color", "Tm2.color")
            temp1 = blast_out[which(blast_out$Query == query.list[k]), ]
            if(nrow(temp1) >= 1){
              if(seqType == "Gene" | seqType == "fragment" | seqType == "gene" | seqType == "Fragment"){
                temp1.1 = temp1[which(temp1$Identity_percentage == max(temp1$Identity_percentage) & temp1$Subject == Chr & temp1$Length_bp == window.size[j] & temp1$Gap_bp == 0 & temp1$Subject_start >= (Pos.left - leftFlanking) & temp1$Subject_start <= (Pos.right + rightFlanking)),]
              }
              if(seqType == "Indel" | seqType == "SNP" | seqType == "INDEL" | seqType == "snp" | seqType == "indel"){
                if(length(grep("leftFlanking", loc.temp)) == 1){
                  temp1.1 = temp1[which(temp1$Identity_percentage == max(temp1$Identity_percentage) & temp1$Subject == Chr & temp1$Length_bp == window.size[j] & temp1$Gap_bp == 0 & temp1$Subject_start >= (Pos.left - leftFlanking) & temp1$Subject_start <= Pos.right),]
                }
                if(length(grep("rightFlanking", loc.temp)) == 1){
                  temp1.1 = temp1[which(temp1$Identity_percentage == max(temp1$Identity_percentage) & temp1$Subject == Chr & temp1$Length_bp == window.size[j] & temp1$Gap_bp == 0 & temp1$Subject_start >= Pos.left & temp1$Subject_start <= (Pos.right + rightFlanking)),]
                }
              }
              if(nrow(temp1.1) == 0) next
              seq.spec.temp$Name[1] = temp1$Query[1]
              seq.spec.temp$Seq[1] = data.frame(split.seq[grep(query.list[k],names(split.seq))])[1,1]
              seq.spec.temp$Chr[1] = Chr
              seq.spec.temp$From[1] = temp1.1$Subject_start[1]
              seq.spec.temp$To[1] = temp1.1$Subject_end[1]
              seq.spec.temp$Percentage[1] = mean(as.numeric(temp1$Identity_percentage))/nrow(temp1)
              seq.spec.temp$Count[1] = nrow(temp1)
              freq = data.frame(letterFrequency(split.seq[grep(query.list[k],names(split.seq))], DNA_BASES))
              GC.content = (freq$G[] + freq$C[])*100/sum(freq[1,])
              if(TmMethod == 1){
                Tm1.value = (freq$G[] + freq$C[])*4 + (freq$A[] + freq$T[])*2
                seq.spec.temp$Tm1[1] = Tm1.value
              }
              if(TmMethod == 2){
                Tm2.value = 81.5 + 0.41*GC.content - 600/nchar(seq.spec.temp$Seq[1])
                seq.spec.temp$Tm2[1] = Tm2.value
              }
              if(TmMethod == "both" | TmMethod == "Both" | TmMethod == "BOTH"){
                Tm1.value = (freq$G[] + freq$C[])*4 + (freq$A[] + freq$T[])*2
                Tm2.value = 81.5 + 0.41*GC.content - 600/nchar(seq.spec.temp$Seq[1])
                seq.spec.temp$Tm1[1] = Tm1.value
                seq.spec.temp$Tm2[1] = Tm2.value
              }
              seq.spec.temp$GC.content[1] = GC.content
              seq.spec.temp$Percentage.color[1] = Specific.colorset[ceiling(seq.spec.temp$Percentage[1])]
              seq.spec.temp$GC.color[1] = ifelse(GC.content != 0, GC.colorset[ceiling(GC.content)], GC.colorset[1])
              seq.spec.temp$Tm1.color[1] = Tm.colorset[ceiling(Tm1.value) - 30]
              seq.spec.temp$Tm2.color[1] = Tm.colorset[ceiling(Tm2.value) - 30]
              seq.spec.temp$Count.color[1] = ifelse(nrow(temp1) <= 100, Count.colorset[nrow(temp1)], Count.colorset[100])
              seq.spec.temp$Percentage[1] = ifelse(seq.spec.temp$Percentage[1] <= 5, 5, seq.spec.temp$Percentage[1])
              seq.spec.temp$Count[1] = ifelse(seq.spec.temp$Count[1] >= 100, 100, seq.spec.temp$Count[1])
              seq.spec.m = rbind(seq.spec.m, seq.spec.temp)
            }
            if(nrow(temp1) == 0){
              next
            }
          }
          seq.spec.m$Loc = (as.numeric(seq.spec.m$From) + as.numeric(seq.spec.m$To))/2
          
          seq.spec.m$GC.content.selected = seq.spec.m$GC.content
          seq.spec.m$Percentage.selected = seq.spec.m$Percentage
          seq.spec.m$Tm1.selected = seq.spec.m$Tm1
          seq.spec.m$Tm2.selected = seq.spec.m$Tm2
          seq.spec.m$Count.selected = seq.spec.m$Count
          for(k in 1:nrow(seq.spec.m)){
            if(seq.spec.m$GC.content[k] <= GCScope[1] | seq.spec.m$GC.content[k] >= GCScope[2]){
              seq.spec.m$GC.content.selected[k] = 0
            }
            if(seq.spec.m$Percentage[k] <= specificityMin){
              seq.spec.m$Percentage.selected[k] = 0
            }
            if(seq.spec.m$Tm1[k] <= TmScope[1] | seq.spec.m$Tm1[k] >= TmScope[2]){
              seq.spec.m$Tm1.selected[k] = 0
            }
            if(seq.spec.m$Tm2[k] <= TmScope[1] | seq.spec.m$Tm2[k] >= TmScope[2]){
              seq.spec.m$Tm2.selected[k] = 0
            }
            if(seq.spec.m$Count[k] >= countMax){
              seq.spec.m$Count.selected[k] = 100
            }
          }
          
          Chr = as.numeric(gsub("Chr", "", Chr))
          
          #### plotting ####
          p1 = ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(GC.content))) + 
            geom_point(color = seq.spec.m$GC.color, size = pointSize) + theme(legend.position = "none") +  
            xlab(NULL) + 
            ylab("GC Content (%)")  + ylim(c(0,100)) + xlim(c(Pos.left, Pos.right)) +
            theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) +
            geom_segment(data = seq.spec.m, mapping = aes(x = Loc, xend = Loc,  y = 0,  yend = GC.content.selected), linetype = 2, color = "red", size = 0.2)
          
          
          if(TmMethod == 1){
            p2 = ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(Tm1))) + 
              geom_point(color = seq.spec.m$Tm1.color, size = pointSize1, shape = pointShape1) + theme(legend.position = "none") +  
              xlab(NULL) + 
              ylab("Tm1 (°C)")  + ylim(c(30,80)) + xlim(c(Pos.left, Pos.right)) +
              theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) + 
              geom_hline(yintercept = c(TmScope[1],TmScope[2]), linetype = hlineType, color = hlineColor, size = hlineSize)
          }
          if(TmMethod == 2){
            p2 = ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(Tm2))) + 
              geom_point(color = seq.spec.m$Tm2.color, size = pointSize2, shape = pointShape2) + theme(legend.position = "none") +  
              xlab(NULL) + 
              ylab("Tm2 (°C)")  + ylim(c(30,80)) + xlim(c(Pos.left, Pos.right)) +
              theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) + 
              geom_hline(yintercept = c(TmScope[1],TmScope[2]), linetype = hlineType, color = hlineColor, size = hlineSize)
          }
          if(TmMethod == "both" | TmMethod == "Both" | TmMethod == "BOTH"){
            p2 = ggplot(data = seq.spec.m) + 
              geom_point(aes(x = Loc, y = as.numeric(Tm1)), color = pointColor1, size = pointSize1, shape = pointShape1) + 
              geom_point(aes(x = Loc, y = as.numeric(Tm2)), color = pointColor2, size = pointSize2, shape = pointShape2) +
              theme(legend.position = "none") +  
              xlab(NULL) + 
              ylab("Tm1 & Tm2 (°C)")  + ylim(c(20,90)) + xlim(c(Pos.left, Pos.right)) +
              theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) + 
              geom_hline(yintercept = c(TmScope[1],TmScope[2]), linetype = hlineType, color = hlineColor, size = hlineSize)
          }
          
          p3 =  ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(Percentage))) + 
            geom_segment(data = seq.spec.m, mapping = aes(x = as.numeric(Loc), xend = as.numeric(Loc), y = as.numeric(Percentage)-0.5, yend = as.numeric(Percentage), size = 0.05), color = seq.spec.m$Percentage.color) + theme(legend.position = "none") +  ylim(c(0, 100)) + xlim(c(Pos.left, Pos.right)) +
            xlab(NULL) + 
            ylab("Sequence Specificity (%)")  + 
            theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) +
            geom_segment(data = seq.spec.m, mapping = aes(x = Loc, xend = Loc,  y = 0,  yend = Percentage.selected), linetype = segmentLinetype, color = segmentColor, size = segmentSize)
          
          p4 = ggplot(data = seq.spec.m, aes(x = Loc, y = Count)) + 
            geom_segment(data = seq.spec.m, mapping = aes(x = as.numeric(Loc), xend = as.numeric(Loc), y = as.numeric(Count)-0.5, yend = as.numeric(Count), size = 0.05), color = seq.spec.m$Count.color) + theme(legend.position = "none") +  ylim(c(0, 100)) + xlim(c(Pos.left, Pos.right)) +
            xlab(paste0("Chr", ifelse(Chr < 10, paste0("0", as.numeric(Chr)), as.numeric(Chr)), ":", Pos.left, "..", Pos.right)) + 
            ylab("Counts")  + 
            theme(panel.border = element_blank()) +
            geom_segment(data = seq.spec.m, mapping = aes(x = Loc, xend = Loc,  y = 100,  yend = Count.selected), linetype = segmentLinetype, color = segmentColor, size = segmentSize)
          
          ## plot setting
          if(GCShow == FALSE & TmShow == TRUE & specificiyShow == TRUE & countShow == TRUE) {p1 = NULL;p = plot_grid(p2, p3, p4, ncol = 1, align = "v")}
          if(TmShow == FALSE & GCShow == TRUE & specificiyShow == TRUE & countShow == TRUE) {p2 = NULL;p = plot_grid(p1, p3, p4, ncol = 1, align = "v")}
          if(specificiyShow == FALSE & GCShow == TRUE & TmShow == FALSE & countShow == TRUE){p3 = NULL;p = plot_grid(p1, p2, p4, ncol = 1, align = "v")} 
          if(countShow == FALSE & GCShow == TRUE & TmShow == TRUE & specificiyShow == TRUE){p4 = NULL;p = plot_grid(p1, p2, p3, ncol = 1, align = "v")} 
          if(GCShow == FALSE & TmShow == FALSE & specificiyShow == TRUE & countShow == TRUE){p1 = NULL;p2 = NULL;p = plot_grid(p3, p4, ncol = 1, align = "v")}
          if(GCShow == FALSE & TmShow == TRUE & specificiyShow == FALSE & countShow == TRUE){p1 = NULL;p3 = NULL;p = plot_grid(p2, p4, ncol = 1, align = "v")}
          if(GCShow == FALSE & TmShow == TRUE & specificiyShow == TRUE & countShow == FALSE){p1 = NULL;p4 = NULL;p = plot_grid(p2, p3, ncol = 1, align = "v")}
          if(GCShow == TRUE & TmShow == FALSE & specificiyShow == FALSE & countShow == TRUE){p2 = NULL;p3 = NULL;p = plot_grid(p1, p4, ncol = 1, align = "v")}
          if(GCShow == TRUE & TmShow == FALSE & specificiyShow == TRUE & countShow == FALSE){p2 = NULL;p4 = NULL;p = plot_grid(p1, p3, ncol = 1, align = "v")}
          if(GCShow == TRUE & TmShow == TRUE & specificiyShow == FALSE & countShow == FALSE){p3 = NULL;p4 = NULL;p = plot_grid(p1, p2, ncol = 1, align = "v")}
          if(GCShow == FALSE & TmShow == FALSE & specificiyShow == FALSE & countShow == TRUE){p1= NULL;p2 = NULL;p3 = NULL;p = plot_grid(p4, ncol = 1, align = "v")}
          if(GCShow == FALSE & TmShow == FALSE & specificiyShow == TRUE & countShow == FALSE){p1= NULL;p2 = NULL;p4 = NULL;plot_grid(p3, ncol = 1, align = "v")}
          if(GCShow == FALSE & TmShow == TRUE & specificiyShow == FALSE & countShow == FALSE){p1= NULL;p3 = NULL;p4 = NULL;plot_grid(p2, ncol = 1, align = "v")}
          if(GCShow == TRUE & TmShow == FALSE & specificiyShow == FALSE & countShow == FALSE){p2= NULL;p3 = NULL;p4 = NULL;plot_grid(p1, ncol = 1, align = "v")}
          if(GCShow == FALSE & TmShow == FALSE & specificiyShow == FALSE & countShow == FALSE){p1 = NULL; p2= NULL;p3 = NULL;p4 = NULL;p = NULL}
          if(GCShow == TRUE & TmShow == TRUE & specificiyShow == TRUE & countShow == TRUE) {p = plot_grid(p1, p2, p3, p4, ncol = 1, align = "v")}
          
          p = p + theme(plot.margin=unit(rep(2,4),'lines'))
          
          ## plot outputting
          #p = plot_grid(p1, p2, p3, p4, ncol = 1, align = "v")
          if(length(p) != 0){
            pdf(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[j], "_for.", For, "_sequence.evaluation.plot.pdf"), width = pdfWidth, height = pdfHeight)
            par(oma = c(1.5, 1, 1.5, 1) + 0.1,mar= c(3, 4, 3, 4) + 0.1)
            print(p)
            dev.off()
          }
          ## data outputting
          names(seq.spec.m) = c("Name", "Seq(5'-3')", "Chr", "From", "To", "Seq.specificity(%)", "Counts", "GC.content(%)", "Tm1", "Tm2", "Seq.specificity.color", "Count.color", "GC.color", "Tm1.color", "Tm2.color", "Anchor.loc", "GC.content.selected", "Percentage.selected", "Tm1.selected", "Tm2.selected", "Count.selected")
          fwrite(seq.spec.m, file = paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[j], "_for.", For, "_sequence.evaluation.csv"), row.names = F, col.names = T, quote = F, sep = "\t")
        }
      }
    }
    # j = 1
    if(dir.exists(inputFile)){
      file.list.1 = list.files(paste0(dir.path, "/", inputFile), recursive = TRUE)
      dir.1 = paste0(dir.path, "/", inputFile, file.list.1)
      dir.1 = dir.1[grep(".fasta|.fas|.fa", dir.1)]
      if(length(str_extract_all(seqType, "Gene|gene|GENE|Fragment|fragment|FRAGMENT")[[1]]) == 1){
        folderName = strsplit(dir.1[1], "/")[[1]][length(strsplit(dir.1[1], "/")[[1]]) - 1]
        if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))){
          dir.create(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))
        }
      }
      ###
      for(j in 1:length(dir.1)){
        if(length(str_extract_all(seqType, "SNP|snp|Indel|indel|INDEL")[[1]]) == 1){
          folderName = strsplit(dir.1[j], "/")[[1]][length(strsplit(dir.1[j], "/")[[1]])]
          folderName = strsplit(folderName, "_")[[1]][1]
          if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))){
            dir.create(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))
          }
        }
        
        input = readDNAStringSet(dir.1[j], format = "fasta")
        # k = 1; l = 6
        for(k in 1:length(input)){
          input.name = names(input)[k]
          input.name = gsub("\\(+\\)|\\(-\\)", "", input.name)
          if(seqType == "SNP" | seqType == "Indel" | seqType == "snp" | seqType == "INDEL" | seqType == "indel"){
            For = "marker.development"
          }else{
            For = gsub("\\.", "", strsplit(input.name, "for")[[1]][2])
          }
          
          for(l in 1:length(window.size)){
            split.seq = seq.splitting(data = input, window.size = window.size[l], step = stepWise)
            if(!is.null(split.seq)){
              writeXStringSet(split.seq, filepath = paste0(dir.path, "/",  "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[l], "_for.", For, "_split.seq.fasta"), compress = FALSE)
              split.seq.path = paste0(dir.path, "/",  "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[l], "_for.", For, "_split.seq.fasta")
              blast_out <- data.frame(system2(command = blastn.dir, 
                                              args = c("-query", split.seq.path,
                                                       "-db", seq.path, 
                                                       "-task blastn",
                                                       "-outfmt", outFormat,
                                                       "-evalue", Evalue,
                                                       "-num_threads", nthreads),
                                              wait = TRUE,
                                              stdout = TRUE)) 
              
              names(blast_out) = c("original")
              blast_out <- blast_out %>% separate(original, blast_out_col, "\t")
              fwrite(blast_out, file = paste0(dir.path, "/",  "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_Evalue.", Evalue, "_window.size.by.", window.size[l], "_for.", For, "_blast.out.csv"), row.names = F, col.names = T, quote = F, sep = "\t")
              for(m in 3:ncol(blast_out)){
                blast_out[,m] = as.numeric(blast_out[,m])
              }
              
              ### sequence specificity calculation
              seq.spec.m = data.frame(matrix(nrow = 0, ncol = 15))
              names(seq.spec.m) = c("Name", "Seq", "Chr", "From", "To", "Percentage", "Count", "GC.content", "Tm1", "Tm2", "Percentage.color", "Count.color", "GC.color", "Tm1.color", "Tm2.color")
              query.list = unique(blast_out$Query)
              Count.colorset = c("red", colorRampPalette(c('blue','black'))(99))
              Tm.colorset = colorRampPalette(c('green','red',"black"))(60)
              GC.colorset = colorRampPalette(c('green','red', "black"))(100)
              Specific.colorset = colorRampPalette(c('black','red'))(100)
              #  m = 1
              for(m in 1:length(query.list)){
                loc.temp = strsplit(query.list[m], "_")[[1]]
                start.end = grep("\\.\\.", loc.temp)
                Pos.left = as.numeric(strsplit(loc.temp[start.end], "\\..")[[1]][1])
                Pos.right = as.numeric(strsplit(loc.temp[start.end], "\\..")[[1]][2])
                if(seqType == "Gene" | seqType == "fragment" | seqType == "gene" | seqType == "Fragment"){
                  leftFlanking = as.numeric(strsplit(loc.temp[grep("leftFlanking", loc.temp)], "\\.")[[1]][2])
                  rightFlanking = as.numeric(strsplit(loc.temp[grep("rightFlanking", loc.temp)], "\\.")[[1]][2])
                }
                if(seqType == "Indel" | seqType == "SNP" | seqType == "INDEL" | seqType == "snp" | seqType == "indel"){
                  if(length(grep("leftFlanking", loc.temp)) == 1){
                    leftFlanking = as.numeric(strsplit(loc.temp[grep("leftFlanking", loc.temp)], "\\.")[[1]][2])
                    rightFlanking = 0
                  }
                  if(length(grep("rightFlanking", loc.temp)) == 1){
                    leftFlanking = 0
                    rightFlanking = as.numeric(strsplit(loc.temp[grep("rightFlanking", loc.temp)], "\\.")[[1]][2])
                  }
                }
                Chr = loc.temp[grep("Chr|Gm", loc.temp)]
                seq.spec.temp = data.frame(matrix(nrow = 1, ncol = 15))
                names(seq.spec.temp) = c("Name", "Seq", "Chr", "From", "To", "Percentage", "Count", "GC.content", "Tm1", "Tm2", "Percentage.color", "Count.color", "GC.color", "Tm1.color", "Tm2.color")
                temp1 = blast_out[which(blast_out$Query == query.list[m]), ]
                if(nrow(temp1) >= 1){
                  if(seqType == "Gene" | seqType == "fragment" | seqType == "gene" | seqType == "Fragment"){
                    temp1.1 = temp1[which(temp1$Identity_percentage == max(temp1$Identity_percentage) & temp1$Subject == Chr & temp1$Length_bp == window.size[l] & temp1$Gap_bp == 0 & temp1$Subject_start >= (Pos.left - leftFlanking) & temp1$Subject_start <= (Pos.right + rightFlanking)),]
                  }
                  if(seqType == "Indel" | seqType == "SNP" | seqType == "INDEL" | seqType == "snp" | seqType == "indel"){
                    if(length(grep("leftFlanking", loc.temp)) == 1){
                      temp1.1 = temp1[which(temp1$Identity_percentage == max(temp1$Identity_percentage) & temp1$Subject == Chr & temp1$Length_bp == window.size[l] & temp1$Gap_bp == 0 & temp1$Subject_start >= (Pos.left - leftFlanking) & temp1$Subject_start <= Pos.right),]
                    }
                    if(length(grep("rightFlanking", loc.temp)) == 1){
                      temp1.1 = temp1[which(temp1$Identity_percentage == max(temp1$Identity_percentage) & temp1$Subject == Chr & temp1$Length_bp == window.size[l] & temp1$Gap_bp == 0 & temp1$Subject_start >= Pos.left & temp1$Subject_start <= (Pos.right + rightFlanking)),]
                    }
                  }
                  if(nrow(temp1.1) == 0) next
                  seq.spec.temp$Name[1] = temp1$Query[1]
                  seq.spec.temp$Seq[1] = data.frame(split.seq[grep(query.list[m],names(split.seq))])[1,1]
                  seq.spec.temp$Chr[1] = Chr
                  seq.spec.temp$From[1] = temp1.1$Subject_start[1]
                  seq.spec.temp$To[1] = temp1.1$Subject_end[1]
                  seq.spec.temp$Percentage[1] = mean(as.numeric(temp1$Identity_percentage))/nrow(temp1)
                  seq.spec.temp$Count[1] = nrow(temp1)
                  freq = data.frame(letterFrequency(split.seq[grep(query.list[m],names(split.seq))], DNA_BASES))
                  GC.content = (freq$G[] + freq$C[])*100/sum(freq[1,])
                  if(TmMethod == 1){
                    Tm1.value = (freq$G[] + freq$C[])*4 + (freq$A[] + freq$T[])*2
                    seq.spec.temp$Tm1[1] = Tm1.value
                  }
                  if(TmMethod == 2){
                    Tm2.value = 81.5 + 0.41*GC.content - 600/nchar(seq.spec.temp$Seq[1])
                    seq.spec.temp$Tm2[1] = Tm2.value
                  }
                  if(TmMethod == "both" | TmMethod == "Both" | TmMethod == "BOTH"){
                    Tm1.value = (freq$G[] + freq$C[])*4 + (freq$A[] + freq$T[])*2
                    Tm2.value = 81.5 + 0.41*GC.content - 600/nchar(seq.spec.temp$Seq[1])
                    seq.spec.temp$Tm1[1] = Tm1.value
                    seq.spec.temp$Tm2[1] = Tm2.value
                  }
                  seq.spec.temp$GC.content[1] = GC.content
                  seq.spec.temp$Percentage.color[1] = Specific.colorset[ceiling(seq.spec.temp$Percentage[1])]
                  seq.spec.temp$GC.color[1] = ifelse(GC.content != 0, GC.colorset[ceiling(GC.content)], GC.colorset[1])
                  seq.spec.temp$Tm1.color[1] = Tm.colorset[ceiling(Tm1.value) - 30]
                  seq.spec.temp$Tm2.color[1] = Tm.colorset[ceiling(Tm2.value) - 30]
                  seq.spec.temp$Count.color[1] = ifelse(nrow(temp1) <= 100, Count.colorset[nrow(temp1)], Count.colorset[100])
                  seq.spec.temp$Percentage[1] = ifelse(seq.spec.temp$Percentage[1] <= 5, 5, seq.spec.temp$Percentage[1])
                  seq.spec.temp$Count[1] = ifelse(seq.spec.temp$Count[1] >= 100, 100, seq.spec.temp$Count[1])
                  seq.spec.m = rbind(seq.spec.m, seq.spec.temp)
                }
                if(nrow(temp1) == 0){
                  next
                }
              }
              
              seq.spec.m$Loc = (as.numeric(seq.spec.m$From) + as.numeric(seq.spec.m$To))/2
              seq.spec.m$GC.content.selected = seq.spec.m$GC.content
              seq.spec.m$Percentage.selected = seq.spec.m$Percentage
              seq.spec.m$Tm1.selected = seq.spec.m$Tm1
              seq.spec.m$Tm2.selected = seq.spec.m$Tm2
              seq.spec.m$Count.selected = seq.spec.m$Count
              
              for(m in 1:nrow(seq.spec.m)){
                if(seq.spec.m$GC.content[m] <= GCScope[1] | seq.spec.m$GC.content[m] >= GCScope[2]){
                  seq.spec.m$GC.content.selected[m] = 0
                }
                if(seq.spec.m$Percentage[m] <= specificityMin){
                  seq.spec.m$Percentage.selected[m] = 0
                }
                if(seq.spec.m$Tm1[m] <= TmScope[1] | seq.spec.m$Tm1[m] >= TmScope[2]){
                  seq.spec.m$Tm1.selected[m] = 0
                }
                if(seq.spec.m$Tm2[m] <= TmScope[1] | seq.spec.m$Tm2[m] >= TmScope[2]){
                  seq.spec.m$Tm2.selected[m] = 0
                }
                if(seq.spec.m$Count[m] >= countMax){
                  seq.spec.m$Count.selected[m] = 100
                }
              }
              
              Chr = as.numeric(gsub("Chr|Gm", "", Chr))
              
              #### plotting ####
              p1 = ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(GC.content))) + 
                geom_point(color = seq.spec.m$GC.color, size = pointSize) + theme(legend.position = "none") +  
                xlab(NULL) + 
                ylab("GC Content (%)")  + ylim(c(0,100)) + xlim(c(Pos.left, Pos.right)) +
                theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) +
                geom_segment(data = seq.spec.m, mapping = aes(x = Loc, xend = Loc,  y = 0,  yend = GC.content.selected), linetype = 2, color = "red", size = 0.2)
              
              if(TmMethod == 1){
                p2 = ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(Tm1))) + 
                  geom_point(color = seq.spec.m$Tm1.color, size = pointSize1, shape = pointShape1) + theme(legend.position = "none") +  
                  xlab(NULL) + 
                  ylab("Tm1 (°C)")  + ylim(c(30,80)) + xlim(c(Pos.left, Pos.right)) +
                  theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) + 
                  geom_hline(yintercept = c(TmScope[1],TmScope[2]), linetype = hlineType, color = hlineColor, size = hlineSize)
              }
              if(TmMethod == 2){
                p2 = ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(Tm2))) + 
                  geom_point(color = seq.spec.m$Tm2.color, size = pointSize2, shape = pointShape2) + theme(legend.position = "none") +  
                  xlab(NULL) + 
                  ylab("Tm2 (°C)")  + ylim(c(30,80)) + xlim(c(Pos.left, Pos.right)) +
                  theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) + 
                  geom_hline(yintercept = c(TmScope[1],TmScope[2]), linetype = hlineType, color = hlineColor, size = hlineSize)
              }
              if(TmMethod == "both" | TmMethod == "Both" | TmMethod == "BOTH"){
                p2 = ggplot(data = seq.spec.m) + 
                  geom_point(aes(x = Loc, y = as.numeric(Tm1)), color = pointColor1, size = pointSize1, shape = pointShape1) + 
                  geom_point(aes(x = Loc, y = as.numeric(Tm2)), color = pointColor2, size = pointSize2, shape = pointShape2) +
                  theme(legend.position = "none") +  
                  xlab(NULL) + 
                  ylab("Tm1 & Tm2 (°C)")  + ylim(c(20,90)) + xlim(c(Pos.left, Pos.right)) +
                  theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) + 
                  geom_hline(yintercept = c(TmScope[1],TmScope[2]), linetype = hlineType, color = hlineColor, size = hlineSize)
              }
              
              p3 =  ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(Percentage))) + 
                geom_segment(data = seq.spec.m, mapping = aes(x = as.numeric(Loc), xend = as.numeric(Loc), y = as.numeric(Percentage)-0.5, yend = as.numeric(Percentage), size = 0.05), color = seq.spec.m$Percentage.color) + theme(legend.position = "none") + ylim(c(0, 100)) +
                xlab(NULL) + 
                ylab("Sequence Specificity (%)")  + xlim(c(Pos.left, Pos.right)) +
                theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) +
                geom_segment(data = seq.spec.m, mapping = aes(x = Loc, xend = Loc,  y = 0,  yend = Percentage.selected), linetype = segmentLinetype, color = segmentColor, size = segmentSize)
              
              p4 = ggplot(data = seq.spec.m, aes(x = Loc, y = Count)) + 
                geom_segment(data = seq.spec.m, mapping = aes(x = as.numeric(Loc), xend = as.numeric(Loc), y = as.numeric(Count)-0.5, yend = as.numeric(Count), size = 0.05), color = seq.spec.m$Count.color) + theme(legend.position = "none") +  ylim(c(0, 100)) + xlim(c(Pos.left, Pos.right)) +
                xlab(paste0("Chr", ifelse(Chr < 10, paste0("0", as.numeric(Chr)), as.numeric(Chr)), ":", Pos.left, "..", Pos.right)) + 
                ylab("Counts")  + 
                theme(panel.border = element_blank()) +
                geom_segment(data = seq.spec.m, mapping = aes(x = Loc, xend = Loc,  y = 100,  yend = Count.selected), linetype = segmentLinetype, color = segmentColor, size = segmentSize)
              
              ## plot setting
              if(GCShow == FALSE & TmShow == TRUE & specificiyShow == TRUE & countShow == TRUE) {p1 = NULL;p = plot_grid(p2, p3, p4, ncol = 1, align = "v")}
              if(TmShow == FALSE & GCShow == TRUE & specificiyShow == TRUE & countShow == TRUE) {p2 = NULL;p = plot_grid(p1, p3, p4, ncol = 1, align = "v")}
              if(specificiyShow == FALSE & GCShow == TRUE & TmShow == FALSE & countShow == TRUE){p3 = NULL;p = plot_grid(p1, p2, p4, ncol = 1, align = "v")} 
              if(countShow == FALSE & GCShow == TRUE & TmShow == TRUE & specificiyShow == TRUE){p4 = NULL;p = plot_grid(p1, p2, p3, ncol = 1, align = "v")} 
              if(GCShow == FALSE & TmShow == FALSE & specificiyShow == TRUE & countShow == TRUE){p1 = NULL;p2 = NULL;p = plot_grid(p3, p4, ncol = 1, align = "v")}
              if(GCShow == FALSE & TmShow == TRUE & specificiyShow == FALSE & countShow == TRUE){p1 = NULL;p3 = NULL;p = plot_grid(p2, p4, ncol = 1, align = "v")}
              if(GCShow == FALSE & TmShow == TRUE & specificiyShow == TRUE & countShow == FALSE){p1 = NULL;p4 = NULL;p = plot_grid(p2, p3, ncol = 1, align = "v")}
              if(GCShow == TRUE & TmShow == FALSE & specificiyShow == FALSE & countShow == TRUE){p2 = NULL;p3 = NULL;p = plot_grid(p1, p4, ncol = 1, align = "v")}
              if(GCShow == TRUE & TmShow == FALSE & specificiyShow == TRUE & countShow == FALSE){p2 = NULL;p4 = NULL;p = plot_grid(p1, p3, ncol = 1, align = "v")}
              if(GCShow == TRUE & TmShow == TRUE & specificiyShow == FALSE & countShow == FALSE){p3 = NULL;p4 = NULL;p = plot_grid(p1, p2, ncol = 1, align = "v")}
              if(GCShow == FALSE & TmShow == FALSE & specificiyShow == FALSE & countShow == TRUE){p1= NULL;p2 = NULL;p3 = NULL;p = plot_grid(p4, ncol = 1, align = "v")}
              if(GCShow == FALSE & TmShow == FALSE & specificiyShow == TRUE & countShow == FALSE){p1= NULL;p2 = NULL;p4 = NULL;plot_grid(p3, ncol = 1, align = "v")}
              if(GCShow == FALSE & TmShow == TRUE & specificiyShow == FALSE & countShow == FALSE){p1= NULL;p3 = NULL;p4 = NULL;plot_grid(p2, ncol = 1, align = "v")}
              if(GCShow == TRUE & TmShow == FALSE & specificiyShow == FALSE & countShow == FALSE){p2= NULL;p3 = NULL;p4 = NULL;plot_grid(p1, ncol = 1, align = "v")}
              if(GCShow == FALSE & TmShow == FALSE & specificiyShow == FALSE & countShow == FALSE){p1 = NULL; p2= NULL;p3 = NULL;p4 = NULL;p = NULL}
              if(GCShow == TRUE & TmShow == TRUE & specificiyShow == TRUE & countShow == TRUE) {p = plot_grid(p1, p2, p3, p4, ncol = 1, align = "v")}
              
              p = p + theme(plot.margin=unit(rep(2,4),'lines'))
              
              ## plot outputting
              if(length(p) != 0){
                pdf(paste0(dir.path, "/",  "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[l], "_for.", For, "_sequence.evaluation.plot.pdf"), width = pdfWidth, height = pdfHeight)
                par(oma = c(1.5, 1, 1.5, 1) + 0.1,mar= c(3, 4, 3, 4) + 0.1)
                print(p)
                dev.off()
              }
              
              ## data outputting
              names(seq.spec.m) = c("Name", "Seq(5'-3')", "Chr", "From", "To", "Seq.specificity(%)", "Counts", "GC.content(%)", "Tm1", "Tm2", "Seq.specificity.color", "Count.color", "GC.color", "Tm1.color", "Tm2.color", "Anchor.loc", "GC.content.selected", "Percentage.selected", "Tm1.selected", "Tm2.selected", "Count.selected")
              fwrite(seq.spec.m, file = paste0(dir.path, "/",  "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[l], "_for.", For, "_sequence.evaluation.csv"), row.names = F, col.names = T, quote = F, sep = "\t")
              rm(seq.spec.m)
            }
          }
        }
      }
    }
  }
  
  #cat("\nSeq.evaluation is Done!\n")
}



