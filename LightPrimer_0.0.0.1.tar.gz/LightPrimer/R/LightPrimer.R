

#' This is some description of this function.
#' @title to create essential folders and template files. 
#'
#' @description By using this package, you could use function of LightPrimer.preparation to create essential folders(./Sequence.extraction, ./Sequence.valuation, ./Designed.primers, ./Input.files, ./gff.file) and template files (GeneList.template.csv, FragmentList.template.csv, IndelList.template.csv, SNPList.template.csv, Template.Instruction.txt). 
#' @details see above
#'
#' @param folderCreation: logical value indicates whether to create essential folder or not, default is TRUE.
#' @param templateCreation: logical value indicates whether to create template files or not, default is TRUE.
#' @return files and folders
#' @export LightPrimer.preparation
#' @examples LightPrimer.preparation()


LightPrimer.preparation = function(folderCreation = NULL, templateCreation = NULL){
  
  library(data.table)
  library(xlsx)
  if(is.null(folderCreation)) folderCreation = TRUE
  if(is.null(templateCreation)) templateCreation = TRUE
  dir.path = getwd()
  
  if(folderCreation == TRUE){
    if(!dir.exists(paste0(dir.path, "/", "Input.files/"))){
      dir.create(paste0(dir.path, "/", "Input.files/"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/"))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/"))){
      dir.create(paste0(dir.path, "/", "Sequence.evaluation/"))
    }
    if(!dir.exists(paste0(dir.path, "/", "Designed.primers/"))){
      dir.create(paste0(dir.path, "/", "Designed.primers/"))
    }
    if(!dir.exists(paste0(dir.path, "/", "gff.file/"))){
      dir.create(paste0(dir.path, "/", "gff.file/"))
    }
  }
  
  ## template generation
  if(templateCreation == TRUE){
    ## GeneList template
    geneList = data.frame(matrix(nrow = 10, ncol = 4))
    names(geneList) = c("Serial.No", "Gene.ID", "Type", "For")
    geneList$Serial.No = seq(1:nrow(geneList))
    fwrite(geneList, file = paste0(dir.path, "/Input.files/GeneList.template.csv"), col.names = T, row.names = F, quote = F, sep = "\t")
    sink(file = paste0(dir.path, "/Input.files/Template.Instruction.txt"), type = "output", append = T)
    writeLines("\n##### Instructions for Templates #####\n")
    writeLines(paste0("Date: ", date(), "\n"))
    writeLines(paste0("## GeneList Template ##\n"))
    writeLines("There are at least THREE columns including 'Gene.ID', 'Type', and 'For', in the template.")
    writeLines("\tSerial.No: numerical order to indicate the serial number of each gene, usually start from 1.")
    writeLines("\tGene.ID: the gene identifier in the genome annotation file (GFF: general feature format) of certain species, e.g. Glyma.01G000100 in soybean. The Gene.ID should be exactly the gene identifier itself rather than its transcripts id (Glyma.01G000100.1)")
    writeLines("\tType: the type of features, e.g. 'CDS', 'promoter', 'gene', 'mRNA', 'five_prime_UTR', 'three_prime_UTR'.")
    writeLines("\tFor: the purpose of this analysis, could be one of 'Cloning', 'qRT-PCR', 'marker.development'.")
    writeLines("\n## END ##\n")
    sink(type = "output")
    
    ## FragmentList template
    fragmentList = data.frame(matrix(nrow = 10, ncol = 10))
    names(fragmentList) = c("Serial.No", "Fragment.ID", "Chr", "Start", "End", "Strand", "Length", "leftFlanking", "rightFlanking", "For")
    geneList$Serial.No = seq(1:nrow(fragmentList))
    fwrite(fragmentList, file = paste0(dir.path, "/Input.files/FragmentList.template.csv"), col.names = T, row.names = F, quote = F, sep = "\t")
    sink(file = paste0(dir.path, "/Input.files/Template.Instruction.txt"), type = "output", append = T)
    writeLines(paste0("\n## FragmentList Template ##\n"))
    writeLines("There are at least FOUR columns including 'Fragment.ID', 'Chr', 'Start', and 'End' in the template.")
    writeLines("\tSerial.No: numerical order to indicate the serial number of each fragment, usually start from 1.")
    writeLines("\tFragment.ID: a string indicates the fragment identifier, in which underline ('_') should be avoided as it has been used in the file names.")
    writeLines("\tChr: numeric value indicates chromosome number, e.g. 1, 2, 3, ...")
    writeLines("\tStart: numeric value indicates start position of the fragment.")
    writeLines("\tEnd: numeric value indicates end position of the fragment.")
    writeLines("\tStrand: '+' or '-' to indicate the strand of the fragment, If it is blank, '+' would be assigned to the fragment as default.")
    writeLines("\tLength: numeric vlaue indicates the length of fragment, which could be left blank.")
    writeLines("\tleftFlanking: numeric value indicates the length of left region to the fragment. If it is blank, 200bp would be assigned to 'leftFlanking' as default.")
    writeLines("\trightFlanking: numeric value indicates the length of right region to the fragment. If it is blank, 200bp would be assigned to 'rightFlanking' as default.")
    writeLines("\tFor: the purpose of this analysis, could be one of 'Cloning', 'qRT-PCR', 'marker.development'.")
    writeLines("\n## END ##\n")
    sink(type = "output")
    
    ## Indel template
    IndelList = data.frame(matrix(nrow = 10, ncol = 7))
    names(IndelList) = c("Serial.No", "Indel.Name", "Chr", "Start", "End", "leftFlanking", "rightFlanking")
    IndelList$Serial.No = seq(1:nrow(IndelList))
    fwrite(IndelList, file = paste0(dir.path, "/Input.files/IndelList.template.csv"), col.names = T, row.names = F, quote = F, sep = "\t")
    sink(file = paste0(dir.path, "/Input.files/Template.Instruction.txt"), type = "output", append = T)
    writeLines(paste0("\n## IndelList Template ##\n"))
    writeLines("There are at least FOUR columns including 'Indel.Name', 'Chr', 'Start', and 'End' in the template, Indel could only used for 'cloning' and 'marker.development'.")
    writeLines("\tSerial.No: numerical order to indicate the serial number of each Indel, usually start from 1.")
    writeLines("\tIndel.Name: a string indicates the Indel identifier, in which underline ('_') should be avoided as it has been used in the file names.")
    writeLines("\tChr: numeric value indicates chromosome number, e.g. 1, 2, 3, ...")
    writeLines("\tStart: numeric value indicates start position of the Indel.")
    writeLines("\tEnd: numeric value indicates end position of the Indel.")
    writeLines("\tleftFlanking: numeric value indicates the length of left region to the Indel. If it is blank, 200bp would be assigned to 'leftFlanking' as default.")
    writeLines("\trightFlanking: numeric value indicates the length of right region to the Indel. If it is blank, 200bp would be assigned to 'rightFlanking' as default.")
    writeLines("\n## END ##\n")
    sink(type = "output")
    
    ## SNP template
    SNPList = data.frame(matrix(nrow = 10, ncol = 6))
    names(SNPList) = c("Serial.No", "SNP.Name", "Chr", "Pos", "leftFlanking", "rightFlanking")
    IndelList$Serial.No = seq(1:nrow(SNPList))
    fwrite(SNPList, file = paste0(dir.path, "/Input.files/SNPList.template.csv"), col.names = T, row.names = F, quote = F, sep = "\t")
    sink(file = paste0(dir.path, "/Input.files/Template.Instruction.txt"), type = "output", append = T)
    writeLines(paste0("\n## SNPList Template ##\n"))
    writeLines("There are at least FOUR columns including 'SNP.Name', 'Chr', and 'Pos' in the template, SNP could only used for 'cloning' and 'marker.development'.")
    writeLines("\tSerial.No: numerical order to indicate the serial number of each SNP, usually start from 1.")
    writeLines("\tSNP.Name: a string indicates the SNP identifier, in which underline ('_') should be avoided as it has been used in the file names.")
    writeLines("\tChr: numeric value indicates chromosome number, e.g. 1, 2, 3, ...")
    writeLines("\tPos: numeric value indicates the position of the SNP.")
    writeLines("\tleftFlanking: numeric value indicates the length of left region to the SNP. If it is blank, 200bp would be assigned to 'leftFlanking' as default.")
    writeLines("\trightFlanking: numeric value indicates the length of right region to the SNP. If it is blank, 200bp would be assigned to 'rightFlanking' as default.")
    writeLines("\n## END ##\n")
    sink(type = "output")
  }
}


#' This is some description of this function.
#' @title to extract sequence related to gene
#'
#' @description By using this package, you could use function of gene.seq.extraction to extract sequence related to gene
#'
#' @details see above
#'
#' @param geneName: gene name alone or gene list file, which including two columns, namely, Gene.ID and Type. Type indicates the CDS, promoter, mRNA, gene, five_prime_UTR, three_prime_UTR or all (all types)
#' @param database: folder contains genome sequence in fasta format
#' @param gffFile: source data stores gene models and gene location on chromosome
#' @param type: a string to indicate the type of geneName, if no type has been assigned in the geneName file or for gene alone, default is 'all'. If 
#' @param promoterLength: numeric value indicate the length of promoter sequence to extract, default is 2000.
#' @param leftFlanking: numeric value indicates the left flanking region, default value is 200bp
#' @param rightFlanking: numeric value indicates the right flanking region, default value is 200bp.
#' @param For: string to indicate purpose of sequence, e.g. Cloning, qRT-PCR, marker.development.
#' @return files and folder
#' @export gene.seq.extraction
#' @examples gene.seq.extraction(database = "./soybean.genome/", gffFile = "./Wm82.a2.v1.gene.gff", geneName = "./gene.list.csv")
#' 

# gene.seq.extraction(database = "./soybean.genome/", gffFile = "./Wm82.a2.v1.gene.gff", geneName = "Glyma.20G148100", For = "Cloning")

# gene.seq.extraction(database = "./soybean.genome/", gffFile = "./Wm82.a2.v1.gene.gff", geneName = "./gene.list.csv")

gene.seq.extraction = function(database = NULL, geneName = NULL, gffFile = NULL, type = NULL, promoterLength = NULL, leftFlanking = NULL, rightFlanking = NULL, For = NULL, ...){
  
  library(data.table)
  library(Biostrings)
  library(stringr)
  
  dir.path = getwd()
  
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction"))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction"))
  }
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction"))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction"))
  }
  
  sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
  writeLines("\n######## Gene Sequence Extraction  ########")
  writeLines(paste0("\nDate: ", date()))
  if(file.exists(geneName)){
    writeLines(paste0("Information source: File\n"))
  }else{
    writeLines(paste0("Information source: parameters input manually\n"))
  }
  sink(type = "output")
  
  if(is.null(geneName)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Program is stopped! 'geneName'' is required!"))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'geneName' is required!")
  } 
  if(is.null(database)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Program is stopped! 'database' is required!"))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'database' is required!")
  } 
  if(is.null(gffFile)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Program is stopped! 'gffFile' is required!"))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'gffFile' is required!")
  } 
  
  if(is.null(promoterLength)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Warning: ", " 'promoterLength' is missing!", ". Dafault value of 2000bp is assigned to 'promoterLength'!"))
    sink(type = "output")
    promoterLength = 2000
  } 
  if(is.null(leftFlanking)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Warning: ", " 'leftFlanking' is missing!", ". Dafault value of 200bp is assigned to 'leftFlanking'!"))
    sink(type = "output")
    leftFlanking = 200
  } 
  if(is.null(rightFlanking)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Warning: ", " 'rightFlanking' is missing!", ". Dafault value of 200bp is assigned to 'rightFlanking'!"))
    sink(type = "output")
    rightFlanking = 200
  }
  
  
  # gff file read in
  gff = fread(gffFile, header = T, sep = "\t", fill = TRUE)
  if(ncol(gff) == 1){
    gff = fread(gffFile, header = T, sep = ",", fill = TRUE)
    if(ncol(gff) == 1){
      gff = fread(gffFile, header = T, sep = " ", fill = TRUE)
    }
  }
  
  if(length(grep("(Gene.ID|Chr|Start|End|Strand|Type)", names(gff))) == 6){
    gff = gff[,c("Gene.ID", "Chr", "Start", "End", "Strand", "Type")]
    type.length = length(unique(gff$Type))
    types = unique(gff$Type)[1]
    for(i in 2:length(unique(gff$Type))){
      types = paste0(types, ", ", unique(gff$Type)[i])
    }
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("gffFile contains ", nrow(gff), " rows, ", type.length, " types, including ", types))
    sink(type = "output")
  }else{
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Program is stopped!", " gff file should contain at least the following columns: 'Gene.ID', 'Chr', 'Start', 'End', 'Strand', and 'Type'! Please check your gff file format!"))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("gff file should contain at least the following columns: 'Gene.ID', 'Chr', 'Start', 'End', 'Strand', and 'Type'! Please check your gff file format!")
  }
  gff$Start = as.integer(gff$Start);gff$End = as.integer(gff$End)
  
  ## database read in 
  if(dir.exists(database)){
    database.dir = paste0(dir.path, "/", database, list.files(paste0(dir.path, "/", database)))
    if(length(database.dir) == 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
    }
    if(length(database.dir) > 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
      for(i in 2:length(database.dir)){
        temp = readDNAStringSet(database.dir[i], format = "fasta")
        DNAseq = append(DNAseq, temp)
      }
    }
  }
  
  ## sequence extraction
  if(file.exists(geneName)){
    if(length(grep(".csv|.txt", geneName)) == 1){
      geneList = fread(paste0(dir.path, "/", geneName), header = T, fill = TRUE)
    }
    if(length(grep(".xlsx", geneName)) == 1){
      geneList = data.frame(read.xlsx(paste0(dir.path, "/", geneName), header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
    }
    
    # file checking
    if(grep("Gene.ID", names(geneList)) != 1){
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0("Program is stopped!", " The first column of geneName file should be Gene.ID, please check your input data!"))
      writeLines("######## THE END  ########")
      sink(type = "output")
      stop("The first column of geneName file should be Gene.ID, please check your input data!")
    } 
    if(grep("Type", names(geneList)) != 2){
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0("Program is stopped!", " The second column of geneName file should be 'Type', which defines the type of sequence you want to extract, e.g. CDS, promoter, mRNA, all, or NA (equals to all), please check your input data!"))
      writeLines("######## THE END  ########")
      sink(type = "output")
      stop("The second column of geneName file should be 'Type', which defines the type of sequence you want to extract, e.g. CDS, promoter, mRNA, all, or NA (equals to all), please check your input data!")
    } 
    if(grep("For", names(geneList)) != 3){
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0("Program is stopped!", " The third column of geneName file should be 'For', which defines the purpose of sequence you want to extract, e.g. cloning, marker-development, qRT.PCR, please check your input data!"))
      writeLines("######## THE END  ########")
      sink(type = "output")
      stop("The third column of geneName file should be 'For', which defines the purpose of sequence you want to extract, e.g. cloning, marker-development, qRT.PCR, please check your input data!")
    }
    
    if(nrow(geneList) >= 1){
      # i = 1; j = 1
      for(i in 1:nrow(geneList)){
        gff.temp = gff[grep(geneList[i,1], gff$Gene.ID),]
        
        if(!is.null(geneName)){
          if(is.null(For)){
            For = geneList$For[i]
          }else{
            For = For
          }
        }
        
        if(nrow(gff.temp) >= 1){
          temp.list = unique(gff.temp$Gene.ID)
          transcript.list = temp.list[which(nchar(temp.list) == 17)]
          gene.name = temp.list[which(nchar(temp.list) == 15)]
          gff.temp.gene = gff.temp[which(gff.temp$Gene.ID == gene.name),]
          for(j in 1:length(transcript.list)){
            if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j]))){
              dir.create(paste0(dir.path, "/", "Sequence.extraction/","Gene.sequence.extraction/", transcript.list[j]))
            }
            gff.temp.1 = gff.temp[grep(transcript.list[j], gff.temp$Gene.ID),]
            gff.temp.five_UTR = gff.temp.1[which(gff.temp.1$Type == "five_prime_UTR"), ]
            gff.temp.three_UTR = gff.temp.1[which(gff.temp.1$Type == "three_prime_UTR"), ]
            gff.temp.CDS = gff.temp.1[which(gff.temp.1$Type == "CDS"), ]
            gff.temp.mRNA = gff.temp.1[which(gff.temp.1$Type == "mRNA"), ]
            if(nrow(gff.temp.mRNA) >= 1){
              gff.temp.promoter = gff.temp.mRNA
            }else{
              gff.temp.promoter = gff.temp.gene
            }
            gff.temp.promoter$Type[1] = "promoter"
            if(nrow(gff.temp.mRNA) >= 1){
              if(gff.temp.promoter$Strand[1] == "+"){
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = min(gff.temp.five_UTR$Start) - promoterLength - 1
                  gff.temp.promoter$End[1] = min(gff.temp.five_UTR$Start) - 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.mRNA$Start[1] - promoterLength - 1
                  gff.temp.promoter$End[1] = gff.temp.mRNA$Start[1] - 1
                }
              }else{
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = max(gff.temp.five_UTR$End) + 1
                  gff.temp.promoter$End[1] = max(gff.temp.five_UTR$End) + promoterLength + 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.mRNA$End[1] + 1
                  gff.temp.promoter$End[1] = gff.temp.mRNA$End[1] + promoterLength + 1
                }
              }
            }else{
              if(gff.temp.promoter$Strand[1] == "+"){
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = min(gff.temp.five_UTR$Start) - promoterLength - 1
                  gff.temp.promoter$End[1] = min(gff.temp.five_UTR$Start) - 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.gene$Start[1] - promoterLength - 1
                  gff.temp.promoter$End[1] = gff.temp.gene$Start[1] - 1
                }
              }else{
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = max(gff.temp.five_UTR$End) + 1
                  
                  gff.temp.promoter$End[1] = max(gff.temp.five_UTR$End) + promoterLength + 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.gene$End[1] + 1
                  gff.temp.promoter$End[1] = gff.temp.gene$End[1] + promoterLength + 1
                }
              }
            }
            
            if(!is.null(geneName)){
              if(is.null(type)){
                type = as.character(geneList[i,2])
              }else{
                type = type
              }
            }
            
            if(For == "qRT-PCR" & type != "mRNA"){
              type = "mRNA"
              cat(paste0("'For' of ", geneList[i,1], " is 'qRT-PCR', which DOES NOT match by 'type' ", type, " so, 'type' has been corrected into 'mRNA'"))
            }
            
            ## CDS extraction
            if(length(grep("CDS", type)) == 1 | type == "all"){
              if(nrow(gff.temp.CDS) >= 1){
                gff.temp.CDS = gff.temp.CDS[order(Start)]
                DNAseq.temp = DNAseq[gff.temp.CDS$Chr[1]]
                cds = as.character(subseq(DNAseq.temp, start = gff.temp.CDS$Start[1], end = gff.temp.CDS$End[1]))
                # k = 2
                if(nrow(gff.temp.CDS) >= 2){
                  for(k in 2:nrow(gff.temp.CDS)){
                    cds.temp = as.character(subseq(DNAseq.temp, start = gff.temp.CDS$Start[k], end = gff.temp.CDS$End[k]))
                    cds = paste0(cds, cds.temp)
                  }
                }
                cds.left = as.character(subseq(DNAseq.temp, start = min(gff.temp.CDS$Start) - leftFlanking, end = min(gff.temp.CDS$Start)))
                cds.right = as.character(subseq(DNAseq.temp, start = max(gff.temp.CDS$End), end = max(gff.temp.CDS$End) + rightFlanking))
                cds = paste0(cds.left, cds, cds.right)
                if(gff.temp.gene$Strand[1] == "+"){
                  cds = DNAStringSet(cds)
                }else{
                  cds = reverseComplement(DNAStringSet(cds))
                }
                names(cds) = paste0(transcript.list[j], "_CDS_", gff.temp.CDS$Chr[1], "_", min(gff.temp.CDS$Start), "..", max(gff.temp.CDS$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(cds, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j], "/", transcript.list[j], "_CDS_", gff.temp.CDS$Chr[1], "_", min(gff.temp.CDS$Start), "..", max(gff.temp.CDS$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.CDS$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The CDS of ", transcript.list[j], " has not been defined by GFF file!"))
                sink(type = "output")
                warning(paste0("The CDS of ", transcript.list[j], " has not been defined by GFF file!"))
              }
            }
            
            ## mRNA
            if(length(grep("mRNA", type)) == 1 | type == "all"){
              if(nrow(gff.temp.mRNA) >= 1){
                gff.temp.mRNA = rbind(gff.temp.five_UTR, gff.temp.three_UTR, gff.temp.CDS)
                gff.temp.mRNA = gff.temp.mRNA[order(Start)]
                DNAseq.temp = DNAseq[gff.temp.mRNA$Chr[1]]
                mRNA = as.character(subseq(DNAseq.temp, start = gff.temp.mRNA$Start[1], end = gff.temp.mRNA$End[1]))
                for(k in 2:nrow(gff.temp.mRNA)){
                  mRNA.temp = as.character(subseq(DNAseq.temp, start = gff.temp.mRNA$Start[k], end = gff.temp.mRNA$End[k]))
                  mRNA = paste0(mRNA, mRNA.temp)
                }
                mRNA.left = as.character(subseq(DNAseq.temp, start = min(gff.temp.mRNA$Start) - leftFlanking, end = min(gff.temp.mRNA$Start)))
                mRNA.right = as.character(subseq(DNAseq.temp, start = max(gff.temp.mRNA$End), end = max(gff.temp.mRNA$End) + rightFlanking))
                mRNA = paste0(mRNA.left, mRNA, mRNA.right)
                if(gff.temp.gene$Strand[1] == "+"){
                  mRNA = DNAStringSet(mRNA)
                }else{
                  mRNA = reverseComplement(DNAStringSet(mRNA))
                }
                names(mRNA) = paste0(transcript.list[j], "_mRNA_", gff.temp.mRNA$Chr[1], "_", min(gff.temp.mRNA$Start), "..", max(gff.temp.mRNA$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(mRNA, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j], "/", transcript.list[j], "_mRNA_", gff.temp.mRNA$Chr[1], "_", min(gff.temp.mRNA$Start), "..", max(gff.temp.mRNA$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.mRNA$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The mRNA of ", transcript.list[j], " has not been defined by GFF file, probably CDS sequence of this gene could be regarded as mRNA!"))
                sink(type = "output")
                warning(paste0("The mRNA of ", transcript.list[j], " has not been defined by GFF file, probably CDS sequence of this gene could be regarded as mRNA!"))
              }
            }
            
            ## gene sequence
            if(length(grep("gene", type)) == 1 | type == "all"){
              if(nrow(gff.temp.gene) >= 1){
                DNAseq.temp = DNAseq[gff.temp.gene$Chr[1]]
                gene = as.character(subseq(DNAseq.temp, start = gff.temp.gene$Start[1], end = gff.temp.gene$End[1]))
                gene.left = as.character(subseq(DNAseq.temp, start = gff.temp.gene$Start[1] - leftFlanking, end = gff.temp.gene$Start[1]))
                gene.right = as.character(subseq(DNAseq.temp, start = gff.temp.gene$End[1], end = gff.temp.gene$End[1] + rightFlanking))
                gene = paste0(gene.left, gene, gene.right)
                if(gff.temp.gene$Strand[1] == "+"){
                  gene = DNAStringSet(gene)
                }else{
                  gene = reverseComplement(DNAStringSet(gene))
                }
                names(gene) = paste0(transcript.list[j], "_gene_", gff.temp.gene$Chr[1], "_", gff.temp.gene$Start[1], "..", gff.temp.gene$End[1], "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(gene, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j], "/", transcript.list[j], "_gene_", gff.temp.gene$Chr[1], "_", gff.temp.gene$Start[1], "..", gff.temp.gene$End[1], "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.gene$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The gene of ", transcript.list[j], " has not been defined by GFF file, probably something went wrong!"))
                sink(type = "output")
                warning(paste0("The gene of ", transcript.list[j], " has not been defined by GFF file, probably something went wrong!"))
              }
            }
            
            ## promoter sequence
            if(length(grep("promoter", type)) == 1 | type == "all"){
              if(nrow(gff.temp.promoter) >= 1){
                DNAseq.temp = DNAseq[gff.temp.promoter$Chr[1]]
                promoter = as.character(subseq(DNAseq.temp, start = gff.temp.promoter$Start[1] - leftFlanking, end = gff.temp.promoter$End[1] + rightFlanking))
                if(gff.temp.promoter$Strand[1] == "+"){
                  promoter = DNAStringSet(promoter)
                }else{
                  promoter = reverseComplement(DNAStringSet(promoter))
                }
                names(promoter) = paste0(transcript.list[j], "_promoter_", gff.temp.promoter$Chr[1], "_", min(gff.temp.promoter$Start), "..", max(gff.temp.promoter$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(promoter, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j], "/", transcript.list[j], "_promoter_", gff.temp.promoter$Chr[1], "_", min(gff.temp.promoter$Start), "..", max(gff.temp.promoter$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.promoter$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The promoter of ", transcript.list[j], " could not be defined based on GFF file, probably something went wrong!"))
                sink(type = "output")
                warning(paste0("The promoter of ", transcript.list[j], " could not be defined based on GFF file, probably something went wrong!"))
              }
            }
            
            ## five prime UTR
            if(length(grep("five_prime_UTR", type)) == 1 | type == "all"){
              if(nrow(gff.temp.five_UTR) >= 1){
                gff.temp.five_UTR = gff.temp.five_UTR[order(Start)]
                DNAseq.temp = DNAseq[gff.temp.five_UTR$Chr[1]]
                five = as.character(subseq(DNAseq.temp, start = gff.temp.five_UTR$Start[1], end = gff.temp.five_UTR$End[1]))
                if(nrow(gff.temp.five_UTR) >= 2){
                  for(k in 2:nrow(gff.temp.five_UTR)){
                    five.temp = as.character(subseq(DNAseq.temp, start = gff.temp.five_UTR$Start[k], end = gff.temp.five_UTR$End[k]))
                    five = paste0(five, five.temp)
                  }
                }
                five.left = as.character(subseq(DNAseq.temp, start = min(gff.temp.five_UTR$Start) - leftFlanking, end = min(gff.temp.five_UTR$Start)))
                five.right = as.character(subseq(DNAseq.temp, start = max(gff.temp.five_UTR$End), end = max(gff.temp.five_UTR$End) + rightFlanking))
                five = paste0(five.left, five, five.right)
                if(gff.temp.five_UTR$Strand[1] == "+"){
                  five = DNAStringSet(five)
                }else{
                  five = reverseComplement(DNAStringSet(five))
                }
                names(five) = paste0(transcript.list[j], "_five.prime.UTR_", gff.temp.five_UTR$Chr[1], "_", min(gff.temp.five_UTR$Start), "..", max(gff.temp.five_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(five, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j], "/", transcript.list[j], "_five.prime.UTR_", gff.temp.five_UTR$Chr[1], "_", min(gff.temp.five_UTR$Start), "..", max(gff.temp.five_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.five_UTR$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The five_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
                sink(type = "output")
                warning(paste0("The five_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
              }
            }
            
            ## three prime UTR
            if(length(grep("three_prime_UTR", type)) == 1 | type == "all"){
              if(nrow(gff.temp.three_UTR) >= 1){
                gff.temp.three_UTR = gff.temp.three_UTR[order(Start)]
                DNAseq.temp = DNAseq[gff.temp.three_UTR$Chr[1]]
                three = as.character(subseq(DNAseq.temp, start = gff.temp.three_UTR$Start[1], end = gff.temp.three_UTR$End[1]))
                if(nrow(gff.temp.three_UTR) >= 2){
                  for(k in 2:nrow(gff.temp.three_UTR)){
                    three.temp = as.character(subseq(DNAseq.temp, start = gff.temp.three_UTR$Start[k], end = gff.temp.three_UTR$End[k]))
                    three = paste0(three, three.temp)
                  }
                }
                three.left = as.character(subseq(DNAseq.temp, start = min(gff.temp.three_UTR$Start) - leftFlanking, end = min(gff.temp.three_UTR$Start)))
                three.right = as.character(subseq(DNAseq.temp, start = max(gff.temp.three_UTR$End), end = max(gff.temp.three_UTR$End) + rightFlanking))
                three = paste0(three.left, three, three.right)
                if(gff.temp.three_UTR$Strand[1] == "+"){
                  three = DNAStringSet(three)
                }else{
                  three = reverseComplement(DNAStringSet(three))
                }
                names(three) = paste0(transcript.list[j], "_three.prime.UTR_", gff.temp.three_UTR$Chr[1], "_", min(gff.temp.three_UTR$Start), "..", max(gff.temp.three_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(three, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j], "/", transcript.list[j], "_three.prime.UTR_", gff.temp.three_UTR$Chr[1], "_", min(gff.temp.three_UTR$Start), "..", max(gff.temp.three_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.three_UTR$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The three_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
                sink(type = "output")
                warning(paste0("The three_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
              }
            }
          }
        }else{
          sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
          writeLines(paste0("Warning: ", "The ", geneList[i], " has not been defined by GFF file!"))
          sink(type = "output")
          warning(paste0("The ", geneList[i], " has not been defined by GFF file!"))
          next;
        }
      }
    }
  }
  
  if(!file.exists(geneName)){
    gene.temp = str_extract_all(geneName, "Glyma.[0-9][0-9]G[0-9][0-9][0-9][0-9][0-9][0-9]")
    if(is.null(For)) For = "Cloning"
    if(is.null(type)){
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0("Warning: ", " 'type' is missing!", ". Dafault value of 'all' is assigned to 'type'!"))
      sink(type = "output")
      type = "all"
    } 
    
    geneList = c()
    geneList.c = c()
    for(i in 1:length(gene.temp)){
      geneList = c(geneList, gene.temp[[i]])
      geneList.c = paste0(geneList.c, "; ", gene.temp[[i]])
    }
    geneList.c = gsub("^; ", "", geneList.c)
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("\nGene List: ", geneList.c))
    writeLines(paste0("\tType: ", type))
    writeLines(paste0("\tPromoterLength: ", promoterLength, "bp"))
    writeLines(paste0("\tleftFlanking: ", leftFlanking, "bp"))
    writeLines(paste0("\trightFlanking: ", rightFlanking, "bp"))
    sink(type = "output")
    
    if(length(geneList) >= 1){
      # i = 1; j = 1
      for(i in 1:length(geneList)){
        gff.temp = gff[grep(geneList[i], gff$Gene.ID),]
        if(For == "qRT-PCR" & type != "mRNA"){
          type = "mRNA"
          cat(paste0("'For' of ", geneList[i,1], " is 'qRT-PCR', which DOES NOT match by 'type' ", type, " so, 'type' has been corrected into 'mRNA'"))
        }
        if(nrow(gff.temp) >= 1){
          temp.list = unique(gff.temp$Gene.ID)
          transcript.list = temp.list[which(nchar(temp.list) == 17)]
          gene.name = temp.list[which(nchar(temp.list) == 15)]
          gff.temp.gene = gff.temp[which(gff.temp$Gene.ID == gene.name),]
          for(j in 1:length(transcript.list)){
            if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j]))){
              dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j]))
            }
            gff.temp.1 = gff.temp[grep(transcript.list[j], gff.temp$Gene.ID),]
            gff.temp.five_UTR = gff.temp.1[which(gff.temp.1$Type == "five_prime_UTR"), ]
            gff.temp.three_UTR = gff.temp.1[which(gff.temp.1$Type == "three_prime_UTR"), ]
            gff.temp.CDS = gff.temp.1[which(gff.temp.1$Type == "CDS"), ]
            gff.temp.mRNA = gff.temp.1[which(gff.temp.1$Type == "mRNA"), ]
            if(nrow(gff.temp.mRNA) >= 1){
              gff.temp.promoter = gff.temp.mRNA
            }else{
              gff.temp.promoter = gff.temp.gene
            }
            gff.temp.promoter$Type = "promoter"
            if(nrow(gff.temp.mRNA) >= 1){
              if(gff.temp.promoter$Strand[1] == "+"){
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = min(gff.temp.five_UTR$Start) - promoterLength - 1
                  gff.temp.promoter$End[1] = min(gff.temp.five_UTR$Start) - 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.mRNA$Start[1] - promoterLength - 1
                  gff.temp.promoter$End[1] = gff.temp.mRNA$Start[1] - 1
                }
              }else{
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = max(gff.temp.five_UTR$End) + 1
                  
                  gff.temp.promoter$End[1] = max(gff.temp.five_UTR$End) + promoterLength + 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.mRNA$End[1] + 1
                  gff.temp.promoter$End[1] = gff.temp.mRNA$End[1] + promoterLength + 1
                }
              }
            }else{
              if(gff.temp.promoter$Strand[1] == "+"){
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = min(gff.temp.five_UTR$Start) - promoterLength - 1
                  gff.temp.promoter$End[1] = min(gff.temp.five_UTR$Start) - 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.gene$Start[1] - promoterLength - 1
                  gff.temp.promoter$End[1] = gff.temp.gene$Start[1] - 1
                }
              }else{
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = max(gff.temp.five_UTR$End) + 1
                  
                  gff.temp.promoter$End[1] = max(gff.temp.five_UTR$End) + promoterLength + 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.gene$End[1] + 1
                  gff.temp.promoter$End[1] = gff.temp.gene$End[1] + promoterLength + 1
                }
              }
            }
            
            ## CDS extraction
            if(length(grep("CDS", type)) == 1 | type == "all"){
              if(nrow(gff.temp.CDS) >= 1){
                gff.temp.CDS = gff.temp.CDS[order(Start)]
                DNAseq.temp = DNAseq[gff.temp.CDS$Chr[1]]
                cds = as.character(subseq(DNAseq.temp, start = gff.temp.CDS$Start[1], end = gff.temp.CDS$End[1]))
                # k = 2
                if(nrow(gff.temp.CDS) >= 2){
                  for(k in 2:nrow(gff.temp.CDS)){
                    cds.temp = as.character(subseq(DNAseq.temp, start = gff.temp.CDS$Start[k], end = gff.temp.CDS$End[k]))
                    cds = paste0(cds, cds.temp)
                  }
                }
                cds.left = as.character(subseq(DNAseq.temp, start = gff.temp.CDS$Start[k] - leftFlanking, end = gff.temp.CDS$Start[k]))
                cds.right = as.character(subseq(DNAseq.temp, start = gff.temp.CDS$End[k], end = gff.temp.CDS$End[k] + rightFlanking))
                cds = paste0(cds.left, cds, cds.right)
                if(gff.temp.gene$Strand[1] == "+"){
                  cds = DNAStringSet(cds)
                }else{
                  cds = reverseComplement(DNAStringSet(cds))
                }
                names(cds) = paste0(transcript.list[j], "_CDS_", gff.temp.CDS$Chr[1], "_", min(gff.temp.CDS$Start), "..", max(gff.temp.CDS$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(cds, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j], "/", transcript.list[j], "_CDS_", gff.temp.CDS$Chr[1], "_", min(gff.temp.CDS$Start), "..", max(gff.temp.CDS$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.CDS$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The CDS of ", transcript.list[j], " has not been defined by GFF file!"))
                sink(type = "output")
                warning(paste0("The CDS of ", transcript.list[j], " has not been defined by GFF file!"))
              }
            }
            
            ## mRNA
            if(length(grep("mRNA", type)) == 1 | type == "all"){
              if(nrow(gff.temp.mRNA) >= 1){
                gff.temp.mRNA = rbind(gff.temp.five_UTR, gff.temp.three_UTR, gff.temp.CDS)
                gff.temp.mRNA = gff.temp.mRNA[order(Start)]
                gff.temp.mRNA$Start = as.integer(gff.temp.mRNA$Start)
                gff.temp.mRNA$End = as.integer(gff.temp.mRNA$End)
                DNAseq.temp = DNAseq[gff.temp.mRNA$Chr[1]]
                mRNA = as.character(subseq(DNAseq.temp, start = gff.temp.mRNA$Start[1], end = gff.temp.mRNA$End[1]))
                for(k in 2:nrow(gff.temp.mRNA)){
                  mRNA.temp = as.character(subseq(DNAseq.temp, start = gff.temp.mRNA$Start[k], end = gff.temp.mRNA$End[k]))
                  mRNA = paste0(mRNA, mRNA.temp)
                }
                mRNA.left = as.character(subseq(DNAseq.temp, start = min(gff.temp.mRNA$Start) - leftFlanking, end = min(gff.temp.mRNA$Start)))
                mRNA.right = as.character(subseq(DNAseq.temp, start = max(gff.temp.mRNA$End), end = max(gff.temp.mRNA$End) + rightFlanking))
                mRNA = paste0(mRNA.left, mRNA, mRNA.right)
                if(gff.temp.gene$Strand[1] == "+"){
                  mRNA = DNAStringSet(mRNA)
                }else{
                  mRNA = reverseComplement(DNAStringSet(mRNA))
                }
                names(mRNA) = paste0(transcript.list[j], "_mRNA_", gff.temp.mRNA$Chr[1], "_", min(gff.temp.mRNA$Start), "..", max(gff.temp.mRNA$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(mRNA, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j], "/", transcript.list[j], "_mRNA_", gff.temp.mRNA$Chr[1], "_", min(gff.temp.mRNA$Start), "..", max(gff.temp.mRNA$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.mRNA$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The mRNA of ", transcript.list[j], " has not been defined by GFF file, probably CDS sequence of this gene could be regarded as mRNA!"))
                sink(type = "output")
                warning(paste0("The mRNA of ", transcript.list[j], " has not been defined by GFF file, probably CDS sequence of this gene could be regarded as mRNA!"))
              }
            }
            
            ## gene sequence
            if(length(grep("gene", type)) == 1 | type == "all"){
              if(nrow(gff.temp.gene) >= 1){
                DNAseq.temp = DNAseq[gff.temp.gene$Chr[1]]
                gene = as.character(subseq(DNAseq.temp, start = gff.temp.gene$Start[1], end = gff.temp.gene$End[1]))
                gene.left = as.character(subseq(DNAseq.temp, start = gff.temp.gene$Start[1] - leftFlanking, end = gff.temp.gene$Start[1]))
                gene.right = as.character(subseq(DNAseq.temp, start = gff.temp.gene$End[1], end = gff.temp.gene$End[1] + rightFlanking))
                gene = paste0(gene.left, gene, gene.right)
                if(gff.temp.gene$Strand[1] == "+"){
                  gene = DNAStringSet(gene)
                }else{
                  gene = reverseComplement(DNAStringSet(gene))
                }
                names(gene) = paste0(transcript.list[j], "_gene_", gff.temp.gene$Chr[1], "_", gff.temp.gene$Start[1], "..", gff.temp.gene$End[1], "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(gene, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j], "/", transcript.list[j], "_gene_", gff.temp.gene$Chr[1], "_", gff.temp.gene$Start[1], "..", gff.temp.gene$End[1], "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.gene$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The gene of ", transcript.list[j], " has not been defined by GFF file, probably something went wrong!"))
                sink(type = "output")
                warning(paste0("The gene of ", transcript.list[j], " has not been defined by GFF file, probably something went wrong!"))
              }
            }
            
            ## promoter sequence
            if(length(grep("promoter", type)) == 1 | type == "all"){
              if(nrow(gff.temp.promoter) >= 1){
                DNAseq.temp = DNAseq[gff.temp.promoter$Chr[1]]
                promoter = as.character(subseq(DNAseq.temp, start = gff.temp.promoter$Start[1], end = gff.temp.promoter$End[1]))
                promoter = as.character(subseq(DNAseq.temp, start = gff.temp.promoter$Start[1] - leftFlanking, end = gff.temp.promoter$End[1] + rightFlanking))
                if(gff.temp.promoter$Strand[1] == "+"){
                  promoter = DNAStringSet(promoter)
                }else{
                  promoter = reverseComplement(DNAStringSet(promoter))
                }
                names(promoter) = paste0(transcript.list[j], "_promoter_", gff.temp.promoter$Chr[1], "_", min(gff.temp.promoter$Start), "..", max(gff.temp.promoter$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(promoter, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j], "/", transcript.list[j], "_promoter_", gff.temp.promoter$Chr[1], "_", min(gff.temp.promoter$Start), "..", max(gff.temp.promoter$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.promoter$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The promoter of ", transcript.list[j], " could not be defined based on GFF file, probably something went wrong!"))
                sink(type = "output")
                warning(paste0("The promoter of ", transcript.list[j], " could not be defined based on GFF file, probably something went wrong!"))
              }
            }
            
            ## five prime UTR
            if(length(grep("five_prime_UTR", type)) == 1 | type == "all"){
              if(nrow(gff.temp.five_UTR) >= 1){
                gff.temp.five_UTR = gff.temp.five_UTR[order(Start)]
                DNAseq.temp = DNAseq[gff.temp.five_UTR$Chr[1]]
                five = as.character(subseq(DNAseq.temp, start = min(gff.temp.five_UTR$Start[1]), end = max(gff.temp.five_UTR$End[1])))
                if(nrow(gff.temp.five_UTR) >= 2){
                  for(k in 2:nrow(gff.temp.five_UTR)){
                    five.temp = as.character(subseq(DNAseq.temp, start = min(gff.temp.five_UTR$Start[k]), end = max(gff.temp.five_UTR$End[k])))
                    five = paste0(five, five.temp)
                  }
                }
                five.left = as.character(subseq(DNAseq.temp, start = min(gff.temp.five_UTR$Start) - leftFlanking, end = min(gff.temp.five_UTR$Start)))
                five.right = as.character(subseq(DNAseq.temp, start = max(gff.temp.five_UTR$End), end = max(gff.temp.five_UTR$End) + rightFlanking))
                five = paste0(five.left, five, five.right)
                if(gff.temp.five_UTR$Strand[1] == "+"){
                  five = DNAStringSet(five)
                }else{
                  five = reverseComplement(DNAStringSet(five))
                }
                names(five) = paste0(transcript.list[j], "_five.prime.UTR_", gff.temp.five_UTR$Chr[1], "_", min(gff.temp.five_UTR$Start), "..", max(gff.temp.five_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(five, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j], "/", transcript.list[j], "_five.prime.UTR_", gff.temp.five_UTR$Chr[1], "_", min(gff.temp.five_UTR$Start), "..", max(gff.temp.five_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.five_UTR$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The five_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
                sink(type = "output")
                warning(paste0("The five_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
              }
            }
            
            ## three prime UTR
            if(length(grep("three_prime_UTR", type)) == 1 | type == "all"){
              if(nrow(gff.temp.three_UTR) >= 1){
                gff.temp.three_UTR = gff.temp.three_UTR[order(Start)]
                DNAseq.temp = DNAseq[gff.temp.three_UTR$Chr[1]]
                three = as.character(subseq(DNAseq.temp, start = gff.temp.three_UTR$Start[1], end = gff.temp.three_UTR$End[1]))
                if(nrow(gff.temp.three_UTR) >= 2){
                  for(k in 2:nrow(gff.temp.three_UTR)){
                    three.temp = as.character(subseq(DNAseq.temp, start = gff.temp.three_UTR$Start[k], end = gff.temp.three_UTR$End[k]))
                    three = paste0(three, three.temp)
                  }
                }
                three.left = as.character(subseq(DNAseq.temp, start = min(gff.temp.three_UTR$Start) - leftFlanking, end = min(gff.temp.three_UTR$Start)))
                three.right = as.character(subseq(DNAseq.temp, start = max(gff.temp.three_UTR$End), end = max(gff.temp.three_UTR$End) + rightFlanking))
                three = paste0(three.left, three, three.right)
                if(gff.temp.three_UTR$Strand[1] == "+"){
                  three = DNAStringSet(three)
                }else{
                  three = reverseComplement(DNAStringSet(three))
                }
                names(three) = paste0(transcript.list[j], "_three.prime.UTR_", gff.temp.three_UTR$Chr[1], "_", min(gff.temp.three_UTR$Start), "..", max(gff.temp.three_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(three, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", transcript.list[j], "/", transcript.list[j], "_three.prime.UTR_", gff.temp.three_UTR$Chr[1], "_", min(gff.temp.three_UTR$Start), "..", max(gff.temp.three_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.three_UTR$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The three_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
                sink(type = "output")
                warning(paste0("The three_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
              }
            }
          }
        }else{
          sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
          writeLines(paste0("Warning: ", "The ", geneList[i], " has not been defined by GFF file!"))
          sink(type = "output")
          warning(paste0("The ", geneList[i], " has not been defined by GFF file!"))
          next;
        }
      }
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0("\nSequence extraction parameters for: ", geneList[i]))
      writeLines(paste0("\tType: ", type))
      sink(type = "output")
    }
  }
  sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene.sequence.extraction/", "gene.seq.extraction.log"), type = "output", append = TRUE)
  writeLines("\n######## THE END  ########")
  sink(type = "output")
  cat("\nCongratulation! gene.seq.extraction is DONE!")
}


#' This is some description of this function.
#' @title to extract fragment sequence from genome based on an input file defining certain parameters. 
#'
#' @description By using this package, you could use function of fragment.seq.extraction.1 to extract fragment sequence from genome based on an input file defining certain parameters. 'fragment' is defined as a fragment sequence other than annotated gene, however a annotated gene could be regarded as a fragment as well.
#'
#' @details see above
#'
#' @param fragmentFile: fragment file, including at least 'Fragment.ID', 'Chr', 'Start', 'End', 'Strand', 'Length', 'leftFlanking', 'rightFlanking', of which 'Fragment.ID', 'Chr', 'Start' and 'End' are required to be specified. The program would assign default value of '+', 'end - start', 200, and 200 for 'Strand', 'Length', 'leftFlanking', and 'rightFlanking' respectively. This file could be in format of *.csv, .txt, .xlsx, if .xlsx format was used parameters should be put in 'Sheet1' as default.
#' @param database: folder or file contains genome sequence in fasta format.
#' @param For: string to indicate the purpose of sequence extraction. Default value is 'Cloning'.
#' @return fasta files, log file stored in ".../Sequence.extraction/Fragment.sequence.extraction/"
#' @export fragment.seq.extraction.1
#' @examples fragment.seq.extraction.1(database = "./soybean.genome/", fragmentFile = "./fragment.seq.extraction.parameter.xlsx")
#' 

###### NOTES ######
# fragment.seq.extraction.1.R is to extract sequence from database from a file
######  END  ######


# fragment.seq.extraction.1(database = "./soybean.genome/", fragmentFile = "./fragment.seq.extraction.parameter.xlsx")

fragment.seq.extraction.1 = function(database = NULL, fragmentFile = NULL, For = NULL, ...){
  
  library(data.table)
  library(Biostrings)
  library(stringr)
  
  dir.path = getwd()
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction"))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction"))
  }
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction"))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction"))
  }
  
  sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
  writeLines("\n######## Fragment Sequence Extraction  ########")
  writeLines(paste0("\nDate: ", date()))
  writeLines(paste0("Information source: fragment file\n"))
  sink(type = "output")
  
  if(is.null(fragmentFile)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0('Program is stopped! fragmentFile is required!'))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'fragmentFile' is required!")
  } 
  if(is.null(database)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0('Program is stopped! Database is required!'))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'database' is required!")
  } 
  if(is.null(For)) For = "Cloning"
  
  ## database read in 
  if(dir.exists(database)){
    database.dir = paste0(dir.path, "/", database, list.files(paste0(dir.path, "/", database)))
    if(length(database.dir) == 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
    }
    if(length(database.dir) > 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
      for(i in 2:length(database.dir)){
        temp = readDNAStringSet(database.dir[i], format = "fasta")
        DNAseq = append(DNAseq, temp)
      }
    }
  }
  if(!dir.exists(database)){
    DNAseq = readDNAStringSet(database, format = "fasta")
  }
  
  ## fragmentFile read in 
  if(file.exists(fragmentFile)){
    if(length(grep(".csv|.txt", fragmentFile)) == 1){
      fragmentList = fragmentList = fread(paste0(dir.path, "/", fragmentFile), header = T, sep = "\t", fill = TRUE)
      if(ncol(fragmentList) == 1){
        fragmentList = fread(paste0(dir.path, "/", fragmentFile), header = T, sep = ",", fill = TRUE)
        if(ncol(fragmentList) == 1){
          fragmentList = fread(paste0(dir.path, "/", fragmentFile), header = T, sep = " ", fill = TRUE)
        }
      }
    }
    if(length(grep(".xlsx", fragmentFile)) == 1){
      fragmentList = data.frame(read.xlsx(paste0(dir.path, "/", fragmentFile), header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
    }
    if(length(grep("Fragment.ID|Chr|Start|End|Strand|Length|leftFlanking|rightFlanking", names(fragmentList))) != 8){
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0('Program is stopped! The fragmentFile should contain at least: Fragment.ID, Chr, Start, End, Strand, Length, leftFlanking, rightFlanking, please check your input data!'))
      writeLines("######## THE END  ########")
      sink(type = "output")
      stop("the 'fragmentFile' should contain at least 'Fragment.ID, Chr, Start, End, Strand, Length, leftFlanking, rightFlanking', please check your input data!")
    }else{
      cat("The format of 'fragmentFile' file is correct!")
    }
  }
  
  fragmentFile.name = gsub(".csv|.txt|.xlsx", "", strsplit(fragmentFile, "/")[[1]][length(strsplit(fragmentFile, "/")[[1]])])
  
  ## sequence extraction
  if(nrow(fragmentList) >= 1){
    # i = 1
    for(i in 1:nrow(fragmentList)){
      # parameter checking
      if(is.null(fragmentList$Fragment.ID[i])  | setequal(NA, fragmentList$Fragment.ID[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0('Program is stopped!', " 'Fragment.ID' is missing in row ", i, " of ", fragmentFile.name, "."))
        writeLines("######## THE END  ########")
        sink(type = "output")
        stop(paste0("'Fragment.ID' is missing in row ", i, " of ", fragmentFile.name))
      }else{
        fragmentID = fragmentList$Fragment.ID[i]
        if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/Fragment.sequence.extraction/", fragmentID))){
          dir.create(paste0(dir.path, "/", "Sequence.extraction/Fragment.sequence.extraction/", fragmentID))
        }
      }
      
      if(is.null(fragmentList$Chr[i]) | setequal(NA, fragmentList$Chr[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0('Program is stopped!', " 'Chr' is missing in row ", i, " of ", fragmentFile.name, "."))
        writeLines("######## THE END  ########")
        sink(type = "output")
        stop(paste0("'Chr' is missing in row ", i, " of ", fragmentFile.name))
      }else{
        chr = fragmentList$Chr[i]
        chr.format = names(DNAseq)[1]
        chr.format = str_extract_all(chr.format, "(Chr|Gm)")[[1]]
        if(length(grep(chr.format, chr)) == 0){
          if(is.numeric(chr)){
            chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
          }else{
            chr = as.numeric(gsub("Chr|Gm", "", chr))
            chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
          }
        }
      }
      
      if(is.null(fragmentList$Start[i]) | setequal(NA, fragmentList$Start[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0('Program is stopped!', " 'Start' is missing in row ", i, " of ", fragmentFile.name, "."))
        writeLines("######## THE END  ########")
        sink(type = "output")
        stop(paste0("'Start' is missing in row ", i, " of ", fragmentFile.name))
      }else{start = fragmentList$Start[i]}
      
      if(is.null(fragmentList$End[i]) | setequal(NA, fragmentList$End[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0('Program is stopped!', " 'End' is missing in row ", i, " of ", fragmentFile.name, "."))
        writeLines("######## THE END  ########")
        sink(type = "output")
        stop(paste0("'End' is missing in row ", i, " of ", fragmentFile.name))
      }else{end = fragmentList$End[i]}
      
      if(is.null(fragmentList$Strand[i])  | setequal(NA, fragmentList$Strand[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0("Warning: ", "'Strand' is missing in row ", i, " of ", fragmentFile.name, ". Default value of '+' has been assigned to strand!"))
        sink(type = "output")
        warning(paste0("'Strand' is missing in row ", i, " of ", fragmentFile.name, ". Default value of '+' has been assigned to strand!"))
        strand = "+"
      }else{strand = fragmentList$Strand[i]}
      if(is.null(fragmentList$Length[i]) | setequal(NA, fragmentList$Length[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0("Warning: ", "'Length' is missing in row ", i, " of ", fragmentFile.name, ". Default value of 'Length' is calculated by 'end - start'!"))
        sink(type = "output")
        warning(paste0("'Length' is missing in row ", i, " of ", fragmentFile.name, ". Default value of 'Length' is calculated by 'end - start'!"))
        length = end - start
      }else{length = fragmentList$Length[i]}
      if(is.null(fragmentList$leftFlanking[i]) | setequal(NA, fragmentList$leftFlanking[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0("Warning: ", "'leftFlanking' is missing in row ", i, " of ", fragmentFile.name, ". Default value of 200 has been assigned to leftFlanking of certain fragment!"))
        sink(type = "output")
        warning(paste0("'leftFlanking' is missing in row ", i, " of ", fragmentFile.name, ". Default value of 200 has been assigned to leftFlanking of certain fragment!"))
        leftFlanking = 200
      }else{
        leftFlanking = fragmentList$leftFlanking[i]
      }
      if(is.null(fragmentList$rightFlanking[i]) | setequal(NA, fragmentList$rightFlanking[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0("Warning: ", "'rightFlanking' is missing in row ", i, " of ", fragmentFile.name, ". Default value of 200 has been assigned to rightFlanking of certain fragment!"))
        sink(type = "output")
        warning(paste0("'rightFlanking' is missing in row ", i, " of ", fragmentFile.name, ". Default value of 200 has been assigned to rightFlanking of certain fragment!"))
        rightFlanking = 200
      }else{
        rightFlanking = fragmentList$rightFlanking[i]
      }
      if(is.null(fragmentList$For[i]) | setequal(NA, fragmentList$For[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0("Warning: ", "'For' is missing in row ", i, " of ", fragmentFile.name, ". 'Cloning' has been assigned to 'For' as default!"))
        sink(type = "output")
        warning(paste0("Warning: ", "'For' is missing in row ", i, " of ", fragmentFile.name, ". 'Cloning' has been assigned to 'For' as default!"))
        For = "Cloning"
      }else{
        For = fragmentList$For[i]
      }
      
      
      ## specific chromosome sequence separation
      DNAseq.chr = DNAseq[chr]
      if(length(DNAseq.chr) == 0){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0('Program is stopped!', "please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!"))
        writeLines("######## THE END  ########")
        sink(type = "output")
        stop("please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!")
      } 
      
      # seq extraction
      seq = as.character(subseq(DNAseq.chr, start = start - leftFlanking, end = end + rightFlanking))
      seq = DNAStringSet(seq)
      if(strand == "-"){
        seq = reverseComplement(seq)
      }
      names(seq) = paste0(fragmentID, "_", chr, "_", start, "..", end, "_leftFlanking.", leftFlanking,"_rightFlanking.", rightFlanking, "_length.", length, "_for.", For)
      writeXStringSet(seq, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", fragmentID, "/", fragmentID, "_", chr, "_", start, "..", end, "_leftFlanking.", leftFlanking,"_rightFlanking.", rightFlanking,  "_length.", length, "_strand(", strand, ")", "_for.", For, ".fasta"), compress = FALSE)
      
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0("\nSequence extraction parameters for ", fragmentID, ":"))
      writeLines(paste0("\tChr: ", chr))
      writeLines(paste0("\tStart: ", start))
      writeLines(paste0("\tEnd: ", end))
      writeLines(paste0("\tStrand: ", strand))
      writeLines(paste0("\tLength: ", length))
      writeLines(paste0("\tleftFlanking: ", leftFlanking))
      writeLines(paste0("\trightFlanking: ", rightFlanking))
      writeLines(paste0("\tFor: ", For, "\n"))
      sink(type = "output")
    }
  }
  sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
  writeLines("\n######## THE END  ########")
  sink(type = "output")
  cat("\nCongratulation! fragment.seq.extraction is DONE!")
}



#' This is some description of this function.
#' @title to extract fragment sequence from genome based on parameters inputted manually. 
#'
#' @description By using this package, you could use function of fragment.seq.extraction.2 to extract fragment sequence from genome based on parameters inputted manually. 'fragment' is defined as a fragment sequence other than annotated gene, however a annotated gene could be regarded as a fragment as well.
#'
#' @details see above
#'
#' @param fragmentName: fragment name
#' @param database: folder or file contains genome sequence in fasta format
#' @param chr: numeric value or string, e.g 15, Chr15, and Gm15, indicates chromosome ID
#' @param start: numeric value indicates the start position of a fragment
#' @param end: numeric value indicates the end position of a fragment
#' @param strand: "+", or "-" indicates the direction of a fragment
#' @param length: numeric value indicates how many base pairs contained by a fragment, length of end - start would be calculated as default if length is missing.
#' @param leftFlanking: numeric value indicates left flanking region of a fragment, default value is 200, please specify 0 to this parameter if no left flanking region is to be extracted.
#' @param rightFlanking: numeric value indicates right flanking region of a fragment, default value is 200, please specify 0 to this parameter if no right flanking region is to be extracted.
#' @param For: string to indicate the purpose of sequence extraction. Default value is 'Cloning'.
#' @return fasta files, log file stored in ".../Sequence.extraction/Fragment.sequence.extraction/"
#' @export fragment.seq.extraction.2
#' @examples # fragment.seq.extraction.2(database = "./soybean.genome/Gmax_275_v2.0.fa", fragmentName = "hello", chr = 15, start = 12345, end = 12435)
#' 


###### NOTES ######
# fragment.seq.extraction.2.R is to extract sequence from database based on parameters input manually
######  END  ######


# fragment.seq.extraction.2(database = "./soybean.genome/Gmax_275_v2.0.fa", fragmentName = "hello", chr = 15, start = 12345, end = 12435)

fragment.seq.extraction.2 = function(database = NULL, fragmentName = NULL, chr = NULL, start = NULL, end = NULL, strand = NULL, length = NULL, leftFlanking = NULL, rightFlanking = NULL, For = NULL, ...){
  
  library(data.table)
  library(Biostrings)
  library(stringr)
  
  dir.path = getwd()
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction"))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction"))
  }
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction"))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction"))
  }
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", fragmentName))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", fragmentName))
  }
  
  sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
  writeLines("\n######## Fragment Sequence Extraction  ########")
  writeLines(paste0("\nDate: ", date()))
  writeLines(paste0("Information source: parameters input manually\n"))
  sink(type = "output")
  
  
  if(is.null(fragmentName)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0('Program is stopped! fragmentName is required!'))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'fragmentName' is required!")
  } 
  if(is.null(database)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0('Program is stopped! Database is required!'))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'database' is required!")
  } 
  if(is.null(start)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0('Program is stopped!', " 'start' is required!"))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'start' is required!")
  } 
  if(is.null(end)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0('Program is stopped!', " 'end' is required!"))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'end' is required!")
  } 
  
  if(is.null(strand)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Warning: ", " 'strand' is missing!", ". Default of '+' is assigned to 'strand'!"))
    sink(type = "output")
    strand = "+"
  }
  if(is.null(length)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Warning: ", " 'length' is missing!", ". value calculated by end - start is assgined as default value for 'length'!"))
    sink(type = "output")
    length = end - start
  } 
  if(is.null(leftFlanking)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Warning: ", " 'leftFlanking' is missing!", ". Default of 200 is assigned to 'leftFlanking'!"))
    sink(type = "output")
    leftFlanking = 200
  } 
  if(is.null(rightFlanking)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Warning: ", " 'rightFlanking' is missing!", ". Default of 200 is assigned to 'rightFlanking'!"))
    sink(type = "output")
    rightFlanking = 200
  } 
  if(is.null(For)) For = "Cloning"
  
  
  ## database read in 
  if(dir.exists(database)){
    database.dir = paste0(dir.path, "/", database, list.files(paste0(dir.path, "/", database)))
    if(length(database.dir) == 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
    }
    if(length(database.dir) > 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
      for(i in 2:length(database.dir)){
        temp = readDNAStringSet(database.dir[i], format = "fasta")
        DNAseq = append(DNAseq, temp)
      }
    }
  }
  if(!dir.exists(database)){
    DNAseq = readDNAStringSet(database, format = "fasta")
  }
  
  if(is.null(chr)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0('Program is stopped!', " 'chr' is required!"))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'chr' is required!")
  }else{
    chr.format = names(DNAseq)[1]
    chr.format = str_extract_all(chr.format, "(Chr|Gm)")[[1]]
    if(length(grep(chr.format, chr)) == 0){
      if(is.numeric(chr)){
        chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
      }else{
        chr = as.numeric(gsub("Chr|Gm", "", chr))
        chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
      }
    }
  }
  
  chr = "Chr15"
  
  ### 
  DNAseq.chr = DNAseq[chr]
  seq = as.character(subseq(DNAseq.chr, start = start - leftFlanking, end = end + rightFlanking))
  seq = DNAStringSet(seq)
  if(strand == "-"){
    seq = reverseComplement(seq)
  }
  names(seq) = paste0(fragmentName, "_", chr, "_", start, "..", end, "_leftFlanking.", leftFlanking,"_rightFlanking.", rightFlanking, "_length.", length, "_for.", For)
  writeXStringSet(seq, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", fragmentName, "/", fragmentName, "_", chr, "_", start, "..", end, "_leftFlanking.", leftFlanking,"_rightFlanking.", rightFlanking,  "_length.", length, "_strand(", strand, ")", "_for.", For, ".fasta"), compress = FALSE)
  
  sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment.sequence.extraction/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
  writeLines(paste0("\nSequence extraction parameters for ", fragmentName, ":"))
  writeLines(paste0("\tChr: ", chr))
  writeLines(paste0("\tStart: ", start))
  writeLines(paste0("\tEnd: ", end))
  writeLines(paste0("\tStrand: ", strand))
  writeLines(paste0("\tLength: ", length))
  writeLines(paste0("\tleftFlanking: ", leftFlanking))
  writeLines(paste0("\trightFlanking: ", rightFlanking))
  writeLines(paste0("\tFor: ", For, "\n"))
  writeLines("\n######## THE END  ########")
  sink(type = "output")
  cat("\nCongratulation! fragment.seq.extraction is DONE!")
}





#' This is some description of this function.
#' @title to extract flanking sequence of certain length based on file input or parameters inputted manually to define SNPs or Indels
#'
#' @description By using this package, you could use function of SNP.indel.flanking.seq.extraction to extract flanking sequence of certain length based on file input or parameters inputted manually to define SNPs or Indels
#'
#' @details see above
#'
#' @param SNPFile: SNP file, including at least 'Type', 'Name', 'Chr', 'Start', 'End', 'Strand', 'Length', 'leftFlanking', 'rightFlanking', of which 'Type', 'Name', 'Chr', 'Start' and 'End' are required to be specified. The program would assign default value of '+', 'end - start', 200, and 200 for 'Strand', 'Length', 'leftFlanking', and 'rightFlanking' respectively. This file could be in format of *.csv, .txt, .xlsx, if .xlsx format was used parameters should be put in 'Sheet1' as default.
#' @param IndelFile: Indel file, which is similar as SNPFile.
#' @param type: string to indiate SNP or Indel, varied format is also accepted, e.g. snp, SNP, indel, Indel, and INDEL
#' @param database: folder or file contains genome sequence in fasta format
#' @param lociName: string to specify the name of a SNP or Indel, when input file was missed, 'lociName' is reuquired.
#' @param chr: string or numeric value indicates specific chromosome, when input file was missed, 'chr' is reuquired.
#' @param start: numeric value indicates the start position of Indel, when input file was missed, 'start' is reuquired.
#' @param end: numeric value indicates the end position of Indel, when input file was missed, 'end' is reuquired.
#' @param pos: numeric value indicates the position of SNP, when input file was missed, 'pos' is reuquired.
#' @param leftFlanking: numeric value indicates left flanking region of SNP or Indel, default value is 200bp.
#' @param rightFlanking: numeric value indicates right flanking region of SNP or Indel, default value is 200bp.
#' @return fasta files, log file stored in ".../Sequence.extraction/Fragment.sequence.extraction/"
#' @export SNP.and.Indel.flanking.seq.extraction
#' @examples SNP.indel.flanking.seq.extraction(database = "./soybean.genome/", lociName = "SNP1", type = "SNP", chr = 13, pos = 12345, start = 13246, end = 13248)
#' 

###### NOTES ######
# SNP.indel.flanking.seq.extraction.R is to extract flanking sequence of SNP or Indel loci, based on parameters defined either by a file or manually inputted.
######  END  ######

# SNP.indel.flanking.seq.extraction(database = "./soybean.genome/", lociName = "Indel1", type = "Indel", chr = 13, pos = 12345, start = 13246, end = 13248)

# SNP.indel.flanking.seq.extraction(database = "./soybean.genome/", SNPFile = "./SNPList.xlsx", type = "SNP")
# SNP.indel.flanking.seq.extraction(database = "./soybean.genome/", IndelFile = "./SNPList.xlsx", type = "Indel")

SNP.and.Indel.flanking.seq.extraction = function(database = NULL, SNPFile = NULL, IndelFile = NULL, type = NULL, lociName = NULL, chr = NULL, start = NULL, end = NULL, pos = NULL, leftFlanking = NULL, rightFlanking = NULL, ...){
  
  library(data.table)
  library(Biostrings)
  library(stringr)
  
  dir.path = getwd()
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction"))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction"))
  }
  
  if(is.null(type)){
    stop("'type' is required!")
  }
  if(is.null(SNPFile)) SNPFile = "NA"
  if(is.null(IndelFile)) IndelFile = "NA"
  
  ## database read in 
  if(dir.exists(database)){
    database.dir = paste0(dir.path, "/", database, list.files(paste0(dir.path, "/", database)))
    if(length(database.dir) == 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
    }
    if(length(database.dir) > 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
      for(i in 2:length(database.dir)){
        temp = readDNAStringSet(database.dir[i], format = "fasta")
        DNAseq = append(DNAseq, temp)
      }
    }
  }
  if(!dir.exists(database)){
    DNAseq = readDNAStringSet(database, format = "fasta")
  }
  
  ## SNP from file
  if(file.exists(SNPFile)){
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "SNP.flanking.sequence.extraction"))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/", "SNP.flanking.sequence.extraction"))
    }
    # file read in
    if(length(grep(".csv|.txt", SNPFile)) == 1){
      SNP = fread(SNPFile, header = T, stringsAsFactors = F, fill = T, sep = "\t")
      if(ncol(SNP) == 1){
        SNP = fread(SNPFile, header = T, stringsAsFactors = F, fill = T, sep = ",")
        if(ncol(SNP) == 1){
          SNP = fread(SNPFile, header = T, stringsAsFactors = F, fill = T, sep = " ")
        }
      }
    }
    if(length(grep(".xlsx|.xls", SNPFile)) == 1){
      SNP = as.data.table(read.xlsx(SNPFile, header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
    }
    SNPFile.name = gsub(".csv|.txt|.xlsx|.xls", "", strsplit(SNPFile, "/")[[1]][length(strsplit(SNPFile, "/")[[1]])])
    # file checking
    if(length(grep("SNP.Name|Chr|Pos|leftFlanking|rightFlanking", names(SNP))) != 5){
      warning("The column name of 'SNPFile' should at least contain: SNP.Name, Chr, Pos, leftFlanking, rightFlanking, please check input file!")
    }else{
      cat("The format of 'SNPFile' is correct!")
    }
    
    # sequence extraction
    for(i in 1:nrow(SNP)){
      SNP.temp = SNP[i,]
      if(is.null(SNP.temp$SNP.Name[1]) | setequal(NA, SNP.temp$SNP.Name[1])){
        stop(paste0("'SNP.Name' of ", SNPFile.name, " is missing!"))
      }else{
        SNPName = SNP.temp$SNP.Name[1]
      }
      if(is.null(SNP.temp$Chr[1]) | setequal(NA, SNP.temp$Chr[1])){
        stop(paste0("'Chr' of ", SNPFile.name, " is missing!"))
      }else{
        chr = SNP$Chr[i]
        chr.format = names(DNAseq)[1]
        chr.format = str_extract_all(chr.format, "(Chr|Gm)")[[1]]
        if(length(grep(chr.format, chr)) == 0){
          if(is.numeric(chr)){
            chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
          }else{
            chr = as.numeric(gsub("Chr|Gm", "", chr))
            chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
          }
        }
      }
      if(is.null(SNP.temp$Pos[1]) | setequal(NA, SNP.temp$Pos[1])){
        stop(paste0("'Pos' of ", SNPFile.name, " is missing!"))
      }else{
        pos = SNP.temp$Pos[1]
      }
      if(is.null(SNP.temp$leftFlanking[1]) | setequal(NA, SNP.temp$leftFlanking[1])){
        warning(paste0("'leftFlanking' of ", SNPFile.name, " is missing!", " Default value of 200bp is assigned to 'leftFlanking'!"))
        leftFlanking = 200
      }else{
        leftFlanking = as.numeric(SNP.temp$leftFlanking[1])
      }
      if(is.null(SNP.temp$rightFlanking[1]) | setequal(NA, SNP.temp$rightFlanking[1])){
        warning(paste0("'rightFlanking' of ", SNPFile.name, " is missing!", " Default value of 200bp is assigned to 'rightFlanking'!"))
        rightFlanking = 200
      }else{
        rightFlanking = as.numeric(SNP.temp$rightFlanking[1])
      }
      
      if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "SNP.flanking.sequence.extraction/", SNPName))){
        dir.create(paste0(dir.path, "/", "Sequence.extraction/", "SNP.flanking.sequence.extraction/", SNPName))
      }
      
      # Chromosome separation
      DNAseq.chr = DNAseq[chr]
      if(length(DNAseq.chr) == 0){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "SNP.sequence.extraction/", "SNP.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0('Program is stopped!', "please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!"))
        writeLines("######## THE END  ########")
        sink(type = "output")
        stop("please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!")
      } 
      
      # seq extraction
      seq.left = as.character(subseq(DNAseq.chr, start = (pos - leftFlanking), end = pos))
      seq.left = DNAStringSet(seq.left)
      names(seq.left) = paste0(SNPName, "_SNP_", chr, "_", (pos - leftFlanking), "..", pos, "_leftFlanking.", leftFlanking)
      writeXStringSet(seq.left, filepath = paste0(dir.path, "/", "Sequence.extraction/", "SNP.flanking.sequence.extraction/", SNPName, "/", SNPName, "_SNP_", chr, "_", (pos - leftFlanking), "..", pos, "_leftFlanking.", leftFlanking, ".fasta"), compress = FALSE)
      
      seq.right = as.character(subseq(DNAseq.chr, start = pos, end = (pos + rightFlanking)))
      seq.right = DNAStringSet(seq.right)
      names(seq.right) = paste0(SNPName, "_SNP_", chr, "_", pos, "..", (pos + rightFlanking), "_rightFlanking.", rightFlanking)
      writeXStringSet(seq.right, filepath = paste0(dir.path, "/", "Sequence.extraction/", "SNP.flanking.sequence.extraction/",SNPName, "/", SNPName, "_SNP_", chr, "_", pos, "..", (pos + rightFlanking), "_rightFlanking.", rightFlanking, ".fasta"), compress = FALSE)
    }
  }
  
  # SNP from input
  if(SNPFile == "NA" & (type == "SNP" | type == "snp")){
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "SNP.flanking.sequence.extraction"))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/", "SNP.flanking.sequence.extraction"))
    }
    if(is.null(lociName)){
      stop("'lociName' is required when there is no SNPFile as input, all parameters defining a SNP locus should not be 'NULL'!")
    }else{
      SNPName = lociName
    }
    if(is.null(chr)){
      stop("'chr' is required when there is no SNPFile as input, all parameters defining a SNP locus should not be 'NULL'!")
    }else{
      chr.format = names(DNAseq)[1]
      chr.format = str_extract_all(chr.format, "(Chr|Gm)")[[1]]
      if(length(grep(chr.format, chr)) == 0){
        if(is.numeric(chr)){
          chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
        }else{
          chr = as.numeric(gsub("Chr|Gm", "", chr))
          chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
        }
      }
    }
    if(is.null(pos)){
      stop("'locusPos' is required when there is no SNPFile as input, all parameters defining a SNP locus should not be 'NULL'!")
    }else{
      pos = pos
    }
    if(is.null(leftFlanking)) leftFlanking = 200
    if(is.null(rightFlanking)) rightFlanking = 200
    
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "SNP.flanking.sequence.extraction/", SNPName))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/", "SNP.flanking.sequence.extraction/", SNPName))
    }
    
    # Chromosome separation
    DNAseq.chr = DNAseq[chr]
    if(length(DNAseq.chr) == 0){
      sink(paste0(dir.path, "/", "Sequence.extraction/", "SNP.flanking.sequence.extraction/", "SNP.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0('Program is stopped!', "please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!"))
      writeLines("######## THE END  ########")
      sink(type = "output")
      stop("please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!")
    } 
    
    # seq extraction
    seq.left = as.character(subseq(DNAseq.chr, start = (pos - leftFlanking), end = pos))
    seq.left = DNAStringSet(seq.left)
    names(seq.left) = paste0(SNPName, "_SNP_", chr, "_", (pos - leftFlanking), "..", pos, "_leftFlanking.", leftFlanking)
    writeXStringSet(seq.left, filepath = paste0(dir.path, "/", "Sequence.extraction/", "SNP.flanking.sequence.extraction/", SNPName, "/", SNPName, "_SNP_", chr, "_", (pos - leftFlanking), "..", pos, "_leftFlanking.", leftFlanking, ".fasta"), compress = FALSE)
    
    seq.right = as.character(subseq(DNAseq.chr, start = pos, end = (pos + rightFlanking)))
    seq.right = DNAStringSet(seq.right)
    names(seq.right) = paste0(SNPName, "_SNP_", chr, "_", pos, "..", (pos + rightFlanking), "_rightFlanking.", rightFlanking)
    writeXStringSet(seq.right, filepath = paste0(dir.path, "/", "Sequence.extraction/", "SNP.flanking.sequence.extraction/", SNPName, "/", SNPName, "_SNP_", chr, "_", pos, "..", (pos + rightFlanking), "_rightFlanking.", rightFlanking, ".fasta"), compress = FALSE)
  }
  
  ## Indel from file
  if(file.exists(IndelFile) & (type == "Indel" | type == "INDEL" | type == "indel")){
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Indel.flanking.sequence.extraction"))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Indel.flanking.sequence.extraction"))
    }
    # file read in
    if(length(grep(".csv|.txt", IndelFile)) == 1){
      Indel = fread(IndelFile, header = T, stringsAsFactors = F, fill = T, sep = "\t")
      if(ncol(Indel) == 1){
        Indel = fread(IndelFile, header = T, stringsAsFactors = F, fill = T, sep = ",")
        if(ncol(SNP) == 1){
          Indel = fread(IndelFile, header = T, stringsAsFactors = F, fill = T, sep = " ")
        }
      }
    }
    if(length(grep(".xlsx|.xls", IndelFile)) == 1){
      Indel = as.data.table(read.xlsx(IndelFile, header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
    }
    IndelFile.name = gsub(".csv|.txt|.xlsx|.xls", "", strsplit(IndelFile, "/")[[1]][length(strsplit(IndelFile, "/")[[1]])])
    # file checking
    if(length(grep("Indel.Name|Chr|Start|End|leftFlanking|rightFlanking", names(Indel))) != 6){
      warning("The column name of 'IndelFile' should at least contain: Indel.Name, Chr, Start, End, leftFlanking, rightFlanking, please check input file!")
    }else{
      cat("The format of 'IndelFile' is correct!")
    }
    
    # sequence extraction
    for(i in 1:nrow(Indel)){
      Indel.temp = Indel[i,]
      if(is.null(Indel.temp$Indel.Name[1]) | setequal(NA, Indel.temp$Indel.Name[1])){
        stop(paste0("'Indel.Name' of ", IndelFile.name, " is missing!"))
      }else{
        IndelName = Indel.temp$Indel.Name[1]
      }
      if(is.null(Indel.temp$Chr[1]) | setequal(NA, Indel.temp$Chr[1])){
        stop(paste0("'Chr' of ", IndelFile.name, " is missing!"))
      }else{
        chr = Indel$Chr[i]
        chr.format = names(DNAseq)[1]
        chr.format = str_extract_all(chr.format, "(Chr|Gm)")[[1]]
        if(length(grep(chr.format, chr)) == 0){
          if(is.numeric(chr)){
            chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
          }else{
            chr = as.numeric(gsub("Chr|Gm", "", chr))
            chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
          }
        }
      }
      if(is.null(Indel.temp$Start[1]) | setequal(NA, Indel.temp$Start[1])){
        stop(paste0("'Start' of ", IndelFile.name, " is missing!"))
      }else{
        start = Indel.temp$Start[1]
      }
      if(is.null(Indel.temp$End[1]) | setequal(NA, Indel.temp$End[1])){
        stop(paste0("'End' of ", IndelFile.name, " is missing!"))
      }else{
        end = Indel.temp$End[1]
      }
      if(is.null(Indel.temp$leftFlanking[1]) | setequal(NA, Indel.temp$leftFlanking[1])){
        warning(paste0("'leftFlanking' of ", IndelFile.name, " is missing!", " Default value of 200bp is assigned to 'leftFlanking'!"))
        leftFlanking = 200
      }else{
        leftFlanking = as.numeric(Indel.temp$leftFlanking[1])
      }
      if(is.null(Indel.temp$rightFlanking[1]) | setequal(NA, Indel.temp$rightFlanking[1])){
        warning(paste0("'rightFlanking' of ", IndelFile.name, " is missing!", " Default value of 200bp is assigned to 'rightFlanking'!"))
        rightFlanking = 200
      }else{
        rightFlanking = as.numeric(Indel.temp$rightFlanking[1])
      }
      
      if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Indel.flanking.sequence.extraction/", IndelName))){
        dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Indel.flanking.sequence.extraction/", IndelName))
      }
      
      # Chromosome separation
      DNAseq.chr = DNAseq[chr]
      if(length(DNAseq.chr) == 0){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Indel.flanking.sequence.extraction/", "Indel.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0('Program is stopped!', "please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!"))
        writeLines("######## THE END  ########")
        sink(type = "output")
        stop("please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!")
      } 
      
      # seq extraction
      seq.left = as.character(subseq(DNAseq.chr, start = (start - leftFlanking), end = start))
      seq.left = DNAStringSet(seq.left)
      names(seq.left) = paste0(IndelName, "_Indel_", chr, "_", (start - leftFlanking), "..", start, "_leftFlanking.", leftFlanking)
      writeXStringSet(seq.left, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Indel.flanking.sequence.extraction/", IndelName, "/", IndelName, "_Indel_", chr, "_", (start - leftFlanking), "..", start, "_leftFlanking.", leftFlanking, ".fasta"), compress = FALSE)
      
      seq.right = as.character(subseq(DNAseq.chr, start = end, end = (end + rightFlanking)))
      seq.right = DNAStringSet(seq.right)
      names(seq.right) = paste0(IndelName, "_Indel_", chr, "_", end, "..", (end + rightFlanking), "_rightFlanking.", rightFlanking)
      writeXStringSet(seq.right, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Indel.flanking.sequence.extraction/", IndelName, "/", IndelName, "_Indel_", chr, "_", end, "..", (end + rightFlanking), "_rightFlanking.", rightFlanking, ".fasta"), compress = FALSE)
    }
  }
  
  # Indel from input
  if(IndelFile == "NA" & (type == "Indel" | type == "INDEL" | type == "indel")){
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Indel.flanking.sequence.extraction"))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Indel.flanking.sequence.extraction"))
    }
    if(is.null(lociName)){
      stop("'lociName' is required when there is no IndelFile as input, all parameters defining a Indel locus should not be 'NULL'!")
    }else{
      IndelName = lociName
    }
    if(is.null(chr)){
      stop("'chr' is required when there is no IndelFile as input, all parameters defining a Indel locus should not be 'NULL'!")
    }else{
      chr.format = names(DNAseq)[1]
      chr.format = str_extract_all(chr.format, "(Chr|Gm)")[[1]]
      if(length(grep(chr.format, chr)) == 0){
        if(is.numeric(chr)){
          chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
        }else{
          chr = as.numeric(gsub("Chr|Gm", "", chr))
          chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
        }
      }
    }
    if(is.null(start)){
      stop("'start' is required when there is no IndelFile as input, all parameters defining a Indel locus should not be 'NULL'!")
    }else{
      start = start
    }
    if(is.null(end)){
      stop("'end' is required when there is no IndelFile as input, all parameters defining a Indel locus should not be 'NULL'!")
    }else{
      end = end
    }
    if(is.null(leftFlanking)) leftFlanking = 200
    if(is.null(rightFlanking)) rightFlanking = 200
    
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Indel.flanking.sequence.extraction/", IndelName))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Indel.flanking.sequence.extraction/", IndelName))
    }
    
    # Chromosome separation
    DNAseq.chr = DNAseq[chr]
    if(length(DNAseq.chr) == 0){
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Indel.flanking.sequence.extraction/", "Indel.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0('Program is stopped!', "please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!"))
      writeLines("######## THE END  ########")
      sink(type = "output")
      stop("please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!")
    } 
    
    # seq extraction
    seq.left = as.character(subseq(DNAseq.chr, start = (start - leftFlanking), end = start))
    seq.left = DNAStringSet(seq.left)
    names(seq.left) = paste0(IndelName, "_Indel_", chr, "_", (start - leftFlanking), "..", start, "_leftFlanking.", leftFlanking)
    writeXStringSet(seq.left, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Indel.flanking.sequence.extraction/", IndelName, "/", IndelName, "_Indel_", chr, "_", (start - leftFlanking), "..", start, "_leftFlanking.", leftFlanking, ".fasta"), compress = FALSE)
    
    seq.right = as.character(subseq(DNAseq.chr, start = end, end = (end + rightFlanking)))
    seq.right = DNAStringSet(seq.right)
    names(seq.right) = paste0(IndelName, "_Indel_", chr, "_", end, "..", (end + rightFlanking), "_rightFlanking.", rightFlanking)
    writeXStringSet(seq.right, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Indel.flanking.sequence.extraction/", IndelName, "/", IndelName, "_Indel_", chr, "_", end, "..", (end + rightFlanking), "_rightFlanking.", rightFlanking, ".fasta"), compress = FALSE)
  }
  cat("\n'SNP.and.Indel.flanking.seq.extraction is DONE!")
}




#' This is some description of this function.
#' @title figure out the chromosomal location of a gene or fragment on specific genome
#'
#' @description By using this package, you could use function of seq.evaluation to perform local-blast for location of a gene or fragment on specific genome
#'
#' @details see above
#' @param seqType: string to indicate type of sequence, which could one of 'Gene', "fragment', 'SNP', 'Indel'.
#' @param inputFile: parameter setting file in '.csv' or '.xlsx' format. it should contains Type	Name	Chr	Start	End	Strand	Primer_strand	Flanking.left.bp	Flanking.right.bp	Expected.amplicon.length.bp	Aiming	Primer.name	Primer.length.bp	Tm.expected	GC.content	Sequence.specificity.min, details could be found in example input file.
#' @param database: folder contains genome sequence in fasta format
#' @param stepWise: numeric value to indicate stepWise of windows, default value is 3.
#' @param windowSize: numeric value to indicate scope of window size, could be a single number, e.g. 23, or a range, e.g. c(20,25). Default value is c(20, 25)
#' @param blastDir: the path to the local blast.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param specificityMin: numeric value to indicate the min value of sequence specificity to signify on the diagnostic plot.
#' @param nthreads: numeric value to indicate how many threads used in the analysis, default is 2
#' @param Evalue: numeric value to indicate e-value threshold in local-blast, default is 0.1 (1e-1)
#' @param outFormat: numeric value to specify -outfmt parameter in local blast, default is 6.
#' @param GCShow: logical value. whether to show GC content on the diagnostic plot, default is TRUE
#' @param TmShow: logical value.whether to show Tm value on the diagnostic plot, default is TRUE
#' @param specificiyShow: logical value.whether to show sequence specificity value on the diagnostic plot, default is TRUE
#' @param countShow: logical value.whether to show Counts on the diagnostic plot, default is TRUE
#' @param countMax: numeric value to indicates the maximum counts threshold, by which fragment to be displayed with dashed line.
#' @param segmentLinetype: numeric value indicates which line type to be used. It is inherited from basic line types in the R.
#' @param segmentColor: string indicate the color of geom_segment(), which represent fragment sequence on the chromosome in terms of location.
#' @param segmentSize: numeric value indicates line size of geom_segment(), default value is 0.2
#' @param pointShape: numeric value indicates point shape in geom_point(), default value for pointShape1 and pointShape2 are 19 and 24 respectively.
#' @param pointColor: string indicates color of geom_point(), default value for pointColor1 and pointColor2 are 'red' and 'blue' respectively.
#' @param pointSize: numeric value indicates point size in geom_point(), default value for pointSize, pointSize1, and pointSize2 are 0.5, 0.5, and 0.5 respectively.
#' @param hlineType: numeric value indicates line type in geom_hline(), default value is 2.
#' @param hlineColor: string indicates line color in geom_hline(), default value is 'blue'
#' @param hlineSize: numeric value indicates line size, default value is 0.3.
#' @param pdfWidth: numeric value indicates width of pdf file, default value is 16.
#' @param pdfHeight: numeric value indicates height of pdf file, default value is 10.
#' @return files and folder
#' @export seq.evaluation
#' @examples seq.evaluation(database = "./soybean.genome/", seqType = "Gene", inputFile = "./Sequence.extraction/Gene.sequence.extraction/Glyma.01G010100.1/Glyma.01G010100.1_mRNA_Chr01_980614..987593_leftFlanking.200_rightFlanking.200_strand(-)_for.qRT-PCR.fasta", blastDir = "./ncbi-blast-2.12.0+/")
#' 


# seq.evaluation(database = "./soybean.genome/", seqType = "SNP", inputFile = "./Sequence.extraction/SNP.flanking.sequence.extraction/SNP.4.15638972/", blastDir = "./ncbi-blast-2.12.0+/")

# windowSize = NULL; stepWise = NULL;TmMethod = NULL; specificityMin = NULL; nthreads = NULL;Evalue = NULL; GCShow = NULL; TmShow = NULL; specificiyShow = NULL;countShow = NULL; TmScope = NULL; GCScope = NULL; countMax = NULL; segmentLinetype = NULL; segmentColor = NULL; segmentSize = NULL; pointShape1 = NULL; pointShape2 = NULL; pointColor1 = NULL; pointColor2 = NULL; pointSize = NULL; pointSize1 = NULL; pointSize2 = NULL; hlineType = NULL; hlineColor = NULL; hlineSize = NULL; pdfWidth = NULL;pdfHeight = NULL;outFormat = NULL

############# NOTES #################
# Basic steps of seq.evaluation are: 1. fragmented sequence generation by specific window size and stepWise; 2. perform Local-Blast for all fragmented sequence; 3. statistic analysis of all fragmented sequences and diagnostic plotting showing GC.content (%), Tm, sequence specificy (%), and mapping counts.
# * sequence specificity: defined as the average identity percentage (%) of all fragments (sequence generated 
#   based on specific window size and stepWise) matched to genome when using Local-Blast. The formula is: sum(identity percentage)/counts. Sequence specificity less than 5% were all assigned as 5% for convenience, as too low of specificity is meaningless in selection of region with high sequence specificity for primer designing.
# * counts: means how many sequence fragment (subject) were matched with input sequence (query), counts which is larger than 100 were all assigned as 100 for convienience in plotting, as too many counts corresponding to low sequence specificity, which would not be selected as candidate primers.
########## END of NOTES ##############

seq.evaluation = function(database = NULL, seqType = NULL, inputFile = NULL, blastDir = NULL, windowSize = NULL, stepWise = NULL, TmMethod = NULL, specificityMin = NULL, nthreads = NULL, Evalue = NULL, GCShow = NULL, TmShow = NULL, specificiyShow = NULL, countShow = NULL, TmScope = NULL, GCScope = NULL, countMax = NULL, segmentLinetype = NULL, segmentColor = NULL, segmentSize = NULL, pointShape1 = NULL, pointShape2 = NULL, pointColor1 = NULL, pointColor2 = NULL, pointSize = NULL, pointSize1 = NULL, pointSize2 = NULL, hlineType = NULL, hlineColor = NULL, hlineSize = NULL, pdfWidth = NULL, pdfHeight = NULL, outFormat = NULL, ...){
  
  ## loading required packages
  library(stringr) # 
  library(Biostrings) # 
  library(tidyr)
  library(xlsx)
  library(WriteXLS)
  #library(tidyverse)
  library(sangerseqR)
  library(data.table)
  library(RColorBrewer)
  library(ggplot2)
  library(cowplot)
  
  ### default value assignment
  if(is.null(database)) stop("'database' is required!")
  if(is.null(inputFile)) stop("'inputFile' is required!")
  if(is.null(blastDir)) stop("'blastDir' is required!")
  if(is.null(seqType)) stop("'seqType' is required!")
  if(is.null(windowSize)) windowSize = c(20,25)
  if(is.null(stepWise)) stepWise = 3
  if(is.null(specificityMin)) specificityMin = 95
  if(is.null(Evalue)) Evalue = 1e-1
  if(is.null(outFormat)) outFormat = 6
  if(is.null(nthreads)) nthreads = 2
  if(is.null(GCShow)) GCShow = TRUE
  if(is.null(TmShow)) TmShow = TRUE
  if(is.null(specificiyShow)) specificiyShow = TRUE
  if(is.null(countShow)) countShow = TRUE
  if(is.null(TmMethod)) TmMethod = "both"
  if(is.null(TmScope)) TmScope = c(40, 65)
  if(is.null(GCScope)) GCScope = c(40, 70)
  if(is.null(countMax)) countMax = 2
  if(is.null(segmentLinetype)) segmentLinetype = 2
  if(is.null(segmentColor)) segmentColor = "red"
  if(is.null(segmentSize)) segmentSize = 0.2
  if(is.null(pointShape1)) pointShape1 = 19
  if(is.null(pointShape2)) pointShape2 = 24
  if(is.null(pointColor1)) pointColor1 = "red"
  if(is.null(pointColor2)) pointColor2 = "blue"
  if(is.null(pointSize)) pointSize = 0.5
  if(is.null(pointSize1)) pointSize1 = 0.5
  if(is.null(pointSize2)) pointSize2 = 0.5
  if(is.null(hlineType)) hlineType = 2
  if(is.null(hlineColor)) hlineColor = "blue"
  if(is.null(hlineSize)) hlineSize = 0.3
  if(is.null(pdfWidth)) pdfWidth = 16
  if(is.null(pdfHeight)) pdfHeight = 10
  
  #inputFile = "./Sequence.extraction/Gene.sequence.extraction/Glyma.01G010100.1/Glyma.01G010100.1_mRNA_Chr01_980614..987593_leftFlanking.200_rightFlanking.200_strand(-)_for.qRT-PCR.fasta"
  
  ## current directory
  dir.path = getwd()
  
  if(!dir.exists(database)){
    stop("Parameter 'database' should be a folder, in which *.fasta file could be defined as a database for LOCAL-BLAST")
  }
  
  if(!is.numeric(windowSize)){
    stop("Please check windowSize input, this parameter give a number region by which input sequence would be freamented, it should be numeric, default input is 'c(20, 25)' other formats of input would not be accepted!")
  }
  window.size = seq(windowSize[1], windowSize[2])
  if(window.size[length(window.size)] > 30 | window.size[length(window.size)] < 18){
    warning(paste0("The shortest and longest window size are ", window.size[1], "bp and ", window.size[length(window.size)], "bp respectively, which are too small or too large for providing meaningfull information for further analysis!"))
  }
  if(!is.numeric(stepWise)){
    stop("The parameter 'stepWise' should be a numeric vector! the default unit for 'stepWise' is 'bp' as default.")
  }
  if(stepWise >= 10){
    warning(paste0("The current stepWise is: ", stepWise, ". A number between 1-10 is prefered, too large stepWise would result in missing information."))
  }
  
  ## folder creation
  if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation"))){
    dir.create(paste0(dir.path, "/", "Sequence.evaluation"))
  }
  if(seqType == "Gene" | seqType == "gene" | seqType == "GENE"){
    folderName1 = "Genes"
  }
  if(seqType == "fragment" | seqType == "Fragment" | seqType == "FRAGMENT"){
    folderName1 = "Fragment"
  }
  if(seqType == "SNP" | seqType == "snp"){
    folderName1 = "SNP"
  }
  if(seqType == "Indel" | seqType == "INDEL" | seqType == "indel"){
    folderName1 = "Indel"
  }
  if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/", folderName1))){
    dir.create(paste0(dir.path, "/", "Sequence.evaluation/", folderName1))
  }
  
  ## make database if its not ready for use
  if(!dir.exists(paste0(dir.path, "/", blastDir, "db"))){
    dir.create(paste0(dir.path, "/", blastDir, "db"))
  }
  if(length(dir(paste0(dir.path, "/", blastDir, "db"))) == 0){
    files = dir(database)
    for(i in 1:length(files)){
      file.copy(from = paste0(dir.path,"/", database, files[i]),
                to = paste0(dir.path, "/", blastDir, "db/", files[i]))
    }
    makeblastdb.dir = paste0(dir.path, "/", blastDir, "bin/makeblastdb")
    db.files = paste0(dir.path, "/", blastDir, "db/", list.files(paste0(dir.path, "/", blastDir, "db/")))
    for(i in 1:length(db.files)){
      seq.name = strsplit(db.files[i], "/")[[1]][length(strsplit(db.files[i], "/")[[1]])]
      seq.name = gsub(".fasta", "", seq.name)
      system2(command = makeblastdb.dir,
              args= c("-in", db.files[i],
                      "-parse_seqids ",
                      "-hash_index ",
                      "-dbtype nucl",
                      "-out", seq.name,
                      "-num_threads", nthreads),
              wait = TRUE,
              stdout = FALSE
      )
      files.1 = dir(dir.path)
      for(j in 1:length(files.1)){
        if(!dir.exists(files.1[j])) {
          file.copy(from = paste0(dir.path,"/",files.1[j]),
                    to = paste0(dir.path,"/",blastDir, "db/", files.1[j]))
          file.remove(paste0(dir.path,"/",files.1[j]))
        }
      }
    }
    rm(seq.name, files, makeblastdb.dir)
  }
  
  ## function 1
  seq.splitting = function(data, window.size, step){
    seq.split = c()
    if(nchar(as.character(data[1])) >= window.size + step){
      for(i in 1:length(data)){
        seq = seq(from = 1, to = nchar(as.character(data[i])), by = step)
        for(j in seq){
          if(j+window.size < nchar(as.character(data[i]))){
            sub_seq <- subseq(data[i], start = j, end = j + window.size - 1)
            names(sub_seq) <- paste0(names(data[i]), "_from_", j, "_to_", j + window.size -1 )
            seq.split = append(seq.split, sub_seq)
          }
        }
      }
    }
    return(seq.split)
  }
  
  blastn.dir = paste0(dir.path, "/", blastDir, "bin/blastn")
  blast_out_col <- c("Query", "Subject", "Identity_percentage",
                     "Length_bp", "Mismatch_bp", "Gap_bp",
                     "Query_start", "Query_end", "Subject_start", "Subject_end",
                     "E_value", "Bit_score")
  
  file.list = list.files(paste0(dir.path, "/", database))
  dir = paste0(dir.path, "/", database, file.list)
  # i = 1
  for(i in 1:length(dir)){
    seq.name = strsplit(dir[i], "/")[[1]][length(strsplit(dir[i], "/")[[1]])]
    seq.path = paste0(dir.path, "/", blastDir, "db/", seq.name)
    DNAseq = readDNAStringSet(dir[i], format = "fasta")
    if(!dir.exists(inputFile)){
      input.file.path = paste0(dir.path, "/", inputFile)
      input = readDNAStringSet(input.file.path, format = "fasta")
      input.name = strsplit(input.file.path, "/")[[1]][length(strsplit(input.file.path, "/")[[1]])]
      input.name = gsub(".fasta", "", input.name)
      input.name = gsub("\\(+\\)|\\(-\\)|_strand", "", input.name)
      For = gsub("\\.", "", strsplit(input.name, "for")[[1]][2])
      if(length(str_extract_all(seqType, "Gene|gene|GENE|Fragment|fragment|FRAGMENT")[[1]]) == 1){
        folderName = strsplit(input.file.path, "/")[[1]][length(strsplit(input.file.path, "/")[[1]]) - 1]
        if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))){
          dir.create(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))
        }
      }
      if(length(str_extract_all(seqType, "SNP|snp|Indel|indel|INDEL")[[1]]) == 1){
        folderName = folderName = strsplit(input.file.path, "/")[[1]][length(strsplit(input.file.path, "/")[[1]])]
        folderName = strsplit(folderName, "_")[[1]][1]
        if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))){
          dir.create(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))
        }
      }
      # j = 2
      for(j in 1:length(window.size)){
        split.seq = seq.splitting(data = input, window.size = window.size[j], step = stepWise)
        if(!is.null(split.seq)){
          writeXStringSet(split.seq, filepath = paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[j], "_for.", For, "_split.seq.fasta"), compress = FALSE)
          split.seq.path = paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[j], "_for.", For, "_split.seq.fasta")
          blast_out <- data.frame(system2(command = blastn.dir, 
                                          args = c("-db", seq.path, 
                                                   "-task blastn",
                                                   "-query", split.seq.path, 
                                                   "-outfmt", outFormat,
                                                   "-evalue", Evalue,
                                                   "-num_threads", nthreads),
                                          wait = TRUE,
                                          stdout = TRUE)) 
          names(blast_out) = c("original")
          blast_out <- blast_out %>% separate(original, blast_out_col, "\t")
          fwrite(blast_out, file = paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_against_", seq.name, "_Evalue.", Evalue, "_window.size.by.", window.size[j], "_for.", For, "_blast.out.csv"), row.names = F, col.names = T, quote = F, sep = "\t")
          for(m in 3:ncol(blast_out)){
            blast_out[,m] = as.numeric(blast_out[,m])
          }
          ### sequence specificity calculation
          seq.spec.m = data.frame(matrix(nrow = 0, ncol = 15))
          names(seq.spec.m) = c("Name", "Seq", "Chr", "From", "To", "Percentage", "Count", "GC.content", "Tm1", "Tm2", "Percentage.color", "Count.color", "GC.color", "Tm.color", "Tm2.color")
          query.list = unique(blast_out$Query)
          Count.colorset = c("red", colorRampPalette(c('blue','black'))(99))
          Tm.colorset = colorRampPalette(c('green','red',"black"))(60)
          GC.colorset = colorRampPalette(c('green','red', "black"))(100)
          Specific.colorset = colorRampPalette(c('black','red'))(100)
          # k = 1
          for(k in 1:length(query.list)){
            loc.temp = strsplit(query.list[k], "_")[[1]]
            start.end = grep("\\.\\.", loc.temp)
            Pos.left = as.numeric(strsplit(loc.temp[start.end], "\\..")[[1]][1])
            Pos.right = as.numeric(strsplit(loc.temp[start.end], "\\..")[[1]][2])
            if(seqType == "Gene" | seqType == "fragment" | seqType == "gene" | seqType == "Fragment"){
              leftFlanking = as.numeric(strsplit(loc.temp[grep("leftFlanking", loc.temp)], "\\.")[[1]][2])
              rightFlanking = as.numeric(strsplit(loc.temp[grep("rightFlanking", loc.temp)], "\\.")[[1]][2])
            }
            if(seqType == "Indel" | seqType == "SNP" | seqType == "INDEL" | seqType == "snp" | seqType == "indel"){
              if(length(grep("leftFlanking", loc.temp)) == 1){
                leftFlanking = as.numeric(strsplit(loc.temp[grep("leftFlanking", loc.temp)], "\\.")[[1]][2])
                rightFlanking = 0
              }
              if(length(grep("rightFlanking", loc.temp)) == 1){
                leftFlanking = 0
                rightFlanking = as.numeric(strsplit(loc.temp[grep("rightFlanking", loc.temp)], "\\.")[[1]][2])
              }
            }
            
            Chr = loc.temp[grep("Chr|Gm", loc.temp)]
            seq.spec.temp = data.frame(matrix(nrow = 1, ncol = 15))
            names(seq.spec.temp) = c("Name", "Seq", "Chr", "From", "To", "Percentage", "Count", "GC.content", "Tm1", "Tm2", "Percentage.color", "Count.color", "GC.color", "Tm1.color", "Tm2.color")
            temp1 = blast_out[which(blast_out$Query == query.list[k]), ]
            if(nrow(temp1) >= 1){
              if(seqType == "Gene" | seqType == "fragment" | seqType == "gene" | seqType == "Fragment"){
                temp1.1 = temp1[which(temp1$Identity_percentage == max(temp1$Identity_percentage) & temp1$Subject == Chr & temp1$Length_bp == window.size[j] & temp1$Gap_bp == 0 & temp1$Subject_start >= (Pos.left - leftFlanking) & temp1$Subject_start <= (Pos.right + rightFlanking)),]
              }
              if(seqType == "Indel" | seqType == "SNP" | seqType == "INDEL" | seqType == "snp" | seqType == "indel"){
                if(length(grep("leftFlanking", loc.temp)) == 1){
                  temp1.1 = temp1[which(temp1$Identity_percentage == max(temp1$Identity_percentage) & temp1$Subject == Chr & temp1$Length_bp == window.size[j] & temp1$Gap_bp == 0 & temp1$Subject_start >= (Pos.left - leftFlanking) & temp1$Subject_start <= Pos.right),]
                }
                if(length(grep("rightFlanking", loc.temp)) == 1){
                  temp1.1 = temp1[which(temp1$Identity_percentage == max(temp1$Identity_percentage) & temp1$Subject == Chr & temp1$Length_bp == window.size[j] & temp1$Gap_bp == 0 & temp1$Subject_start >= Pos.left & temp1$Subject_start <= (Pos.right + rightFlanking)),]
                }
              }
              if(nrow(temp1.1) == 0) next
              seq.spec.temp$Name[1] = temp1$Query[1]
              seq.spec.temp$Seq[1] = data.frame(split.seq[grep(query.list[k],names(split.seq))])[1,1]
              seq.spec.temp$Chr[1] = Chr
              seq.spec.temp$From[1] = temp1.1$Subject_start[1]
              seq.spec.temp$To[1] = temp1.1$Subject_end[1]
              seq.spec.temp$Percentage[1] = mean(as.numeric(temp1$Identity_percentage))/nrow(temp1)
              seq.spec.temp$Count[1] = nrow(temp1)
              freq = data.frame(letterFrequency(split.seq[grep(query.list[k],names(split.seq))], DNA_BASES))
              GC.content = (freq$G[] + freq$C[])*100/sum(freq[1,])
              if(TmMethod == 1){
                Tm1.value = (freq$G[] + freq$C[])*4 + (freq$A[] + freq$T[])*2
                seq.spec.temp$Tm1[1] = Tm1.value
              }
              if(TmMethod == 2){
                Tm2.value = 81.5 + 0.41*GC.content - 600/nchar(seq.spec.temp$Seq[1])
                seq.spec.temp$Tm2[1] = Tm2.value
              }
              if(TmMethod == "both" | TmMethod == "Both" | TmMethod == "BOTH"){
                Tm1.value = (freq$G[] + freq$C[])*4 + (freq$A[] + freq$T[])*2
                Tm2.value = 81.5 + 0.41*GC.content - 600/nchar(seq.spec.temp$Seq[1])
                seq.spec.temp$Tm1[1] = Tm1.value
                seq.spec.temp$Tm2[1] = Tm2.value
              }
              seq.spec.temp$GC.content[1] = GC.content
              seq.spec.temp$Percentage.color[1] = Specific.colorset[ceiling(seq.spec.temp$Percentage[1])]
              seq.spec.temp$GC.color[1] = ifelse(GC.content != 0, GC.colorset[ceiling(GC.content)], GC.colorset[1])
              seq.spec.temp$Tm1.color[1] = Tm.colorset[ceiling(Tm1.value) - 30]
              seq.spec.temp$Tm2.color[1] = Tm.colorset[ceiling(Tm2.value) - 30]
              seq.spec.temp$Count.color[1] = ifelse(nrow(temp1) <= 100, Count.colorset[nrow(temp1)], Count.colorset[100])
              seq.spec.temp$Percentage[1] = ifelse(seq.spec.temp$Percentage[1] <= 5, 5, seq.spec.temp$Percentage[1])
              seq.spec.temp$Count[1] = ifelse(seq.spec.temp$Count[1] >= 100, 100, seq.spec.temp$Count[1])
              seq.spec.m = rbind(seq.spec.m, seq.spec.temp)
            }
            if(nrow(temp1) == 0){
              next
            }
          }
          seq.spec.m$Loc = (as.numeric(seq.spec.m$From) + as.numeric(seq.spec.m$To))/2
          
          seq.spec.m$GC.content.selected = seq.spec.m$GC.content
          seq.spec.m$Percentage.selected = seq.spec.m$Percentage
          seq.spec.m$Tm1.selected = seq.spec.m$Tm1
          seq.spec.m$Tm2.selected = seq.spec.m$Tm2
          seq.spec.m$Count.selected = seq.spec.m$Count
          for(k in 1:nrow(seq.spec.m)){
            if(seq.spec.m$GC.content[k] <= GCScope[1] | seq.spec.m$GC.content[k] >= GCScope[2]){
              seq.spec.m$GC.content.selected[k] = 0
            }
            if(seq.spec.m$Percentage[k] <= specificityMin){
              seq.spec.m$Percentage.selected[k] = 0
            }
            if(seq.spec.m$Tm1[k] <= TmScope[1] | seq.spec.m$Tm1[k] >= TmScope[2]){
              seq.spec.m$Tm1.selected[k] = 0
            }
            if(seq.spec.m$Tm2[k] <= TmScope[1] | seq.spec.m$Tm2[k] >= TmScope[2]){
              seq.spec.m$Tm2.selected[k] = 0
            }
            if(seq.spec.m$Count[k] >= countMax){
              seq.spec.m$Count.selected[k] = 100
            }
          }
          
          Chr = as.numeric(gsub("Chr", "", Chr))
          
          #### plotting ####
          p1 = ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(GC.content))) + 
            geom_point(color = seq.spec.m$GC.color, size = pointSize) + theme(legend.position = "none") +  
            xlab(NULL) + 
            ylab("GC Content (%)")  + ylim(c(0,100)) + xlim(c(Pos.left, Pos.right)) +
            theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) +
            geom_segment(data = seq.spec.m, mapping = aes(x = Loc, xend = Loc,  y = 0,  yend = GC.content.selected), linetype = 2, color = "red", size = 0.2)
          
          
          if(TmMethod == 1){
            p2 = ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(Tm1))) + 
              geom_point(color = seq.spec.m$Tm1.color, size = pointSize1, shape = pointShape1) + theme(legend.position = "none") +  
              xlab(NULL) + 
              ylab("Tm1 (°C)")  + ylim(c(30,80)) + xlim(c(Pos.left, Pos.right)) +
              theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) + 
              geom_hline(yintercept = c(TmScope[1],TmScope[2]), linetype = hlineType, color = hlineColor, size = hlineSize)
          }
          if(TmMethod == 2){
            p2 = ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(Tm2))) + 
              geom_point(color = seq.spec.m$Tm2.color, size = pointSize2, shape = pointShape2) + theme(legend.position = "none") +  
              xlab(NULL) + 
              ylab("Tm2 (°C)")  + ylim(c(30,80)) + xlim(c(Pos.left, Pos.right)) +
              theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) + 
              geom_hline(yintercept = c(TmScope[1],TmScope[2]), linetype = hlineType, color = hlineColor, size = hlineSize)
          }
          if(TmMethod == "both" | TmMethod == "Both" | TmMethod == "BOTH"){
            p2 = ggplot(data = seq.spec.m) + 
              geom_point(aes(x = Loc, y = as.numeric(Tm2)), color = pointColor1, size = pointSize1, shape = pointShape1) + 
              geom_point(aes(x = Loc, y = as.numeric(Tm1)), color = pointColor2, size = pointSize2, shape = pointShape2) +
              theme(legend.position = "none") +  
              xlab(NULL) + 
              ylab("Tm1 & Tm2 (°C)")  + ylim(c(20,90)) + xlim(c(Pos.left, Pos.right)) +
              theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) + 
              geom_hline(yintercept = c(TmScope[1],TmScope[2]), linetype = hlineType, color = hlineColor, size = hlineSize)
          }
          
          p3 =  ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(Percentage))) + 
            geom_segment(data = seq.spec.m, mapping = aes(x = as.numeric(Loc), xend = as.numeric(Loc), y = as.numeric(Percentage)-0.5, yend = as.numeric(Percentage), size = 0.05), color = seq.spec.m$Percentage.color) + theme(legend.position = "none") +  ylim(c(0, 100)) + xlim(c(Pos.left, Pos.right)) +
            xlab(NULL) + 
            ylab("Sequence Specificity (%)")  + 
            theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) +
            geom_segment(data = seq.spec.m, mapping = aes(x = Loc, xend = Loc,  y = 0,  yend = Percentage.selected), linetype = 2, color = "red", size = 0.2)
          
          p4 = ggplot(data = seq.spec.m, aes(x = Loc, y = Count)) + 
            geom_segment(data = seq.spec.m, mapping = aes(x = as.numeric(Loc), xend = as.numeric(Loc), y = as.numeric(Count)-0.5, yend = as.numeric(Count), size = 0.05), color = seq.spec.m$Count.color) + theme(legend.position = "none") +  ylim(c(0, 100)) + xlim(c(Pos.left, Pos.right)) +
            xlab(paste0("Chr", ifelse(Chr < 10, paste0("0", as.numeric(Chr)), as.numeric(Chr)), ":", Pos.left, "..", Pos.right)) + 
            ylab("Counts")  + 
            theme(panel.border = element_blank()) +
            geom_segment(data = seq.spec.m, mapping = aes(x = Loc, xend = Loc,  y = 100,  yend = Count.selected), linetype = segmentLinetype, color = segmentColor, size = segmentSize)
          
          ## plot setting
          if(GCShow == FALSE & TmShow == TRUE & specificiyShow == TRUE & countShow == TRUE) {p1 = NULL;p = plot_grid(p2, p3, p4, ncol = 1, align = "v")}
          if(TmShow == FALSE & GCShow == TRUE & specificiyShow == TRUE & countShow == TRUE) {p2 = NULL;p = plot_grid(p1, p3, p4, ncol = 1, align = "v")}
          if(specificiyShow == FALSE & GCShow == TRUE & TmShow == FALSE & countShow == TRUE){p3 = NULL;p = plot_grid(p1, p2, p4, ncol = 1, align = "v")} 
          if(countShow == FALSE & GCShow == TRUE & TmShow == TRUE & specificiyShow == TRUE){p4 = NULL;p = plot_grid(p1, p2, p3, ncol = 1, align = "v")} 
          if(GCShow == FALSE & TmShow == FALSE & specificiyShow == TRUE & countShow == TRUE){p1 = NULL;p2 = NULL;p = plot_grid(p3, p4, ncol = 1, align = "v")}
          if(GCShow == FALSE & TmShow == TRUE & specificiyShow == FALSE & countShow == TRUE){p1 = NULL;p3 = NULL;p = plot_grid(p2, p4, ncol = 1, align = "v")}
          if(GCShow == FALSE & TmShow == TRUE & specificiyShow == TRUE & countShow == FALSE){p1 = NULL;p4 = NULL;p = plot_grid(p2, p3, ncol = 1, align = "v")}
          if(GCShow == TRUE & TmShow == FALSE & specificiyShow == FALSE & countShow == TRUE){p2 = NULL;p3 = NULL;p = plot_grid(p1, p4, ncol = 1, align = "v")}
          if(GCShow == TRUE & TmShow == FALSE & specificiyShow == TRUE & countShow == FALSE){p2 = NULL;p4 = NULL;p = plot_grid(p1, p3, ncol = 1, align = "v")}
          if(GCShow == TRUE & TmShow == TRUE & specificiyShow == FALSE & countShow == FALSE){p3 = NULL;p4 = NULL;p = plot_grid(p1, p2, ncol = 1, align = "v")}
          if(GCShow == FALSE & TmShow == FALSE & specificiyShow == FALSE & countShow == TRUE){p1= NULL;p2 = NULL;p3 = NULL;p = plot_grid(p4, ncol = 1, align = "v")}
          if(GCShow == FALSE & TmShow == FALSE & specificiyShow == TRUE & countShow == FALSE){p1= NULL;p2 = NULL;p4 = NULL;plot_grid(p3, ncol = 1, align = "v")}
          if(GCShow == FALSE & TmShow == TRUE & specificiyShow == FALSE & countShow == FALSE){p1= NULL;p3 = NULL;p4 = NULL;plot_grid(p2, ncol = 1, align = "v")}
          if(GCShow == TRUE & TmShow == FALSE & specificiyShow == FALSE & countShow == FALSE){p2= NULL;p3 = NULL;p4 = NULL;plot_grid(p1, ncol = 1, align = "v")}
          if(GCShow == FALSE & TmShow == FALSE & specificiyShow == FALSE & countShow == FALSE){p1 = NULL; p2= NULL;p3 = NULL;p4 = NULL;p = NULL}
          if(GCShow == TRUE & TmShow == TRUE & specificiyShow == TRUE & countShow == TRUE) {p = plot_grid(p1, p2, p3, p4, ncol = 1, align = "v")}
          
          p = p + theme(plot.margin=unit(rep(2,4),'lines'))
          
          ## plot outputting
          #p = plot_grid(p1, p2, p3, p4, ncol = 1, align = "v")
          if(length(p) != 0){
            pdf(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[j], "_for.", For, "_sequence.evaluation.plot.pdf"), width = pdfWidth, height = pdfHeight)
            par(oma = c(1.5, 1, 1.5, 1) + 0.1,mar= c(3, 4, 3, 4) + 0.1)
            print(p)
            dev.off()
          }
          ## data outputting
          names(seq.spec.m) = c("Name", "Seq(5'-3')", "Chr", "From", "To", "Seq.specificity(%)", "Counts", "GC.content(%)", "Tm1", "Tm2", "Seq.specificity.color", "Count.color", "GC.color", "Tm1.color", "Tm2.color", "Anchor.loc", "GC.content.selected", "Percentage.selected", "Tm1.selected", "Tm2.selected", "Count.selected")
          fwrite(seq.spec.m, file = paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[j], "_for.", For, "_sequence.evaluation.csv"), row.names = F, col.names = T, quote = F, sep = "\t")
        }
      }
    }
    # j = 1
    if(dir.exists(inputFile)){
      file.list.1 = list.files(paste0(dir.path, "/", inputFile), recursive = TRUE)
      dir.1 = paste0(dir.path, "/", inputFile, file.list.1)
      dir.1 = dir.1[grep(".fasta|.fas|.fa", dir.1)]
      if(length(str_extract_all(seqType, "Gene|gene|GENE|Fragment|fragment|FRAGMENT")[[1]]) == 1){
        folderName = strsplit(dir.1[1], "/")[[1]][length(strsplit(dir.1[1], "/")[[1]]) - 1]
        if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))){
          dir.create(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))
        }
      }
      ###
      for(j in 1:length(dir.1)){
        if(length(str_extract_all(seqType, "SNP|snp|Indel|indel|INDEL")[[1]]) == 1){
          folderName = strsplit(dir.1[j], "/")[[1]][length(strsplit(dir.1[j], "/")[[1]])]
          folderName = strsplit(folderName, "_")[[1]][1]
          if(!dir.exists(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))){
            dir.create(paste0(dir.path, "/", "Sequence.evaluation/", folderName1, "/", folderName))
          }
        }
        
        input = readDNAStringSet(dir.1[j], format = "fasta")
        # k = 1; l = 6
        for(k in 1:length(input)){
          input.name = names(input)[k]
          input.name = gsub("\\(+\\)|\\(-\\)", "", input.name)
          if(seqType == "SNP" | seqType == "Indel" | seqType == "snp" | seqType == "INDEL" | seqType == "indel"){
            For = "marker.development"
          }else{
            For = gsub("\\.", "", strsplit(input.name, "for")[[1]][2])
          }
          
          for(l in 1:length(window.size)){
            split.seq = seq.splitting(data = input, window.size = window.size[l], step = stepWise)
            if(!is.null(split.seq)){
              writeXStringSet(split.seq, filepath = paste0(dir.path, "/",  "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[l], "_for.", For, "_split.seq.fasta"), compress = FALSE)
              split.seq.path = paste0(dir.path, "/",  "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[l], "_for.", For, "_split.seq.fasta")
              blast_out <- data.frame(system2(command = blastn.dir, 
                                              args = c("-query", split.seq.path,
                                                       "-db", seq.path, 
                                                       "-task blastn",
                                                       "-outfmt", outFormat,
                                                       "-evalue", Evalue,
                                                       "-num_threads", nthreads),
                                              wait = TRUE,
                                              stdout = TRUE)) 
              
              names(blast_out) = c("original")
              blast_out <- blast_out %>% separate(original, blast_out_col, "\t")
              fwrite(blast_out, file = paste0(dir.path, "/",  "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_Evalue.", Evalue, "_window.size.by.", window.size[l], "_for.", For, "_blast.out.csv"), row.names = F, col.names = T, quote = F, sep = "\t")
              for(m in 3:ncol(blast_out)){
                blast_out[,m] = as.numeric(blast_out[,m])
              }
              
              ### sequence specificity calculation
              seq.spec.m = data.frame(matrix(nrow = 0, ncol = 15))
              names(seq.spec.m) = c("Name", "Seq", "Chr", "From", "To", "Percentage", "Count", "GC.content", "Tm1", "Tm2", "Percentage.color", "Count.color", "GC.color", "Tm1.color", "Tm2.color")
              query.list = unique(blast_out$Query)
              Count.colorset = c("red", colorRampPalette(c('blue','black'))(99))
              Tm.colorset = colorRampPalette(c('green','red',"black"))(60)
              GC.colorset = colorRampPalette(c('green','red', "black"))(100)
              Specific.colorset = colorRampPalette(c('black','red'))(100)
              #  m = 1
              for(m in 1:length(query.list)){
                loc.temp = strsplit(query.list[m], "_")[[1]]
                start.end = grep("\\.\\.", loc.temp)
                Pos.left = as.numeric(strsplit(loc.temp[start.end], "\\..")[[1]][1])
                Pos.right = as.numeric(strsplit(loc.temp[start.end], "\\..")[[1]][2])
                if(seqType == "Gene" | seqType == "fragment" | seqType == "gene" | seqType == "Fragment"){
                  leftFlanking = as.numeric(strsplit(loc.temp[grep("leftFlanking", loc.temp)], "\\.")[[1]][2])
                  rightFlanking = as.numeric(strsplit(loc.temp[grep("rightFlanking", loc.temp)], "\\.")[[1]][2])
                }
                if(seqType == "Indel" | seqType == "SNP" | seqType == "INDEL" | seqType == "snp" | seqType == "indel"){
                  if(length(grep("leftFlanking", loc.temp)) == 1){
                    leftFlanking = as.numeric(strsplit(loc.temp[grep("leftFlanking", loc.temp)], "\\.")[[1]][2])
                    rightFlanking = 0
                  }
                  if(length(grep("rightFlanking", loc.temp)) == 1){
                    leftFlanking = 0
                    rightFlanking = as.numeric(strsplit(loc.temp[grep("rightFlanking", loc.temp)], "\\.")[[1]][2])
                  }
                }
                Chr = loc.temp[grep("Chr|Gm", loc.temp)]
                seq.spec.temp = data.frame(matrix(nrow = 1, ncol = 15))
                names(seq.spec.temp) = c("Name", "Seq", "Chr", "From", "To", "Percentage", "Count", "GC.content", "Tm1", "Tm2", "Percentage.color", "Count.color", "GC.color", "Tm1.color", "Tm2.color")
                temp1 = blast_out[which(blast_out$Query == query.list[m]), ]
                if(nrow(temp1) >= 1){
                  if(seqType == "Gene" | seqType == "fragment" | seqType == "gene" | seqType == "Fragment"){
                    temp1.1 = temp1[which(temp1$Identity_percentage == max(temp1$Identity_percentage) & temp1$Subject == Chr & temp1$Length_bp == window.size[l] & temp1$Gap_bp == 0 & temp1$Subject_start >= (Pos.left - leftFlanking) & temp1$Subject_start <= (Pos.right + rightFlanking)),]
                  }
                  if(seqType == "Indel" | seqType == "SNP" | seqType == "INDEL" | seqType == "snp" | seqType == "indel"){
                    if(length(grep("leftFlanking", loc.temp)) == 1){
                      temp1.1 = temp1[which(temp1$Identity_percentage == max(temp1$Identity_percentage) & temp1$Subject == Chr & temp1$Length_bp == window.size[l] & temp1$Gap_bp == 0 & temp1$Subject_start >= (Pos.left - leftFlanking) & temp1$Subject_start <= Pos.right),]
                    }
                    if(length(grep("rightFlanking", loc.temp)) == 1){
                      temp1.1 = temp1[which(temp1$Identity_percentage == max(temp1$Identity_percentage) & temp1$Subject == Chr & temp1$Length_bp == window.size[l] & temp1$Gap_bp == 0 & temp1$Subject_start >= Pos.left & temp1$Subject_start <= (Pos.right + rightFlanking)),]
                    }
                  }
                  if(nrow(temp1.1) == 0) next
                  seq.spec.temp$Name[1] = temp1$Query[1]
                  seq.spec.temp$Seq[1] = data.frame(split.seq[grep(query.list[m],names(split.seq))])[1,1]
                  seq.spec.temp$Chr[1] = Chr
                  seq.spec.temp$From[1] = temp1.1$Subject_start[1]
                  seq.spec.temp$To[1] = temp1.1$Subject_end[1]
                  seq.spec.temp$Percentage[1] = mean(as.numeric(temp1$Identity_percentage))/nrow(temp1)
                  seq.spec.temp$Count[1] = nrow(temp1)
                  freq = data.frame(letterFrequency(split.seq[grep(query.list[m],names(split.seq))], DNA_BASES))
                  GC.content = (freq$G[] + freq$C[])*100/sum(freq[1,])
                  if(TmMethod == 1){
                    Tm1.value = (freq$G[] + freq$C[])*4 + (freq$A[] + freq$T[])*2
                    seq.spec.temp$Tm1[1] = Tm1.value
                  }
                  if(TmMethod == 2){
                    Tm2.value = 81.5 + 0.41*GC.content - 600/nchar(seq.spec.temp$Seq[1])
                    seq.spec.temp$Tm2[1] = Tm2.value
                  }
                  if(TmMethod == "both" | TmMethod == "Both" | TmMethod == "BOTH"){
                    Tm1.value = (freq$G[] + freq$C[])*4 + (freq$A[] + freq$T[])*2
                    Tm2.value = 81.5 + 0.41*GC.content - 600/nchar(seq.spec.temp$Seq[1])
                    seq.spec.temp$Tm1[1] = Tm1.value
                    seq.spec.temp$Tm2[1] = Tm2.value
                  }
                  seq.spec.temp$GC.content[1] = GC.content
                  seq.spec.temp$Percentage.color[1] = Specific.colorset[ceiling(seq.spec.temp$Percentage[1])]
                  seq.spec.temp$GC.color[1] = ifelse(GC.content != 0, GC.colorset[ceiling(GC.content)], GC.colorset[1])
                  seq.spec.temp$Tm1.color[1] = Tm.colorset[ceiling(Tm1.value) - 30]
                  seq.spec.temp$Tm2.color[1] = Tm.colorset[ceiling(Tm2.value) - 30]
                  seq.spec.temp$Count.color[1] = ifelse(nrow(temp1) <= 100, Count.colorset[nrow(temp1)], Count.colorset[100])
                  seq.spec.temp$Percentage[1] = ifelse(seq.spec.temp$Percentage[1] <= 5, 5, seq.spec.temp$Percentage[1])
                  seq.spec.temp$Count[1] = ifelse(seq.spec.temp$Count[1] >= 100, 100, seq.spec.temp$Count[1])
                  seq.spec.m = rbind(seq.spec.m, seq.spec.temp)
                }
                if(nrow(temp1) == 0){
                  next
                }
              }
              
              seq.spec.m$Loc = (as.numeric(seq.spec.m$From) + as.numeric(seq.spec.m$To))/2
              seq.spec.m$GC.content.selected = seq.spec.m$GC.content
              seq.spec.m$Percentage.selected = seq.spec.m$Percentage
              seq.spec.m$Tm1.selected = seq.spec.m$Tm1
              seq.spec.m$Tm2.selected = seq.spec.m$Tm2
              seq.spec.m$Count.selected = seq.spec.m$Count
              
              for(m in 1:nrow(seq.spec.m)){
                if(seq.spec.m$GC.content[m] <= GCScope[1] | seq.spec.m$GC.content[m] >= GCScope[2]){
                  seq.spec.m$GC.content.selected[m] = 0
                }
                if(seq.spec.m$Percentage[m] <= specificityMin){
                  seq.spec.m$Percentage.selected[m] = 0
                }
                if(seq.spec.m$Tm1[m] <= TmScope[1] | seq.spec.m$Tm1[m] >= TmScope[2]){
                  seq.spec.m$Tm1.selected[m] = 0
                }
                if(seq.spec.m$Tm2[m] <= TmScope[1] | seq.spec.m$Tm2[m] >= TmScope[2]){
                  seq.spec.m$Tm2.selected[m] = 0
                }
                if(seq.spec.m$Count[m] >= countMax){
                  seq.spec.m$Count.selected[m] = 100
                }
              }
              
              Chr = as.numeric(gsub("Chr|Gm", "", Chr))
              
              #### plotting ####
              p1 = ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(GC.content))) + 
                geom_point(color = seq.spec.m$GC.color, size = pointSize) + theme(legend.position = "none") +  
                xlab(NULL) + 
                ylab("GC Content (%)")  + ylim(c(0,100)) + xlim(c(Pos.left, Pos.right)) +
                theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) +
                geom_segment(data = seq.spec.m, mapping = aes(x = Loc, xend = Loc,  y = 0,  yend = GC.content.selected), linetype = 2, color = "red", size = 0.2)
              
              if(TmMethod == 1){
                p2 = ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(Tm1))) + 
                  geom_point(color = seq.spec.m$Tm1.color, size = pointSize1, shape = pointShape1) + theme(legend.position = "none") +  
                  xlab(NULL) + 
                  ylab("Tm1 (°C)")  + ylim(c(30,80)) + xlim(c(Pos.left, Pos.right)) +
                  theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) + 
                  geom_hline(yintercept = c(45,55), linetype = hlineType, color = hlineColor, size = hlineSize)
              }
              if(TmMethod == 2){
                p2 = ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(Tm2))) + 
                  geom_point(color = seq.spec.m$Tm2.color, size = pointSize2, shape = pointShape2) + theme(legend.position = "none") +  
                  xlab(NULL) + 
                  ylab("Tm2 (°C)")  + ylim(c(30,80)) + xlim(c(Pos.left, Pos.right)) +
                  theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) + 
                  geom_hline(yintercept = c(45,55), linetype = hlineType, color = hlineColor, size = hlineSize)
              }
              if(TmMethod == "both" | TmMethod == "Both" | TmMethod == "BOTH"){
                p2 = ggplot(data = seq.spec.m) + 
                  geom_point(aes(x = Loc, y = as.numeric(Tm2)), color = pointColor1, size = pointSize1, shape = pointShape1) + 
                  geom_point(aes(x = Loc, y = as.numeric(Tm1)), color = pointColor2, size = pointSize2, shape = pointShape2) +
                  theme(legend.position = "none") +  
                  xlab(NULL) + 
                  ylab("Tm1 & Tm2 (°C)")  + ylim(c(20,90)) + xlim(c(Pos.left, Pos.right)) +
                  theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) + 
                  geom_hline(yintercept = c(45,55), linetype = hlineType, color = hlineColor, size = hlineSize)
              }
              
              p3 =  ggplot(data = seq.spec.m, aes(x = Loc, y = as.numeric(Percentage))) + 
                geom_segment(data = seq.spec.m, mapping = aes(x = as.numeric(Loc), xend = as.numeric(Loc), y = as.numeric(Percentage)-0.5, yend = as.numeric(Percentage), size = 0.05), color = seq.spec.m$Percentage.color) + theme(legend.position = "none") + ylim(c(0, 100)) +
                xlab(NULL) + 
                ylab("Sequence Specificity (%)")  + xlim(c(Pos.left, Pos.right)) +
                theme(panel.border = element_blank(), axis.text.x = element_blank(), axis.ticks = element_blank()) +
                geom_segment(data = seq.spec.m, mapping = aes(x = Loc, xend = Loc,  y = 0,  yend = Percentage.selected), linetype = segmentLinetype, color = segmentColor, size = segmentSize)
              
              p4 = ggplot(data = seq.spec.m, aes(x = Loc, y = Count)) + 
                geom_segment(data = seq.spec.m, mapping = aes(x = as.numeric(Loc), xend = as.numeric(Loc), y = as.numeric(Count)-0.5, yend = as.numeric(Count), size = 0.05), color = seq.spec.m$Count.color) + theme(legend.position = "none") +  ylim(c(0, 100)) + xlim(c(Pos.left, Pos.right)) +
                xlab(paste0("Chr", ifelse(Chr < 10, paste0("0", as.numeric(Chr)), as.numeric(Chr)), ":", Pos.left, "..", Pos.right)) + 
                ylab("Counts")  + 
                theme(panel.border = element_blank()) +
                geom_segment(data = seq.spec.m, mapping = aes(x = Loc, xend = Loc,  y = 100,  yend = Count.selected), linetype = segmentLinetype, color = segmentColor, size = segmentSize)
              
              ## plot setting
              if(GCShow == FALSE & TmShow == TRUE & specificiyShow == TRUE & countShow == TRUE) {p1 = NULL;p = plot_grid(p2, p3, p4, ncol = 1, align = "v")}
              if(TmShow == FALSE & GCShow == TRUE & specificiyShow == TRUE & countShow == TRUE) {p2 = NULL;p = plot_grid(p1, p3, p4, ncol = 1, align = "v")}
              if(specificiyShow == FALSE & GCShow == TRUE & TmShow == FALSE & countShow == TRUE){p3 = NULL;p = plot_grid(p1, p2, p4, ncol = 1, align = "v")} 
              if(countShow == FALSE & GCShow == TRUE & TmShow == TRUE & specificiyShow == TRUE){p4 = NULL;p = plot_grid(p1, p2, p3, ncol = 1, align = "v")} 
              if(GCShow == FALSE & TmShow == FALSE & specificiyShow == TRUE & countShow == TRUE){p1 = NULL;p2 = NULL;p = plot_grid(p3, p4, ncol = 1, align = "v")}
              if(GCShow == FALSE & TmShow == TRUE & specificiyShow == FALSE & countShow == TRUE){p1 = NULL;p3 = NULL;p = plot_grid(p2, p4, ncol = 1, align = "v")}
              if(GCShow == FALSE & TmShow == TRUE & specificiyShow == TRUE & countShow == FALSE){p1 = NULL;p4 = NULL;p = plot_grid(p2, p3, ncol = 1, align = "v")}
              if(GCShow == TRUE & TmShow == FALSE & specificiyShow == FALSE & countShow == TRUE){p2 = NULL;p3 = NULL;p = plot_grid(p1, p4, ncol = 1, align = "v")}
              if(GCShow == TRUE & TmShow == FALSE & specificiyShow == TRUE & countShow == FALSE){p2 = NULL;p4 = NULL;p = plot_grid(p1, p3, ncol = 1, align = "v")}
              if(GCShow == TRUE & TmShow == TRUE & specificiyShow == FALSE & countShow == FALSE){p3 = NULL;p4 = NULL;p = plot_grid(p1, p2, ncol = 1, align = "v")}
              if(GCShow == FALSE & TmShow == FALSE & specificiyShow == FALSE & countShow == TRUE){p1= NULL;p2 = NULL;p3 = NULL;p = plot_grid(p4, ncol = 1, align = "v")}
              if(GCShow == FALSE & TmShow == FALSE & specificiyShow == TRUE & countShow == FALSE){p1= NULL;p2 = NULL;p4 = NULL;plot_grid(p3, ncol = 1, align = "v")}
              if(GCShow == FALSE & TmShow == TRUE & specificiyShow == FALSE & countShow == FALSE){p1= NULL;p3 = NULL;p4 = NULL;plot_grid(p2, ncol = 1, align = "v")}
              if(GCShow == TRUE & TmShow == FALSE & specificiyShow == FALSE & countShow == FALSE){p2= NULL;p3 = NULL;p4 = NULL;plot_grid(p1, ncol = 1, align = "v")}
              if(GCShow == FALSE & TmShow == FALSE & specificiyShow == FALSE & countShow == FALSE){p1 = NULL; p2= NULL;p3 = NULL;p4 = NULL;p = NULL}
              if(GCShow == TRUE & TmShow == TRUE & specificiyShow == TRUE & countShow == TRUE) {p = plot_grid(p1, p2, p3, p4, ncol = 1, align = "v")}
              
              p = p + theme(plot.margin=unit(rep(2,4),'lines'))
              
              ## plot outputting
              if(length(p) != 0){
                pdf(paste0(dir.path, "/",  "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[l], "_for.", For, "_sequence.evaluation.plot.pdf"), width = pdfWidth, height = pdfHeight)
                par(oma = c(1.5, 1, 1.5, 1) + 0.1,mar= c(3, 4, 3, 4) + 0.1)
                print(p)
                dev.off()
              }
              
              ## data outputting
              names(seq.spec.m) = c("Name", "Seq(5'-3')", "Chr", "From", "To", "Seq.specificity(%)", "Counts", "GC.content(%)", "Tm1", "Tm2", "Seq.specificity.color", "Count.color", "GC.color", "Tm1.color", "Tm2.color", "Anchor.loc", "GC.content.selected", "Percentage.selected", "Tm1.selected", "Tm2.selected", "Count.selected")
              fwrite(seq.spec.m, file = paste0(dir.path, "/",  "Sequence.evaluation/", folderName1, "/", folderName, "/", input.name, "_window.size.by.", window.size[l], "_for.", For, ".sequence.evaluation.csv"), row.names = F, col.names = T, quote = F, sep = "\t")
              rm(seq.spec.m)
            }
          }
        }
      }
    }
  }
  
  cat("\nSeq.evaluation is Done!")
}




#' This is some description of this function.
#' @title to design primers for qRT-PCR primers of certain gene.
#'
#' @description By using this package, you could use function of primer.designing.for.qRT.PCR to design primers for qRT-PCR primers of certain gene.
#'
#' @details see above
#'
#' @param seqEvaluation: seqEvaluation folder.
#' @param gffFile: general feature format of certain genome, it must contain at least Gene.ID, Chr, Start, End, Strand, Type.
#' @param plotting: logical value indicates whether to plot primers or not.
#' @param TmScope: numeric scope indicates the min and max of primer Tm, default value is 'c(40, 60)'.
#' @param GCScope: numeric scope indicates the min and max of primer GC content (%), default value is 'c(35, 65)'.
#' @param specificityMin: numeric value indicates the minimum standard of sequence specificity (%), default value is 98%.
#' @param countMax: numeric value indicates the maximum standard of counts of this primer mathched to different position on the chromosome, default value is 2.
#' @param endMatch: logical value indicates whether the primer end (3') matched to genome, default value is TRUE
#' @param GCend: logical value indicates whether the primer end (3') should be G:C or not, default value is TRUE
#' @param lengthScope: numeric scope indicates the expected min and max amplicon length of primer pairs, default value is 'c(70, 150)'.
#' @param primerLength: numeric scope indicates the min and max length of primer, default value is 'c(20, 25)'.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param primerStrand: 'F' or 'R', or c('F', 'R')
#' @param Fcolor: color value for forward primers, default is "#B2182B".
#' @param Rcolor: color value for reverse primers, default is "#2166AC".
#' @param lcolor: color value for line connecting forward and reverse primer pairs, default is 'black'.
#' @param overlapMin: numeric value indicates at least how many base pairs should be acrossing different exons, to eliminate none specific matching to genome DNA. Default is 5bp.
#' @return files and folder
#' @export primer.designing.for.qRT.PCR
#' @examples primer.designing.for.qRT.PCR(seqEvaluation = "./Sequence.evaluation/", gffFile = "./Wm82.a2.v1.gene.gff")
#' 

# primer.designing.for.qRT.PCR(seqEvaluation = "./Sequence.evaluation/", gffFile = "./Wm82.a2.v1.gene.gff")

primer.designing.for.qRT.PCR = function(seqEvaluation = NULL, gffFile = NULL, plotting = NULL, TmScope = NULL, GCScope = NULL, specificityMin = NULL, countMax = NULL, endMatch = NULL, GCend = NULL, lengthScope = NULL, primerLength = NULL, TmMethod = NULL, primerStrand = NULL, Fcolor = NULL, Rcolor = NULL, lcolor = NULL, overlapMin = NULL, ...){
  
  library(stringr)
  library(seqinr)
  library(Biostrings)
  library(tidyr)
  library(xlsx)
  library(WriteXLS)
  library(data.table)
  library(ggplot2)
  
  dir.path = getwd()
  
  if(!dir.exists(paste0(dir.path, "/", "Designed.primers"))){
    dir.create(paste0(dir.path, "/", "Designed.primers"))
  }
  if(!dir.exists(paste0(dir.path, "/", "Designed.primers/", "qRT.primers"))){
    dir.create(paste0(dir.path, "/", "Designed.primers/", "qRT.primers"))
  }
  
  if(is.null(seqEvaluation)) stop("'seqEvaluation' is required!")
  if(is.null(gffFile)) stop("'gffFile' is required!")
  if(is.null(plotting)) plotting = TRUE
  if(is.null(TmScope)) TmScope = c(40, 60)
  if(is.null(GCScope)) GCScope = c(35, 65)
  if(is.null(countMax)) countMax = 2
  if(is.null(specificityMin)) specificityMin = 98
  if(is.null(endMatch)) endMatch = TRUE
  if(is.null(GCend)) GCend = TRUE
  if(is.null(lengthScope)) lengthScope = c(70, 150)
  if(is.null(primerLength)) primerLength = c(20, 25)
  if(is.null(overlapMin)) overlapMin = 5
  if(is.null(TmMethod)) TmMethod = "both"
  if(is.null(primerStrand)) primerStrand = c('F', 'R')
  if(is.null(plotting)) plotting = TRUE
  if(is.null(Fcolor)) Fcolor = "#B2182B"
  if(is.null(Rcolor)) Rcolor = "#2166AC"
  if(is.null(lcolor)) lcolor = "black"
  
  if(!dir.exists(seqEvaluation)){
    stop("'seqEvaluation' should be a folder contains 'Blast.output', 'Splitted.seq', 'window.size.by.*' etc., please perform seq.evaluation() analysis before primer designing!")
  }
  
  gff = fread(gffFile, header = T, sep = "\t", fill = TRUE)
  if(ncol(gff) == 1){
    gff = fread(gffFile, header = T, sep = ",", fill = TRUE)
    if(ncol(gff) == 1){
      gff = fread(gffFile, header = T, sep = " ", fill = TRUE)
    }
  }
  setkeyv(gff, names(gff))
  if(length(grep("(Gene.ID|Chr|Start|End|Strand|Type)", names(gff))) == 6){
    gff = gff[,c("Gene.ID", "Chr", "Start", "End", "Strand", "Type")]
    type.length = length(unique(gff$Type))
    types = unique(gff$Type)[1]
    for(i in 2:length(unique(gff$Type))){
      types = paste0(types, ", ", unique(gff$Type)[i])
    }
    # cat(paste0("gffFile contains ", nrow(gff), " rows, ", type.length, " types, including ", types))
  }else{
    stop("gff file should contain at least the following columns: 'Gene.ID', 'Chr', 'Start', 'End', 'Strand', and 'Type'! Please check your gff file format!")
  }
  
  # file merging function
  data.merging = function(fileList = NULL, header = NULL, skipRow = NULL, ...){
    library(data.table)
    if(is.null(fileList)) stop("'fileList' in 'data.merging' is required!")
    if(is.null(header)) header = T
    if(is.null(skipRow)) skipRow = 0
    data = fread(fileList[1], header = header, stringsAsFactors = F, sep = "\t", skip = skipRow, fill = T)
    if(ncol(data) == 1){
      data = fread(fileList[1], header = header, stringsAsFactors = F, sep = ",", skip = skipRow, fill = T)
      if(ncol(data) == 1){
        data = fread(fileList[1], header = header, stringsAsFactors = F, sep = " ", skip = skipRow, fill = T)
      }
    }
    for(i in 2:length(fileList)){
      temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = "\t", skip = skipRow, fill = T)
      if(ncol(temp) == 1){
        temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = ",", skip = skipRow, fill = T)
        if(ncol(temp) == 1){
          temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = " ", skip = skipRow, fill = T)
        }
      }
      data = rbind(data, temp)
    }
    return(data)
  }
  
  ### fasta sequence merging
  seq.merging = function(seqDir){
    seq = readDNAStringSet(seqDir[1], format = "fasta")
    for(i in 2:length(seqDir)){
      temp = readDNAStringSet(seqDir[i], format = "fasta")
      seq = append(seq, temp)
    }
    return(seq)
  }
  
  file.list = list.files(paste0(dir.path, "/", seqEvaluation), recursive = TRUE)
  dir = paste0(dir.path, "/", seqEvaluation, file.list)
  dir = dir[-grep(".pdf", dir)]
  blast.dir = dir[grep("blast.out.csv", dir)]
  dir = dir[-grep("blast.out.csv", dir)]
  seqEval.dir = dir[grep("sequence.evaluation.csv", dir)]
  split.dir = dir[grep("split.seq.fasta", dir)]
  mRNA.cds.dir = seqEval.dir[grep("mRNA", seqEval.dir)]
  mRNA.blast.dir = blast.dir[grep("mRNA", blast.dir)]
  mRNA.blast.dir = mRNA.blast.dir[grep("qRT-PCR|qRT.PCR", mRNA.blast.dir)]
  mRNA.cds.dir.name = c()
  
  for(i in 1:length(mRNA.cds.dir)){
    temp = strsplit(strsplit(mRNA.cds.dir[i], "/")[[1]][length(strsplit(mRNA.cds.dir[i], "/")[[1]])], "_")[[1]]
    temp = paste0(temp[1], "_", temp[2])
    mRNA.cds.dir.name = c(mRNA.cds.dir.name, temp)
  }
  mRNA.list = unique(mRNA.cds.dir.name)
  # i = 1
  for(i in 1:length(mRNA.list)){
    #######
    dir.temp = mRNA.cds.dir[grep(mRNA.list[i], mRNA.cds.dir)]
    overall = data.merging(fileList = dir.temp)
    overall = overall[!duplicated(overall),]
    type = str_extract_all(mRNA.cds.dir[i], "(mRNA)")[[1]]
    names(overall) = gsub("\\(.?\\)|\\(5'-3'\\)", "", names(overall))
    setkeyv(overall, names(overall))
    overall.NA = overall[is.na(overall$To),]
    overall = overall[!is.na(overall$From),]
    
    #######
    split.dir.temp = split.dir[grep(mRNA.list[i], split.dir)]
    split.dir.temp = split.dir.temp[grep("qRT-PCR|qRT.PCR", split.dir.temp)]
    split.seq = seq.merging(seqDir = split.dir.temp)
    split.seq = data.table(cbind(names(split.seq), data.frame(split.seq[names(split.seq)])))
    names(split.seq) = c("Name", "Seq")
    setkeyv(split.seq, names(split.seq))
    split.seq$From = NA
    split.seq$To = NA
    split.seq$Length = NA
    # j = 1
    for(j in 1:nrow(split.seq)){
      split.seq$From[j] = as.numeric(strsplit(split.seq$Name[j], "_")[[1]][9])
      split.seq$To[j] = as.numeric(strsplit(split.seq$Name[j], "_")[[1]][11])
      split.seq$Length[j] = as.numeric(split.seq$To[j]) - as.numeric(split.seq$From[j]) + 1
    }
    # split.seq[, c('From') := as.numeric(unlist(strsplit(split.seq$Name, "_"))[seq(9, nrow(split.seq)*11, by = 11)])]
    # split.seq[, c('To') := as.numeric(unlist(strsplit(split.seq$Name, "_"))[seq(11, nrow(split.seq)*11, by = 11)])]
    # split.seq[, c('Length') := To - From + 1]
    split.seq = as.data.table(split.seq)
    setkeyv(split.seq, names(split.seq))
    
    
    #######
    Chr = strsplit(strsplit(dir.temp[1], "/")[[1]][length(strsplit(dir.temp[1], "/")[[1]])], "_")[[1]][3]
    region = strsplit(strsplit(dir.temp[1], "/")[[1]][length(strsplit(dir.temp[1], "/")[[1]])], "_")[[1]][4]
    region = as.numeric(strsplit(region, "\\..")[[1]])
    leftFlanking = strsplit(strsplit(dir.temp[1], "/")[[1]][length(strsplit(dir.temp[1], "/")[[1]])], "_")[[1]][5]
    leftFlanking = as.numeric(strsplit(leftFlanking, "\\.")[[1]][2])
    rightFlanking = strsplit(strsplit(dir.temp[1], "/")[[1]][length(strsplit(dir.temp[1], "/")[[1]])], "_")[[1]][6]
    rightFlanking = as.numeric(strsplit(rightFlanking, "\\.")[[1]][2])
    
    #######
    mRNAName = strsplit(mRNA.list[i], "_")[[1]][1]
    mRNA.gff = gff[which(gff$Gene.ID == mRNAName & gff$Type != "mRNA"),]
    Strand = unique(mRNA.gff$Strand)
    if(leftFlanking >= 0 & rightFlanking >= 0){
      flanking = data.table(matrix(nrow = 2, ncol = ncol(mRNA.gff)))
      names(flanking) = names(mRNA.gff)
      flanking$Type[1] = "leftFlanking"; flanking$Type[2] = "rightFlanking"
      if(Strand == "+"){
        flanking$Start[1] = min(mRNA.gff$Start) - leftFlanking
        flanking$End[1] = min(mRNA.gff$Start) - 1
        flanking$Start[2] = max(mRNA.gff$End) + 1
        flanking$End[2] = max(mRNA.gff$End) + rightFlanking
      }else{
        flanking$End[1] = max(mRNA.gff$End) + leftFlanking
        flanking$Start[1] = max(mRNA.gff$End) + 1
        flanking$Start[2] = min(mRNA.gff$Start) - rightFlanking
        flanking$End[2] = min(mRNA.gff$Start) - 1
      }
      mRNA.gff = rbind(mRNA.gff, flanking)
      mRNA.gff[,c(1,2,5)] = mRNA.gff[1,c(1,2,5)]
    }
    
    mRNA.gff = mRNA.gff[order(mRNA.gff$Start),]
    mRNA.gff$From = 0;mRNA.gff$To = 0
    #######
    if(Strand == "+"){
      mRNA.gff$fragmentLength = mRNA.gff$End - mRNA.gff$Start + 1
      for(j in 1:nrow(mRNA.gff)){
        if(j == 1){
          mRNA.gff$From[j] = 1; mRNA.gff$To[j] = mRNA.gff$fragmentLength[j]
        }
        if(j > 1){
          mRNA.gff$From[j] = mRNA.gff$To[j-1] + 1; mRNA.gff$To[j] = mRNA.gff$From[j] + mRNA.gff$fragmentLength[j] - 1
        }
      }
    }else{
      Start = mRNA.gff$End
      End = mRNA.gff$Start
      mRNA.gff$Start = Start
      mRNA.gff$End = End
      mRNA.gff = mRNA.gff[order(mRNA.gff$End, decreasing = T),]
      mRNA.gff$fragmentLength = mRNA.gff$Start - mRNA.gff$End + 1
      for(j in 1:nrow(mRNA.gff)){
        if(j == 1){
          mRNA.gff$From[j] = 1; mRNA.gff$To[j] = mRNA.gff$fragmentLength[j]
        }
        if(j > 1){
          mRNA.gff$From[j] = mRNA.gff$To[j-1] + 1; mRNA.gff$To[j] = mRNA.gff$From[j] + mRNA.gff$fragmentLength[j] - 1
        }
      }
    }
    
    ###
    split.seq$Start = NA
    split.seq$End = NA
    split.seq$gffStart1 = NA
    split.seq$gffEnd1 = NA
    split.seq$gffStart2 = NA
    split.seq$gffEnd2 = NA
    split.seq$Left = NA
    split.seq$Right = NA
    split.seq$bridge = "No"
    split.seq = as.data.table(split.seq)
    setkeyv(split.seq, names(split.seq))
    split.seq = split.seq[order(split.seq$From),]
    # j = 6; k = 1
    for(j in 1:nrow(split.seq)){
      window.temp = split.seq$To[j] - split.seq$From[j] + 1
      if(Strand == "+"){
        for(k in 1:nrow(mRNA.gff)){
          if(split.seq$From[j] <= mRNA.gff$To[k] & split.seq$From[j] >= mRNA.gff$From[k]){
            split.seq$Start[j] = mRNA.gff$Start[k] + split.seq$From[j] - ifelse(k >= 2, mRNA.gff$To[k-1], 0) -1
            split.seq$gffStart1[j] = mRNA.gff$Start[k]
            split.seq$gffEnd1[j] = mRNA.gff$End[k]
            if(split.seq$To[j] <= mRNA.gff$To[k]){
              split.seq$End[j] = mRNA.gff$Start[k] + split.seq$From[j] - ifelse(k >= 2, mRNA.gff$To[k-1], 0) + window.temp - 2
              split.seq$gffStart2[j] = mRNA.gff$Start[k]
              split.seq$gffEnd2[j] = mRNA.gff$End[k]
            }else{
              split.seq$gffStart2[j] = mRNA.gff$Start[k+1]
              split.seq$gffEnd2[j] = mRNA.gff$End[k+1]
              left = mRNA.gff$To[k] - split.seq$From[j] + 1
              right = split.seq$To[j] - mRNA.gff$To[k]
              split.seq$End[j] = mRNA.gff$Start[k+1]  + right - 1
              split.seq$Left[j] = left
              split.seq$Right[j] = right
              split.seq$bridge[j] = "Yes"
            }
          }
        }
      }
      if(Strand == "-"){
        for(k in 1:nrow(mRNA.gff)){
          if(split.seq$From[j] <= mRNA.gff$To[k] & split.seq$From[j] >= mRNA.gff$From[k]){
            split.seq$Start[j] = mRNA.gff$Start[k] - split.seq$From[j] + ifelse(k >= 2, mRNA.gff$To[k-1], 0) + 1
            split.seq$gffStart1[j] = mRNA.gff$End[k]
            split.seq$gffEnd1[j] = mRNA.gff$Start[k]
            if(split.seq$To[j] <= mRNA.gff$To[k]){
              split.seq$End[j] = mRNA.gff$Start[k] - split.seq$From[j] + ifelse(k >= 2, mRNA.gff$To[k-1], 0) + 2 - window.temp
              split.seq$gffStart2[j] = mRNA.gff$End[k]
              split.seq$gffEnd2[j] = mRNA.gff$Start[k]
            }else{
              split.seq$gffStart2[j] = mRNA.gff$End[k+1]
              split.seq$gffEnd2[j] = mRNA.gff$Start[k+1]
              left = mRNA.gff$From[k+1] - split.seq$From[j]
              right = split.seq$To[j] - mRNA.gff$To[k]
              split.seq$End[j] = mRNA.gff$Start[k+1]  - right + 1
              split.seq$Left[j] = left
              split.seq$Right[j] = right
              split.seq$bridge[j] = "Yes"
            }
          }
        }
      }
    }
    split.seq = as.data.table(split.seq)
    setkeyv(split.seq, names(split.seq))
    
    #######
    blast.dir.temp = mRNA.blast.dir[grep(mRNA.list[i], mRNA.blast.dir)]
    blast.out = data.merging(fileList = blast.dir.temp)
    setkeyv(blast.out, names(blast.out))
    blast.out$From = NA
    blast.out$To = NA
    blast.out$Length = NA
    # j = 1
    for(j in 1:nrow(blast.out)){
      blast.out$From[j] = as.numeric(strsplit(blast.out$Query[j], "_")[[1]][9])
      blast.out$To[j] = as.numeric(strsplit(blast.out$Query[j], "_")[[1]][11])
      blast.out$Length[j] = as.numeric(blast.out$To[j]) - as.numeric(blast.out$From[j]) + 1
    }
    # blast.out[, c('From') := as.numeric(unlist(strsplit(blast.out$Query, "_"))[seq(9, nrow(blast.out)*11, by = 11)])]
    # blast.out[, c('To') := as.numeric(unlist(strsplit(blast.out$Query, "_"))[seq(11, nrow(blast.out)*11, by = 11)])]
    # blast.out[, c('Length') := To - From + 1]
    blast.out = as.data.table(blast.out)
    setkeyv(data.table(blast.out), names(blast.out))
    window = sort(unique(blast.out$Length))
    
    ## selection of overlaped primers
    overlap.select = split.seq[which(split.seq$bridge == "Yes" & split.seq$Left >= overlapMin & split.seq$Right >= overlapMin),]
    blast.select = blast.out[which(blast.out$Query %in% overlap.select$Name & blast.out$Length %in% overlap.select$Length),]
    if(nrow(blast.out) >= 1){
      overlap.select.1 = overlap.select[is.na(match(overlap.select$Name, blast.select$Query)),]
    }else{
      overlap.select.1 = overlap.select
    }
    
    if(Strand == "+"){
      overlap.select.1 = overlap.select.1[which(overlap.select.1$Start >= (min(c(mRNA.gff$Start,mRNA.gff$End)) + leftFlanking) & overlap.select.1$End <= (max(c(mRNA.gff$Start,mRNA.gff$End)) - rightFlanking)),]
    }else{
      overlap.select.1 = overlap.select.1[which(overlap.select.1$End >= (min(c(mRNA.gff$Start,mRNA.gff$End)) + rightFlanking) & overlap.select.1$Start <= (max(c(mRNA.gff$Start,mRNA.gff$End)) - leftFlanking)),]
    }
    
    overlap.select = overlap.select.1
    if(nrow(overlap.select) >= 1){
      for(j in 1:nrow(overlap.select)){
        if(overlap.select$Start[j] >= overlap.select$End[j]){
          temp = overlap.select$Start[j]
          overlap.select$Start[j] = overlap.select$End[j]
          overlap.select$End[j] = temp
        }
      }
    }else{
      cat("There is no primer identified across different exons for qRT-PCR!")
    }
    
    ## primer selection
    ## Tm filtration
    if(TmMethod == "both"){
      overall.temp1 = overall[which((overall$Tm1 >= TmScope[1] & overall$Tm1 <= TmScope[2]) | (overall$Tm2 >= TmScope[2] & overall$Tm2 <= TmScope[2])),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("The TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation."))
        next
      }
    }
    if(TmMethod == 1){
      overall.temp1 = overall[which(overall$Tm1 >= TmScope[1] & overall$Tm1 <= TmScope[2]),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("The TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation."))
        next
      }
    }
    if(TmMethod == 2){
      overall.temp1 = overall[which(overall$Tm2 >= TmScope[2] & overall$Tm2 <= TmScope[2]),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("The TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation."))
        next()
      }
    }
    
    ## GC content filtration
    overall.temp2 = overall.temp1[which(overall.temp1$GC.content >= GCScope[1] & overall.temp1$GC.content <= GCScope[2]),]
    if(nrow(overall.temp2) == 0){
      warning(paste0("The GCScope between ", GCScope[1], " and ", GCScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation."))
      next()
    }
    
    ## count filtration
    if(!is.null(countMax)){
      overall.temp3 = overall.temp2[which(overall.temp2$Counts <= countMax),]
    }else{
      overall.temp3 = overall.temp2
    }
    
    ## sequence specificity
    if(!is.null(specificityMin)){
      overall.temp4 = overall.temp3[which(overall.temp3$Seq.specificity >= specificityMin),]
    }else{
      overall.temp4 = overall.temp3
    }
    overall.temp4 = overall.temp4[order(overall.temp4$From),]
    for(j in 1:nrow(overall.temp4)){
      if(overall.temp4$From[j] >= overall.temp4$To[j]){
        temp = overall.temp4$From[j]
        overall.temp4$From[j] = overall.temp4$To[j]
        overall.temp4$To[j] = temp
      }
    }
    
    overall.temp4 = as.data.table(overall.temp4)
    setkeyv(overall.temp4, names(overall.temp4))
    if(Strand == "+"){
      overall.temp4 = overall.temp4[which(overall.temp4$From >= (min(c(mRNA.gff$Start,mRNA.gff$End)) + leftFlanking) & overall.temp4$To <= (max(c(mRNA.gff$Start,mRNA.gff$End)) - rightFlanking)),]
    }else{
      overall.temp4 = overall.temp4[which(overall.temp4$From >= (min(c(mRNA.gff$Start,mRNA.gff$End)) + rightFlanking) & overall.temp4$To <= (max(c(mRNA.gff$Start,mRNA.gff$End)) - leftFlanking)),]
    }
    
    ###################
    ## length selection
    ## overlapped primer as Forward
    if(nrow(overlap.select) >= 1 & nrow(overall.temp4) >= 1){
      length.select.1 = data.table(matrix(nrow = 0, ncol = 11))
      names(length.select.1) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
      ## overlapped primer as Reverse
      length.select.2 = data.table(matrix(nrow = 0, ncol = 11))
      names(length.select.2) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
      if(Strand == "+"){
        for(j in 1:nrow(overall.temp4)){
          for(k in 1:nrow(overlap.select)){
            distance1 = overlap.select$Start[k] - overall.temp4$To[j]
            if(distance1 >= lengthScope[1] & distance1 <= lengthScope[2]){
              temp1 = data.table(matrix(nrow = 1, ncol = 11))
              names(temp1) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
              temp1$seqName2[1] = overlap.select$Name[k]
              temp1$seq2[1] = overlap.select$Seq[k]
              temp1$seqStart2[1] = overlap.select$Start[k]
              temp1$seqEnd2[1] = overlap.select$End[k]
              temp1$primerStrand2[1] = "R"
              temp1$seqName1[1] = overall.temp4$Name[j]
              temp1$seq1[1] = overall.temp4$Seq[j]
              temp1$seqStart1[1] = overall.temp4$From[j]
              temp1$seqEnd1[1] = overall.temp4$To[j]
              temp1$primerStrand1[1] = "F"
              temp1$Distance[1] = distance1
              length.select.1 = rbind(length.select.1, temp1)
            }
            distance2 = overall.temp4$From[j] - overlap.select$End[k]
            if(distance2 >= lengthScope[1] & distance2 <= lengthScope[2]){
              temp2 = data.table(matrix(nrow = 1, ncol = 11))
              names(temp2) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
              temp2$seqName2[1] = overall.temp4$Name[j]
              temp2$seq2[1] = overall.temp4$Seq[j]
              temp2$seqStart2[1] = overall.temp4$From[j]
              temp2$seqEnd2[1] = overall.temp4$To[j]
              temp2$primerStrand2[1] = "R"
              temp2$seqName1[1] = overlap.select$Name[k]
              temp2$seq1[1] = overlap.select$Seq[k]
              temp2$seqStart1[1] = overlap.select$Start[k]
              temp2$seqEnd1[1] = overlap.select$End[k]
              temp2$primerStrand1[1] = "F"
              temp2$Distance[1] = distance2
              length.select.2 = rbind(length.select.2, temp2)
            }
          }
        }
      }
      # j = 80; k = 14
      if(Strand == "-"){
        for(j in 1:nrow(overall.temp4)){
          for(k in 1:nrow(overlap.select)){
            distance1 = overlap.select$Start[k] - overall.temp4$To[j]
            if(distance1 >= lengthScope[1] & distance1 <= lengthScope[2]){
              temp1 = data.table(matrix(nrow = 1, ncol = 11))
              names(temp1) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
              temp1$seqName2[1] = overlap.select$Name[k]
              temp1$seq2[1] = overlap.select$Seq[k]
              temp1$seqStart2[1] = overlap.select$Start[k]
              temp1$seqEnd2[1] = overlap.select$End[k]
              temp1$primerStrand2[1] = "R"
              temp1$seqName1[1] = overall.temp4$Name[j]
              temp1$seq1[1] = overall.temp4$Seq[j]
              temp1$seqStart1[1] = overall.temp4$From[j]
              temp1$seqEnd1[1] = overall.temp4$To[j]
              temp1$primerStrand1[1] = "F"
              temp1$Distance[1] = distance1
              length.select.1 = rbind(length.select.1, temp1)
            }
            distance2 = overall.temp4$From[j] - overlap.select$End[k]
            if(distance2 >= lengthScope[1] & distance2 <= lengthScope[2]){
              temp2 = data.table(matrix(nrow = 1, ncol = 11))
              names(temp2) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
              temp2$seqName2[1] = overall.temp4$Name[j]
              temp2$seq2[1] = overall.temp4$Seq[j]
              temp2$seqStart2[1] = overall.temp4$From[j]
              temp2$seqEnd2[1] = overall.temp4$To[j]
              temp2$primerStrand2[1] = "R"
              temp2$seqName1[1] = overlap.select$Name[k]
              temp2$seq1[1] = overlap.select$Seq[k]
              temp2$seqStart1[1] = overlap.select$Start[k]
              temp2$seqEnd1[1] = overlap.select$End[k]
              temp2$primerStrand1[1] = "F"
              temp2$Distance[1] = distance2
              length.select.2 = rbind(length.select.2, temp2)
            }
          }
        }
      }
      
      if(nrow(length.select.1) == 0 | nrow(length.select.2) == 0){
        warning(paste0("The lengthScope between ", lengthScope[1], " and ", lengthScope[2], " for ", mRNA.list[i], " is too stringent, please try other values for this parameter."))
        GCend.select.1 = length.select.1
        GCend.select.2 = length.select.2
      }else{
        GCend.select.1 = length.select.1
        GCend.select.2 = length.select.2
      }
      
      ## primer length filtration
      if(nrow(GCend.select.1) >= 1){
        GCend.select.1$seq1Length = nchar(GCend.select.1$seq1)
        GCend.select.1$seq2Length = nchar(GCend.select.1$seq2)
        GCend.select.1 = data.table(GCend.select.1)
        setkeyv(GCend.select.1, names(GCend.select.1))
        GCend.select.1 = GCend.select.1[which(GCend.select.1$seq1Length >= primerLength[1] & GCend.select.1$seq1Length <= primerLength[2] & GCend.select.1$seq2Length >= primerLength[1] & GCend.select.1$seq2Length <= primerLength[2]),]
        GCend.select.1 = GCend.select.1[,-c(grep('seq1Length', names(GCend.select.1)), grep('seq2Length', names(GCend.select.1)))]
      }
      if(nrow(GCend.select.2) >= 2){
        GCend.select.2$seq1Length = nchar(GCend.select.2$seq1)
        GCend.select.2$seq2Length = nchar(GCend.select.2$seq2)
        GCend.select.2 = data.table(GCend.select.2)
        setkeyv(GCend.select.2, names(GCend.select.2))
        GCend.select.2 = GCend.select.2[which(GCend.select.2$seq1Length >= primerLength[1] & GCend.select.2$seq1Length <= primerLength[2] & GCend.select.2$seq2Length >= primerLength[1] & GCend.select.2$seq2Length <= primerLength[2]),]
        GCend.select.2 = GCend.select.2[,-c(grep('seq1Length', names(GCend.select.2)), grep('seq2Length', names(GCend.select.2)))]
      }
      
      if(nrow(GCend.select.1) == 0 | nrow(GCend.select.2) == 0){
        warning(paste0("The primerLenth between ", primerLength[1], " and ", primerLength[2], " for ", mRNA.list[i], " is too stringent, please try other values for this parameter."))
      }else{
        GCend.select.1 = GCend.select.1
        GCend.select.2 = GCend.select.2
      }
      
      ## endMatch
      if(GCend == TRUE){
        if(nrow(GCend.select.1) >= 1){
          GCend.select.1$seq1endBase = NA
          GCend.select.1$seq2startBase = NA
          for(j in 1:nrow(GCend.select.1)){
            GCend.select.1$seq1endBase[j] = strsplit(GCend.select.1$seq1[j], "")[[1]][length(strsplit(GCend.select.1$seq1[j], "")[[1]])]
            GCend.select.1$seq2startBase[j] = strsplit(GCend.select.1$seq2[j], "")[[1]][1]
          }
          setkeyv(GCend.select.1, names(GCend.select.1))
          GCend.select.1 = GCend.select.1[which((GCend.select.1$seq1endBase == "G" | GCend.select.1$seq1endBase == "C") & (GCend.select.1$seq2startBase == "G" | GCend.select.1$seq2startBase== "C")),]
        }
      }else{
        GCend.select.1 = GCend.select.1
      }
      
      ## 
      if(GCend == TRUE){
        if(nrow(GCend.select.2) >= 1){
          GCend.select.2$seq1endBase = NA
          GCend.select.2$seq2startBase = NA
          for(j in 1:nrow(GCend.select.2)){
            GCend.select.2$seq1endBase[j] = strsplit(GCend.select.2$seq1[j], "")[[1]][length(strsplit(GCend.select.2$seq1[j], "")[[1]])]
            GCend.select.2$seq2startBase[j] = strsplit(GCend.select.2$seq2[j], "")[[1]][1]
          }
          setkeyv(GCend.select.2, names(GCend.select.2))
          GCend.select.2 = GCend.select.2[which((GCend.select.2$seq1endBase == "G" | GCend.select.2$seq1endBase == "C") & (GCend.select.2$seq2startBase == "G" | GCend.select.2$seq2startBase== "C")),]
        }
      }else{
        GCend.select.2 = GCend.select.2
      }
      
      ## reversing R primers
      if(nrow(GCend.select.1) >= 1){
        GCend.select.1$seq2 = as.character(reverseComplement(DNAStringSet(GCend.select.1$seq2)))
        names(GCend.select.1) = gsub("seq2", "revc.seq2", names(GCend.select.1))
        GCend.select.1 = GCend.select.1[,-c(12,13)]
      }
      if(nrow(GCend.select.2) >= 1){
        GCend.select.2$seq2 = as.character(reverseComplement(DNAStringSet(GCend.select.2$seq2)))
        names(GCend.select.2) = gsub("seq2", "revc.seq2", names(GCend.select.2))
        GCend.select.2 = GCend.select.2[,-c(12,13)]
      }
      
      if(nrow(GCend.select.2) >= 1 & nrow(GCend.select.1) >= 1){
        primer.select = rbind(GCend.select.1, GCend.select.2)
      }else{
        if(nrow(GCend.select.2) >= 1 & nrow(GCend.select.1) == 0){
          primer.select = GCend.select.2
        }else{
          primer.select = GCend.select.1
        }
      }
      
      if(nrow(primer.select) >= 1){
        for(j in 1:nrow(primer.select)){
          if(primer.select$seqStart1[j] >= primer.select$seqEnd1[j]){
            temp = primer.select$seqStart1[j]
            primer.select$seqStart1[j] = primer.select$seqEnd1[j]
            primer.select$seqEnd1[j] = temp
          }
          if(primer.select$seqStart2[j] >= primer.select$seqEnd2[j]){
            temp = primer.select$seqStart2[j]
            primer.select$seqStart2[j] = primer.select$seqEnd2[j]
            primer.select$seqEnd2[j] = temp
          }
        }
      }else{
        warning(paste0("No primers selected for ", mRNA.list[i], "!"))
      }
      
      ## outputting
      fwrite(primer.select, file = paste0(dir.path, "/", "Designed.primers/qRT.primers/", mRNA.list[i], "_", overall$Chr[1], "_", min(c(mRNA.gff$Start,mRNA.gff$End)), "..", max(c(mRNA.gff$Start,mRNA.gff$End)), ".primers.final.csv"), row.names = F, col.names = T, sep = "\t", na = "NA")
      
      ## plotting
      if((plotting == TRUE | plotting == T) & nrow(primer.select) >= 1){
        SIname = strsplit(primer.select$seqName1[1], "_")[[1]][1]
        type = strsplit(primer.select$seqName1[1], "_")[[1]][2]
        chr = str_extract_all(primer.select$seqName1[1], "(Chr[0-9][0-9])")[[1]]
        Start = strsplit(strsplit(primer.select$seqName1[1], "_")[[1]][4], "\\..")[[1]][1]
        End = strsplit(strsplit(primer.select$seqName1[1], "_")[[1]][4], "\\..")[[1]][2]
        primer.select$order = seq(1:nrow(primer.select))/10
        primer.select$primerPair = paste0("Pair_", seq(1:nrow(primer.select)), "(", primer.select$Distance, "bp)")
        
        p = ggplot(primer.select, aes(x = seqStart1, y = 0.1*nrow(primer.select))) +
          labs(title = paste0(SIname, " ", type, " ", chr, ":", Start, "..", End, " qRT-PCR primers distribution")) +
          xlab(paste0(chr, ":", min(c(mRNA.gff$Start,mRNA.gff$End)), "..", max(c(mRNA.gff$Start,mRNA.gff$End)))) +
          theme(axis.ticks.y.left = element_blank(),
                axis.ticks.y = element_blank(),
                axis.line.y = element_blank(),
                axis.line.x.top = element_blank(),
                panel.grid = element_blank(),
                axis.text.y = element_blank(),
                plot.background = element_blank(),
                panel.background = element_blank(),
                axis.title.y = element_blank(),
                axis.line = element_line(colour = "black",size = 0.5))+
          xlim(c(min(c(mRNA.gff$Start,mRNA.gff$End)), max(c(mRNA.gff$Start,mRNA.gff$End)))) + ylim(c(-0.1, 0.1*nrow(primer.select) + 0.1)) +
          geom_segment(data = mRNA.gff, 
                       mapping = aes(x = Start, xend = End, y = -0.1, yend = -0.1, color = Type), 
                       #arrow = arrow(length = unit(0.1,"cm")),
                       size = 4) + 
          geom_segment(data = primer.select,
                       mapping = aes(x = seqEnd1, xend = seqStart2, y = order, yend = order),
                       size = 0.1, color = lcolor) +
          geom_segment(data = primer.select,
                       mapping = aes(x = seqStart1, xend = seqEnd1, y = order, yend = order),
                       arrow = arrow(length = unit(ifelse(nrow(primer.select) <= 2, 0.2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 0.5/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 5/nrow(primer.select), ifelse(nrow(primer.select) > 100, 10/nrow(primer.select), 10/nrow(primer.select))))),"cm")),
                       size = ifelse(nrow(primer.select) <= 2, 2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 3/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 100/nrow(primer.select), ifelse(nrow(primer.select) > 100, 120/nrow(primer.select), 200/nrow(primer.select))))), color = Fcolor) + 
          geom_segment(data = primer.select,
                       mapping = aes(x = seqEnd2, xend = seqStart2, y = order, yend = order),
                       arrow = arrow(length = unit(ifelse(nrow(primer.select) <= 2, 0.2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 0.5/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 5/nrow(primer.select), ifelse(nrow(primer.select) > 100, 10/nrow(primer.select), 10/nrow(primer.select))))),"cm")),
                       size = ifelse(nrow(primer.select) <= 2, 2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 3/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 100/nrow(primer.select), ifelse(nrow(primer.select) > 100, 120/nrow(primer.select), 200/nrow(primer.select))))), color = Rcolor) +
          geom_text(data = primer.select, mapping = aes(x = seqEnd2, y = order, label = primerPair),
                    check_overlap = TRUE, 
                    nudge_x = ifelse(nrow(primer.select) <= 2, 80, ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 75, ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 70, ifelse(nrow(primer.select) > 100, 65, 60)))), 
                    size = ifelse(nrow(primer.select) <= 2, 2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 10/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 50/nrow(primer.select), ifelse(nrow(primer.select) > 100, 80/nrow(primer.select), 100/nrow(primer.select))))))
        p = p + theme(plot.margin=unit(rep(2,4),'lines'))
        pdf(paste0(dir.path, "/", "Designed.primers/qRT.primers/", mRNA.list[i], "_", overall$Chr[1], "_", min(c(mRNA.gff$Start,mRNA.gff$End)), "..", max(c(mRNA.gff$Start,mRNA.gff$End)), ".primers.final.plot.pdf"), width = 10, height = ifelse(nrow(primer.select) <= 2, 3, ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 5, ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 10, ifelse(nrow(primer.select) > 100, 15, 20)))))
        print(p)
        dev.off()
      }
    }
    
    ###### if there is no primer identified across different exons, alternative primers would be selected.
    if((nrow(overlap.select) == 0 & nrow(overall.temp4) >= 1) | (nrow(primer.select) == 0 & nrow(overlap.select) >=1 & nrow(overall.temp4) >= 1)){
      length.select = data.table(matrix(nrow = 0, ncol = 11))
      names(length.select) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
      for(j in 1:(nrow(overall.temp4)-1)){
        for(k in (j+1):nrow(overall.temp4)){
          distance = overall.temp4$From[k] - overall.temp4$To[j]
          if(distance >= lengthScope[1] & distance <= lengthScope[2]){
            temp1 = data.table(matrix(nrow = 1, ncol = 11))
            names(temp1) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
            temp1$seqName1[1] = overall.temp4$Name[j]
            temp1$seq1[1] = overall.temp4$Seq[j]
            temp1$seqStart1[1] = overall.temp4$From[j]
            temp1$seqEnd1[1] = overall.temp4$To[j]
            temp1$primerStrand1[1] = overall.temp4$primerStrand[j]
            temp1$seqName2[1] = overall.temp4$Name[k]
            temp1$seq2[1] = overall.temp4$Seq[k]
            temp1$seqStart2[1] = overall.temp4$From[k]
            temp1$seqEnd2[1] = overall.temp4$To[k]
            temp1$primerStrand2[1] = overall.temp4$primerStrand[k]
            temp1$Distance[1] = distance
            length.select = rbind(length.select, temp1)
          }
        }
      }
      length.select = length.select[primerStrand1 != primerStrand2]
      if(nrow(length.select) == 0){
        warning(paste0("The lengthScope between ", lengthScope[1], " and ", lengthScope[2], " for ", mRNA.list[i], " is too stringent, please try other values for this parameter."))
        GCend.select = length.select
      }else{
        GCend.select = length.select
      }
      
      ## primer length filtration
      if(nrow(GCend.select) >= 1){
        GCend.select$seq1Length = nchar(GCend.select$seq1)
        GCend.select$seq2Length = nchar(GCend.select$seq2)
        GCend.select = GCend.select[seq1Length >= primerLength[1] & seq1Length <= primerLength[2] & seq2Length >= primerLength[1] & seq2Length <= primerLength[2]]
        if(nrow(GCend.select) == 0){
          warning(paste0("The primerLenth between ", primerLength[1], " and ", primerLength[2], " for ", para.temp[1,2], " is too stringent, please try other values for this parameter."))
        }else{
          GCend.select = GCend.select
        }
        GCend.select = GCend.select[,-c('seq1Length', 'seq2Length')]
      }
      
      ## endMatch
      if(GCend == TRUE & nrow(GCend.select) >= 1){
        GCend.select$seq1endBase = NA
        GCend.select$seq2startBase = NA
        for(j in 1:nrow(GCend.select)){
          GCend.select$seq1endBase[j] = strsplit(GCend.select$seq1[j], "")[[1]][length(strsplit(GCend.select$seq1[j], "")[[1]])]
          GCend.select$seq2startBase[j] = strsplit(GCend.select$seq2[j], "")[[1]][1]
        }
        setkeyv(GCend.select, names(GCend.select))
        GCend.select = GCend.select[(seq1endBase == "G" | seq1endBase == "C") & (seq2startBase == "G" | seq2startBase== "C")]
      }else{
        GCend.select = GCend.select
      }
      
      ## reversing R primers
      if(nrow(GCend.select) >= 1){
        GCend.select$seq2 = as.character(reverseComplement(DNAStringSet(GCend.select$seq2)))
        names(GCend.select) = gsub("seq2", "revc.seq2", names(GCend.select))
        GCend.select = GCend.select[,-c(12,13)]
        fwrite(GCend.select, file = paste0(dir.path, "/", "Designed.primers/qRT.primers/", mRNA.list[i], "_", overall$Chr[1], "_", min(c(mRNA.gff$Start,mRNA.gff$End)), "..", max(c(mRNA.gff$Start,mRNA.gff$End)), ".primers.final.csv"), row.names = F, col.names = T, sep = "\t", na = "NA")
      }
      
      ## plotting
      if((plotting == TRUE | plotting == T) & nrow(GCend.select) >= 1){
        SIname = strsplit(GCend.select$seqName1[1], "_")[[1]][1]
        type = strsplit(GCend.select$seqName1[1], "_")[[1]][2]
        chr = str_extract_all(GCend.select$seqName1[1], "(Chr[0-9][0-9])")[[1]]
        Start = strsplit(strsplit(GCend.select$seqName1[1], "_")[[1]][4], "\\..")[[1]][1]
        End = strsplit(strsplit(GCend.select$seqName1[1], "_")[[1]][4], "\\..")[[1]][2]
        GCend.select$order = seq(1:nrow(GCend.select))/10
        GCend.select$primerPair = paste0("Pair_", seq(1:nrow(GCend.select)), "(", GCend.select$Distance, "bp)")
        
        p = ggplot(primer.select, aes(x = seqStart1, y = 0.1*nrow(primer.select))) +
          labs(title = paste0(SIname, " ", type, " ", chr, ":", Start, "..", End, " qRT-PCR primers distribution")) +
          xlab(paste0(chr, ":", min(c(mRNA.gff$Start,mRNA.gff$End)), "..", max(c(mRNA.gff$Start,mRNA.gff$End)))) +
          theme(axis.ticks.y.left = element_blank(),
                axis.ticks.y = element_blank(),
                axis.line.y = element_blank(),
                axis.line.x.top = element_blank(),
                panel.grid = element_blank(),
                axis.text.y = element_blank(),
                plot.background = element_blank(),
                panel.background = element_blank(),
                axis.title.y = element_blank(),
                axis.line = element_line(colour = "black",size = 0.5))+
          xlim(c(min(c(mRNA.gff$Start,mRNA.gff$End)), max(c(mRNA.gff$Start,mRNA.gff$End)))) + ylim(c(-0.1, 0.1*nrow(primer.select) + 0.1)) +
          geom_segment(data = mRNA.gff, 
                       mapping = aes(x = Start, xend = End, y = -0.1, yend = -0.1, color = Type), 
                       size = 4) + 
          geom_segment(data = primer.select,
                       mapping = aes(x = seqEnd1, xend = seqStart2, y = order, yend = order),
                       size = 0.1, color = lcolor) +
          geom_segment(data = primer.select,
                       mapping = aes(x = seqStart1, xend = seqEnd1, y = order, yend = order),
                       arrow = arrow(length = unit(ifelse(nrow(primer.select) <= 2, 0.2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 0.5/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 5/nrow(primer.select), ifelse(nrow(primer.select) > 100, 10/nrow(primer.select), 10/nrow(primer.select))))),"cm")),
                       size = ifelse(nrow(primer.select) <= 2, 2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 3/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 100/nrow(primer.select), ifelse(nrow(primer.select) > 100, 120/nrow(primer.select), 200/nrow(primer.select))))), color = Fcolor) + 
          geom_segment(data = primer.select,
                       mapping = aes(x = seqEnd2, xend = seqStart2, y = order, yend = order),
                       arrow = arrow(length = unit(ifelse(nrow(primer.select) <= 2, 0.2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 0.5/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 5/nrow(primer.select), ifelse(nrow(primer.select) > 100, 10/nrow(primer.select), 10/nrow(primer.select))))),"cm")),
                       size = ifelse(nrow(primer.select) <= 2, 2/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 3/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 100/nrow(primer.select), ifelse(nrow(primer.select) > 100, 120/nrow(primer.select), 200/nrow(primer.select))))), color = Rcolor) +
          geom_text(data = primer.select, mapping = aes(x = seqEnd2, y = order, label = primerPair),
                    check_overlap = TRUE, 
                    nudge_x = ifelse(nrow(primer.select) <= 2, 80, ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 75, ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 70, ifelse(nrow(primer.select) > 100, 65, 60)))), 
                    size = ifelse(nrow(primer.select) <= 2, 10/nrow(primer.select), ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 50/nrow(primer.select), ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 100/nrow(primer.select), ifelse(nrow(primer.select) > 100, 120/nrow(primer.select), 200/nrow(primer.select))))))
        p = p + theme(plot.margin=unit(rep(2,4),'lines'))
        pdf(paste0(dir.path, "/", "Designed.primers/qRT.primers/", mRNA.list[i], "_", overall$Chr[1], "_", min(c(mRNA.gff$Start,mRNA.gff$End)), "..", max(c(mRNA.gff$Start,mRNA.gff$End)), ".primers.final.plot.pdf"), width = 10, height = ifelse(nrow(primer.select) <= 2, 3, ifelse(nrow(primer.select) > 2 & nrow(primer.select) <= 10, 5, ifelse(nrow(primer.select) > 10 & nrow(primer.select) <= 100, 10, ifelse(nrow(primer.select) > 100, 15, 20)))))
        print(p)
        dev.off()
      }
    }
  }
  cat("\n primer.designing.for.qRT.PCT is DONE!")
}




#' This is some description of this function.
#' @title to design primers for cloning of certain sequence either genes or fragments
#'
#' @description By using this package, you could use function of primer.designing.for.cloning to design primers for cloning of certain sequence either genes or fragments
#'
#' @details see above
#' 
#' @param seqType: string to indicate type of sequence, which could one of 'Gene', "fragment'.
#' @param seqEvaluation: seqEvaluation folder.
#' @param plotting: logical value indicates whether to plot primers or not.
#' @param TmScope: numeric scope indicates the min and max of primer Tm, default value is 'c(40, 60)'.
#' @param GCScope: numeric scope indicates the min and max of primer GC content (%), default value is 'c(35, 65)'.
#' @param specificityMin: numeric value indicates the minimum standard of sequence specificity (%), default value is 98%.
#' @param countMax: numeric value indicates the maximum standard of counts of this primer mathched to different position on the chromosome, default value is 2.
#' @param endMatch: logical value indicates whether the primer end (3') matched to genome, default value is TRUE
#' @param GCend: logical value indicates whether the primer end (3') should be G:C or not, default value is TRUE
#' @param primerLength: numeric scope indicates the min and max length of primer, default value is 'c(20, 25)'.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param primerStrand: 'F' or 'R', or c('F', 'R')
#' @param Fcolor: color value for forward primers, default is "#B2182B".
#' @param Rcolor: color value for reverse primers, default is "#2166AC".
#' @param lcolor: color value for line connecting forward and reverse primer pairs, default is 'black'.
#' @param leftRegion: the position scope for left primer.
#' @param rightRegion: the position scope for right primer.
#' @return files and folder
#' @export primer.designing.for.cloning
#' @examples primer.designing.for.cloning(seqEvaluation = "./Sequence.evaluation/Genes/Glyma.20G148100.1/", seqType = "Gene", gffFile = "./Wm82.a2.v1.gene.gff")
#' 
#' 

#primer.designing.for.cloning(seqEvaluation = "./Sequence.evaluation/Genes/Glyma.01G010200.1/", seqType = "Gene", gffFile = "./Wm82.a2.v1.gene.gff")

primer.designing.for.cloning = function(seqEvaluation = NULL, gffFile = NULL, plotting = NULL, seqType = NULL, TmScope = NULL, GCScope = NULL, specificityMin = NULL, countMax = NULL, endMatch = NULL, GCend = NULL, primerLength = NULL, TmMethod = NULL, primerStrand = NULL, Fcolor = NULL, Rcolor = NULL, lcolor = NULL, leftRegion = NULL, rightRegion = NULL, ...) {
  
  library(stringr)
  library(seqinr)
  library(Biostrings)
  library(tidyr)
  library(xlsx)
  library(WriteXLS)
  library(data.table)
  library(ggplot2)
  
  dir.path = getwd()
  
  if(!dir.exists(paste0(dir.path, "/", "Designed.primers"))){
    dir.create(paste0(dir.path, "/", "Designed.primers"))
  }
  if(!dir.exists(paste0(dir.path, "/", "Designed.primers/", "Cloning.primers"))){
    dir.create(paste0(dir.path, "/", "Designed.primers/", "Cloning.primers"))
  }
  
  
  if(is.null(seqEvaluation)) stop("'seqEvaluation' is required!")
  if(is.null(seqType)) stop("'seqType' is required!")
  if(is.null(plotting)) plotting = TRUE
  if(is.null(TmScope)) TmScope = c(40, 60)
  if(is.null(GCScope)) GCScope = c(35, 65)
  if(is.null(countMax)) countMax = 2
  if(is.null(specificityMin)) specificityMin = 98
  if(is.null(endMatch)) endMatch = TRUE
  if(is.null(GCend)) GCend = TRUE
  if(is.null(primerLength)) primerLength = c(20, 25)
  if(is.null(TmMethod)) TmMethod = "both"
  if(is.null(primerStrand)) primerStrand = c('F', 'R')
  if(is.null(plotting)) plotting = TRUE
  if(is.null(Fcolor)) Fcolor = "#B2182B"
  if(is.null(Rcolor)) Rcolor = "#2166AC"
  if(is.null(lcolor)) lcolor = "black"
  
  
  
  if(!dir.exists(seqEvaluation)){
    stop("'seqEvaluation' should be a folder contains 'Blast.output', 'Splitted.seq', etc., please perform seq.evaluation() analysis before primer designing!")
  }
  
  ## file list path classification
  file.list = list.files(paste0(dir.path, "/", seqEvaluation), recursive = TRUE)
  dir = paste0(dir.path, "/", seqEvaluation, file.list)
  dir = dir[-grep(".pdf", dir)]
  seqEval.dir = dir[grep("sequence.evaluation.csv", dir)]
  cloning.dir = seqEval.dir[grep("Cloning|clone|cloning", seqEval.dir)]
  fileName = c()
  # i = 1
  for(i in 1:length(cloning.dir)){
    temp = strsplit(cloning.dir[i], "/")[[1]][length(strsplit(cloning.dir[i], "/")[[1]])]
    temp = strsplit(temp, "_")[[1]][1:2]
    temp = paste0(temp[1], "_", temp[2])
    fileName = c(fileName, temp)
  }
  fileName = unique(fileName)
  
  ## gff file read in
  if(seqType == "Gene" | seqType == "gene" | seqType == "GENE"){
    if(is.null(gffFile)) stop("'gffFile' is required for 'GENE'!")
    gff = fread(gffFile, header = T, fill = T, stringsAsFactors = F, sep = "\t")
    if(ncol(gff) == 1){
      gff = fread(gffFile, header = T, fill = T, stringsAsFactors = F, sep = ",")
      if(ncol(gff) == 1){
        gff = fread(gffFile, header = T, fill = T, stringsAsFactors = F, sep = " ")
      }
    }
  }
  
  # file merging function
  data.merging = function(fileList = NULL, header = NULL, skipRow = NULL, ...){
    library(data.table)
    if(is.null(fileList)) stop("'fileList' in 'data.merging' is required!")
    if(is.null(header)) header = T
    if(is.null(skipRow)) skipRow = 0
    data = fread(fileList[1], header = header, stringsAsFactors = F, sep = "\t", skip = skipRow, fill = T)
    if(ncol(data) == 1){
      data = fread(fileList[1], header = header, stringsAsFactors = F, sep = ",", skip = skipRow, fill = T)
      if(ncol(data) == 1){
        data = fread(fileList[1], header = header, stringsAsFactors = F, sep = " ", skip = skipRow, fill = T)
      }
    }
    for(i in 2:length(fileList)){
      temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = "\t", skip = skipRow, fill = T)
      if(ncol(temp) == 1){
        temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = ",", skip = skipRow, fill = T)
        if(ncol(temp) == 1){
          temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = " ", skip = skipRow, fill = T)
        }
      }
      data = rbind(data, temp)
    }
    return(data)
  }
  # i = 1; j = 3
  for(i in 1:length(fileName)){
    dir.1 = cloning.dir[grep(fileName[i], cloning.dir)]
    overall =  data.merging(fileList = dir.1)
    overall = overall[!duplicated(overall),]
    names(overall) = gsub("\\(.?\\)|\\(5'-3'\\)", "", names(overall))
    setkeyv(overall, names(overall))
    overall.NA = overall[is.na(overall$To),]
    overall = overall[!is.na(overall$From),]
    setkeyv(overall, names(overall))
    
    input.name = strsplit(dir.1[1], "/")[[1]][length(strsplit(dir.1[1], "/")[[1]])]
    input.name = strsplit(input.name, "_")[[1]]
    leftFlanking = as.numeric(strsplit(input.name[grep("leftFlanking", input.name)], "\\.")[[1]][2])
    rightFlanking = as.numeric(strsplit(input.name[grep("rightFlanking", input.name)], "\\.")[[1]][2])
    pos.left = as.numeric(strsplit(input.name[grep("\\.\\.", input.name)], "\\.\\.")[[1]][1])
    pos.right = as.numeric(strsplit(input.name[grep("\\.\\.", input.name)], "\\.\\.")[[1]][2])
    if(is.null(leftRegion)) leftRegion = c(pos.left - leftFlanking, pos.left)
    if(is.null(rightRegion)) rightRegion = c(pos.right, pos.right + rightFlanking)
    
    ## primer selection
    ## Tm filtration
    if(TmMethod == "both"){
      overall.temp1 = overall[which((overall$Tm1 >= TmScope[1] & overall$Tm1 <= TmScope[2]) | (overall$Tm2 >= TmScope[2] & overall$Tm2 <= TmScope[2])),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("The TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation."))
        next
      }
    }
    if(TmMethod == 1){
      overall.temp1 = overall[which(overall$Tm1 >= TmScope[1] & overall$Tm1 <= TmScope[2]),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("The TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation."))
        next
      }
    }
    if(TmMethod == 2){
      overall.temp1 = overall[which(overall$Tm2 >= TmScope[2] & overall$Tm2 <= TmScope[2]),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("The TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation."))
        next()
      }
    }
    
    ## GC content filtration
    overall.temp2 = overall.temp1[which(overall.temp1$GC.content >= GCScope[1] & overall.temp1$GC.content <= GCScope[2]),]
    if(nrow(overall.temp2) == 0){
      warning(paste0("The GCScope between ", GCScope[1], " and ", GCScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation."))
      next()
    }
    
    ## count filtration
    if(!is.null(countMax)){
      overall.temp3 = overall.temp2[which(overall.temp2$Counts <= countMax),]
    }else{
      overall.temp3 = overall.temp2
    }
    
    ## sequence specificity
    if(!is.null(specificityMin)){
      overall.temp4 = overall.temp3[which(overall.temp3$Seq.specificity >= specificityMin),]
    }else{
      overall.temp4 = overall.temp3
    }
    
    overall.temp4 = overall.temp4[order(overall.temp4$From),]
    
    ## basic information outputting
    fwrite(overall.temp4, file = paste0(dir.path, "/", "Designed.primers/Cloning.primers/", fileName[i], "_", overall$Chr[1], "_", min(overall$From), "..", max(overall$To),  ".cloning.primers.passed.filtration.csv"), row.names = F, col.names = T, sep = "\t", na = "NA")
    
    ## region selection
    left = overall.temp4[which(overall.temp4$From >= leftRegion[1] & overall.temp4$To <= leftRegion[2]),]
    right = overall.temp4[which(overall.temp4$From >= rightRegion[1] & overall.temp4$To <= rightRegion[2]),]
    
    if(nrow(left) == 0){
      cat(paste0("There is no primer candidates identified in the left region defined for ", fileName[i], "!\n"))
    }
    if(nrow(right) == 0){
      cat(paste0("There is no primer candidates identified in the right region defined for ", fileName[i], "!\n"))
    }
    
    if(nrow(left) >= 1 & nrow(right) >= 1){
      left = left[,c(1:5)];names(left) = c("seqName1", "seq1", "Chr1", "seqStart1", "seqEnd1")
      right = right[,c(1:5)]; names(right) = c("seqName2", "seq2", "Chr2", "seqStart2", "seqEnd2")
      primer.final = cbind(left, right)
      primer.final$Distance = primer.final$seqStart2 - primer.final$seqEnd1
      if(nrow(primer.final) >= 1){
        if(GCend == TRUE){
          primer.final$seq1endBase = NA
          primer.final$seq2startBase = NA
          for(j in 1:nrow(primer.final)){
            primer.final$seq1endBase[j] = strsplit(primer.final$seq1[j], "")[[1]][length(strsplit(primer.final$seq1[j], "")[[1]])]
            primer.final$seq2startBase[j] = strsplit(primer.final$seq2[j], "")[[1]][1]
          }
          setkeyv(primer.final, names(primer.final))
          primer.final = primer.final[(which(primer.final$seq1endBase == "G" | primer.final$seq1endBase == "C") & (primer.final$seq2startBase == "G" | primer.final$seq2startBase== "C")),]
        }else{
          primer.final = primer.final
        }
      }
      
      primer.final$seq2 = as.character(reverseComplement(DNAStringSet(primer.final$seq2)))
      names(primer.final) = gsub("seq2", "revc.seq2", names(primer.final))
      
      if(nrow(primer.final) >= 1){
        if(primer.final$seqStart1[1] >= primer.final$seqEnd1[1]){
          temp = primer.final$seqStart1
          primer.final$seqStart1 = primer.final$seqEnd1
          primer.final$seqEnd1 = temp
        }
        if(primer.final$seqStart2[1] >= primer.final$seqEnd2[1]){
          temp = primer.final$seqStart2
          primer.final$seqStart2 = primer.final$seqEnd2
          primer.final$seqEnd2 = temp
        }
        ## outputting
        fwrite(primer.final, file = paste0(dir.path, "/", "Designed.primers/Cloning.primers/", fileName[i], "_", overall$Chr[1], "_", min(overall$From), "..", max(overall$To), ".Cloning.primers.final.csv"), row.names = F, col.names = T, sep = "\t", na = "NA")
      }
      
      ## plotting
      if(plotting == TRUE | plotting == T & nrow(primer.final) >= 1){
        seqName = strsplit(primer.final$seqName1[1], "_")[[1]][1]
        chr = str_extract_all(primer.final$seqName1[1], "(Chr[0-9][0-9])")[[1]]
        if(seqType == "Gene" | seqType == "gene" | seqType == "GENE"){
          Start = as.numeric(strsplit(strsplit(primer.final$seqName1[1], "_")[[1]][4], "\\..")[[1]][1])
          End = as.numeric(strsplit(strsplit(primer.final$seqName1[1], "_")[[1]][4], "\\..")[[1]][2])
          gff.temp1 = gff[which(gff$Gene.ID == seqName & gff$Type != "mRNA"),]
          gff.temp1 = gff.temp1[,c(6,2,3,4)]
          names(gff.temp1) = c("Fragment.Name", "Chr", "Start", "End")
          gff.temp = data.frame(matrix(nrow = 2, ncol = 4))
          names(gff.temp) = c("Fragment.Name", "Chr", "Start", "End")
          gff.temp$Fragment.Name[1:2] = c("leftFlanking", "rightFlanking")
          gff.temp$Chr[1:2] = chr
          gff.temp$Start = c(Start-leftFlanking-1, End+1)
          gff.temp$End = c(Start-1, End + rightFlanking +1)
          gff.temp = rbind(gff.temp, gff.temp1)
          gff.temp = gff.temp[order(gff.temp$Start),]
        }
        if(seqType == "fragment" | seqType == "Fragment" | seqType == "FRAGMENT"){
          Start = as.numeric(strsplit(strsplit(primer.final$seqName1[1], "_")[[1]][3], "\\..")[[1]][1])
          End = as.numeric(strsplit(strsplit(primer.final$seqName1[1], "_")[[1]][3], "\\..")[[1]][2])
          gff.temp = data.frame(matrix(nrow = 3, ncol = 4))
          names(gff.temp) = c("Fragment.Name", "Chr", "Start", "End")
          gff.temp$Fragment.Name[1:3] = c("leftFlanking", seqName, "rightFlanking")
          gff.temp$Chr[1:3] = chr
          gff.temp$Start = c(Start-leftFlanking-1, Start, End+1)
          gff.temp$End = c(Start-1, End, End + rightFlanking +1)
        }
        primer.final$order = seq(1:nrow(primer.final))/10
        primer.final$primerPair = paste0("Pair_", seq(1:nrow(primer.final)), "(", primer.final$Distance, "bp)")
        
        p = ggplot(primer.final, aes(x = seqStart1, y = 0.1*nrow(primer.final))) +
          labs(title = paste0(seqName, " ", chr, ":", Start, "..", End, " cloning primer candidates distribution")) +
          xlab(paste0(chr, ":", min(overall$From), "..", max(overall$To))) +
          theme(axis.ticks.y.left = element_blank(),
                axis.ticks.y = element_blank(),
                axis.line.y = element_blank(),
                axis.line.x.top = element_blank(),
                panel.grid = element_blank(),
                axis.text.y = element_blank(),
                plot.background = element_blank(),
                panel.background = element_blank(),
                axis.title.y = element_blank(),
                axis.line = element_line(colour = "black",size = 0.5))+
          xlim(c(min(overall$From)-leftFlanking, max(overall$To)+rightFlanking)) + ylim(c(-0.1, 0.1*nrow(primer.final) + 0.1)) +
          geom_segment(data = gff.temp, 
                       mapping = aes(x = Start, xend = End, y = -0.1, yend = -0.1, color = Fragment.Name), 
                       size = 4) + 
          geom_segment(data = primer.final,
                       mapping = aes(x = seqEnd1, xend = seqStart2, y = order, yend = order),
                       size = 0.1, color = lcolor) +
          geom_segment(data = primer.final,
                       mapping = aes(x = seqStart1, xend = seqEnd1, y = order, yend = order),
                       arrow = arrow(length = unit(ifelse(nrow(primer.final) <= 2, 0.2/nrow(primer.final), ifelse(nrow(primer.final) > 2 & nrow(primer.final) <= 10, 0.5/nrow(primer.final), ifelse(nrow(primer.final) > 10 & nrow(primer.final) <= 100, 2/nrow(primer.final), ifelse(nrow(primer.final) > 100, 5/nrow(primer.final), 10/nrow(primer.final))))),"cm")),
                       size = ifelse(nrow(primer.final) <= 2, 2/nrow(primer.final), ifelse(nrow(primer.final) > 2 & nrow(primer.final) <= 10, 3/nrow(primer.final), ifelse(nrow(primer.final) > 10 & nrow(primer.final) <= 50, 10/nrow(primer.final), ifelse(nrow(primer.final) > 50, 20/nrow(primer.final), 200/nrow(primer.final))))), color = Fcolor) + 
          geom_segment(data = primer.final,
                       mapping = aes(x = seqEnd2, xend = seqStart2, y = order, yend = order),
                       arrow = arrow(length = unit(ifelse(nrow(primer.final) <= 2, 0.2/nrow(primer.final), ifelse(nrow(primer.final) > 2 & nrow(primer.final) <= 10, 0.5/nrow(primer.final), ifelse(nrow(primer.final) > 10 & nrow(primer.final) <= 100, 2/nrow(primer.final), ifelse(nrow(primer.final) > 100, 5/nrow(primer.final), 10/nrow(primer.final))))),"cm")),
                       size = ifelse(nrow(primer.final) <= 2, 2/nrow(primer.final), ifelse(nrow(primer.final) > 2 & nrow(primer.final) <= 10, 3/nrow(primer.final), ifelse(nrow(primer.final) > 10 & nrow(primer.final) <= 50, 10/nrow(primer.final), ifelse(nrow(primer.final) > 50, 20/nrow(primer.final), 200/nrow(primer.final))))), color = Rcolor) +
          geom_text(data = primer.final, mapping = aes(x = seqEnd2, y = order, label = primerPair),
                    check_overlap = TRUE, 
                    nudge_x = ifelse(nrow(primer.final) <= 2, 120, ifelse(nrow(primer.final) > 2 & nrow(primer.final) <= 10, 75, ifelse(nrow(primer.final) > 10 & nrow(primer.final) <= 100, 70, ifelse(nrow(primer.final) > 100, 65, 60)))), 
                    size = ifelse(nrow(primer.final) <= 2, 2/nrow(primer.final), ifelse(nrow(primer.final) > 2 & nrow(primer.final) <= 10, 10/nrow(primer.final), ifelse(nrow(primer.final) > 10 & nrow(primer.final) <= 100, 50/nrow(primer.final), ifelse(nrow(primer.final) > 100, 80/nrow(primer.final), 100/nrow(primer.final))))))
        p = p + theme(plot.margin=unit(rep(2,4),'lines'))
        pdf(paste0(dir.path, "/", "Designed.primers/Cloning.primers/", fileName[i], "_", overall$Chr[1], "_", min(overall$From), "..", max(overall$To), ".cloning.primers.final.plot.pdf"), width = 10, height = ifelse(nrow(primer.final) <= 2, 3, ifelse(nrow(primer.final) > 2 & nrow(primer.final) <= 10, 5, ifelse(nrow(primer.final) > 10 & nrow(primer.final) <= 100, 10, ifelse(nrow(primer.final) > 100, 15, 20)))))
        print(p)
        dev.off()
      }
    }
    if(plotting == TRUE & nrow(overall.temp4) != 0){
      seqName = strsplit(overall.temp4$Name[1], "_")[[1]][1]
      chr = str_extract_all(overall.temp4$Name[1], "(Chr[0-9][0-9])")[[1]]
      if(seqType == "Gene" | seqType == "gene" | seqType == "GENE"){
        Start = as.numeric(strsplit(strsplit(overall.temp4$Name[1], "_")[[1]][4], "\\..")[[1]][1])
        End = as.numeric(strsplit(strsplit(overall.temp4$Name[1], "_")[[1]][4], "\\..")[[1]][2])
        gff.temp1 = gff[which(gff$Gene.ID == seqName & gff$Type != "mRNA"),]
        gff.temp1 = gff.temp1[,c(6,2,3,4)]
        names(gff.temp1) = c("Fragment.Name", "Chr", "Start", "End")
        gff.temp = data.frame(matrix(nrow = 2, ncol = 4))
        names(gff.temp) = c("Fragment.Name", "Chr", "Start", "End")
        gff.temp$Fragment.Name[1:2] = c("leftFlanking", "rightFlanking")
        gff.temp$Chr[1:2] = chr
        gff.temp$Start = c(Start-leftFlanking-1, End+1)
        gff.temp$End = c(Start-1, End + rightFlanking +1)
        gff.temp = rbind(gff.temp, gff.temp1)
        gff.temp = gff.temp[order(gff.temp$Start),]
      }
      if(seqType == "fragment" | seqType == "Fragment" | seqType == "FRAGMENT"){
        Start = as.numeric(strsplit(strsplit(overall.temp4$Name[1], "_")[[1]][3], "\\..")[[1]][1])
        End = as.numeric(strsplit(strsplit(overall.temp4$Name[1], "_")[[1]][3], "\\..")[[1]][2])
        gff.temp = data.frame(matrix(nrow = 3, ncol = 4))
        names(gff.temp) = c("Fragment.Name", "Chr", "Start", "End")
        gff.temp$Fragment.Name[1:3] = c("leftFlanking", seqName, "rightFlanking")
        gff.temp$Chr[1:3] = chr
        gff.temp$Start = c(Start-leftFlanking-1, Start, End+1)
        gff.temp$End = c(Start-1, End, End + rightFlanking +1)
      }
      overall.temp4$order = seq(1:nrow(overall.temp4))/10
      #overall.temp4$primerPair = paste0("Pair_", seq(1:nrow(overall.temp4)), "(", overall.temp4$Distance, "bp)")
      
      p = ggplot(overall.temp4, aes(x = seqStart1, y = 0.1*nrow(overall.temp4))) +
        labs(title = paste0(seqName, " ", chr, ":", Start, "..", End, " potential primers distribution")) +
        xlab(paste0(chr, ":", min(overall$From), "..", max(overall$To))) +
        theme(axis.ticks.y.left = element_blank(),
              axis.ticks.y = element_blank(),
              axis.line.y = element_blank(),
              axis.line.x.top = element_blank(),
              panel.grid = element_blank(),
              axis.text.y = element_blank(),
              plot.background = element_blank(),
              panel.background = element_blank(),
              axis.title.y = element_blank(),
              axis.line = element_line(colour = "black",size = 0.5))+
        xlim(c(min(overall$From)-leftFlanking, max(overall$To)+rightFlanking)) + ylim(c(-0.1, 0.1*nrow(overall.temp4) + 0.1)) +
        geom_segment(data = gff.temp, 
                     mapping = aes(x = Start, xend = End, y = -0.1, yend = -0.1, color = Fragment.Name), 
                     size = 4) + 
        geom_segment(data = overall.temp4,
                     mapping = aes(x = From, xend = To, y = order, yend = order),
                     size = 0.2, color = Fcolor)
      
      p = p + theme(plot.margin=unit(rep(2,4),'lines'))
      pdf(paste0(dir.path, "/", "Designed.primers/Cloning.primers/", fileName[i], "_", overall$Chr[1], "_", min(overall$From), "..", max(overall$To), ".all.primers.distribution.plot.pdf"), width = 10, height = ifelse(nrow(overall.temp4) <= 2, 3, ifelse(nrow(overall.temp4) > 2 & nrow(overall.temp4) <= 10, 5, ifelse(nrow(overall.temp4) > 10 & nrow(overall.temp4) <= 100, 10, ifelse(nrow(overall.temp4) > 100, 15, 20)))))
      print(p)
      dev.off()
    }
  }
  cat("\nPrimer.designing.for.cloning is Done!")  
}






#' This is some description of this function.
#' @title to develop molecular markers for SNP and Indel from flanking region.
#'
#' @description By using this package, you could use function of primer.designing.for.SNP.and.Indel.markers to develop molecular markers for SNP and Indel from flanking region.
#'
#' @details see above

#' @param seqType: string to indicate type of sequence, which could one of 'Indel', "SNP'.
#' @param seqEvaluation: seqEvaluation folder.
#' @param plotting: logical value indicates whether to plot primers or not.
#' @param TmScope: numeric scope indicates the min and max of primer Tm, default value is 'c(40, 60)'.
#' @param GCScope: numeric scope indicates the min and max of primer GC content (%), default value is 'c(35, 65)'.
#' @param specificityMin: numeric value indicates the minimum standard of sequence specificity (%), default value is 98%.
#' @param countMax: numeric value indicates the maximum standard of counts of this primer mathched to different position on the chromosome, default value is 2.
#' @param endMatch: logical value indicates whether the primer end (3') matched to genome, default value is TRUE
#' @param GCend: logical value indicates whether the primer end (3') should be G:C or not, default value is TRUE
#' @param lengthScope: numeric scope indicates the expected min and max amplicon length of primer pairs, default value is 'c(70, 150)'.
#' @param primerLength: numeric scope indicates the min and max length of primer, default value is 'c(20, 25)'.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param primerStrand: 'F' or 'R', or c('F', 'R')
#' @param Fcolor: color value for forward primers, default is "#B2182B".
#' @param Rcolor: color value for reverse primers, default is "#2166AC".
#' @param lcolor: color value for line connecting forward and reverse primer pairs, default is 'black'.
#' @param rectFill: color value for rect shade indicating the position of SNP or Indel, default is '#FF3300'.
#' @return files and folder
#' @export primer.designing.for.SNP.and.Indel.markers
#' @examples primer.designing.for.SNP.and.Indel.markers(seqEvaluation = "./Sequence.evaluation/")
#' 
#' 

#plotting = NULL; TmScope = NULL; GCScope = NULL; specificityMin = NULL; countMax = NULL; endMatch = NULL; GCend = NULL; lengthScope = NULL; primerLength = NULL; TmMethod = NULL; primerStrand = NULL; Fcolor = NULL; Rcolor = NULL; lcolor = NULL; rectFill = NULL; seqType = NULL


#primer.designing.for.SNP.and.Indel.markers(seqEvaluation = "./Sequence.evaluation/Indel/Indel1/", seqType = "Indel")

primer.designing.for.SNP.and.Indel.markers = function(seqEvaluation = NULL, seqType = NULL, plotting = NULL, TmScope = NULL, GCScope = NULL, specificityMin = NULL, countMax = NULL, endMatch = NULL, GCend = NULL, lengthScope = NULL, primerLength = NULL, TmMethod = NULL, primerStrand = NULL, Fcolor = NULL, Rcolor = NULL, lcolor = NULL, rectFill = NULL, ...){
  library(stringr)
  library(seqinr)
  library(Biostrings)
  library(tidyr)
  library(xlsx)
  library(WriteXLS)
  library(data.table)
  library(ggplot2)
  
  dir.path = getwd()
  
  if(!dir.exists(paste0(dir.path, "/", "Designed.primers"))){
    dir.create(paste0(dir.path, "/", "Designed.primers"))
  }
  if(!dir.exists(paste0(dir.path, "/", "Designed.primers/", "SNP.and.Indel.primers"))){
    dir.create(paste0(dir.path, "/", "Designed.primers/", "SNP.and.Indel.primers"))
  }
  
  if(is.null(seqEvaluation)) stop("'seqEvaluation' is required!")
  if(is.null(TmScope)) TmScope = c(40, 60)
  if(is.null(GCScope)) GCScope = c(35, 65)
  if(is.null(countMax)) countMax = 2
  if(is.null(specificityMin)) specificityMin = 98
  if(is.null(endMatch)) endMatch = TRUE
  if(is.null(GCend)) GCend = TRUE
  if(is.null(lengthScope)) lengthScope = c(70, 150)
  if(is.null(primerLength)) primerLength = c(20, 25)
  if(is.null(TmMethod)) TmMethod = "both"
  if(is.null(primerStrand)) primerStrand = c('F', 'R')
  if(is.null(plotting)) plotting = TRUE
  if(is.null(Fcolor)) Fcolor = "#B2182B"
  if(is.null(Rcolor)) Rcolor = "#2166AC"
  if(is.null(lcolor)) lcolor = "black"
  if(is.null(rectFill)) rectFill = '#FF3300'
  
  if(!dir.exists(seqEvaluation)){
    stop("'seqEvaluation' should be a folder contains 'Blast.output', 'Splitted.seq', 'window.size.by.*' etc., please perform seq.evaluation() analysis before primer designing!")
  }
  
  # file merging function
  data.merging = function(fileList = NULL, header = NULL, skipRow = NULL, ...){
    library(data.table)
    if(is.null(fileList)) stop("'fileList' in 'data.merging' is required!")
    if(is.null(header)) header = T
    if(is.null(skipRow)) skipRow = 0
    data = fread(fileList[1], header = header, stringsAsFactors = F, sep = "\t", skip = skipRow, fill = T)
    if(ncol(data) == 1){
      data = fread(fileList[1], header = header, stringsAsFactors = F, sep = ",", skip = skipRow, fill = T)
      if(ncol(data) == 1){
        data = fread(fileList[1], header = header, stringsAsFactors = F, sep = " ", skip = skipRow, fill = T)
      }
    }
    for(i in 2:length(fileList)){
      temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = "\t", skip = skipRow, fill = T)
      if(ncol(temp) == 1){
        temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = ",", skip = skipRow, fill = T)
        if(ncol(temp) == 1){
          temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = " ", skip = skipRow, fill = T)
        }
      }
      data = rbind(data, temp)
    }
    return(data)
  }
  
  ## file list path classification
  file.list = list.files(paste0(dir.path, "/", seqEvaluation), recursive = TRUE)
  dir = paste0(dir.path, "/", seqEvaluation, file.list)
  dir = dir[-grep(".pdf", dir)]
  dir = dir[-grep("blast_output|split.seq", dir)]
  seqEval.dir = dir[grep("sequence.evaluation.csv", dir)]
  SNP.dir = seqEval.dir[grep("SNP", seqEval.dir)]
  Indel.dir = seqEval.dir[grep("Indel", seqEval.dir)]
  SI.dir = c(SNP.dir, Indel.dir)
  
  
  # i = 1
  if(seqType == "SNP" | seqType == "snp"){
    SNP.dir.name = c()
    for(i in 1:length(SNP.dir)){
      temp = strsplit(strsplit(SNP.dir[i], "/")[[1]][length(strsplit(SNP.dir[i], "/")[[1]])], "_")[[1]]
      SNP.dir.name = c(SNP.dir.name, temp[1])
    }
    loci = unique(SNP.dir.name)
  }
  if(seqType == "Indel" | seqType == "indel" | seqType == "indel"){
    Indel.dir.name = c()
    for(i in 1:length(Indel.dir)){
      temp = strsplit(strsplit(Indel.dir[i], "/")[[1]][length(strsplit(Indel.dir[i], "/")[[1]])], "_")[[1]]
      Indel.dir.name = c(Indel.dir.name, temp[1])
    }
    loci = unique(Indel.dir.name)
  }
  # i = 1
  for(i in 1:length(loci)){
    loci.dir = SI.dir[grep(loci[i], SI.dir)]
    left.dir = loci.dir[grep("left", loci.dir)]
    right.dir = loci.dir[grep("right", loci.dir)]
    left = data.merging(fileList = left.dir)
    left$primerStrand = primerStrand[1]
    right = data.merging(fileList = right.dir)
    right$primerStrand = primerStrand[2]
    left.max = max(left$To)
    right.min = min(right$From)
    overall = rbind(left, right)
    names(overall) = gsub("\\(.?\\)|\\(5'-3'\\)", "", names(overall))
    setkeyv(left, names(left))
    setkeyv(right, names(right))
    setkeyv(overall, names(overall))
    
    ## primer selection
    ## Tm filtration
    if(TmMethod == "both"){
      overall.temp1 = overall[which((overall$Tm1 >= TmScope[1] & overall$Tm1 <= TmScope[2]) | (overall$Tm2 >= TmScope[2] & overall$Tm2 <= TmScope[2])),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("The TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation."))
        next
      }
    }
    if(TmMethod == 1){
      overall.temp1 = overall[which(overall$Tm1 >= TmScope[1] & overall$Tm1 <= TmScope[2]),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("The TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation."))
        next
      }
    }
    if(TmMethod == 2){
      overall.temp1 = overall[which(overall$Tm2 >= TmScope[2] & overall$Tm2 <= TmScope[2]),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("The TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation."))
        next()
      }
    }
    
    ## GC content filtration
    overall.temp2 = overall.temp1[which(overall.temp1$GC.content >= GCScope[1] & overall.temp1$GC.content <= GCScope[2]),]
    if(nrow(overall.temp2) == 0){
      warning(paste0("The GCScope between ", GCScope[1], " and ", GCScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation."))
      next()
    }
    
    ## count filtration
    if(!is.null(countMax)){
      overall.temp3 = overall.temp2[which(overall.temp2$Counts <= countMax),]
    }else{
      overall.temp3 = overall.temp2
    }
    
    ## sequence specificity
    if(!is.null(specificityMin)){
      overall.temp4 = overall.temp3[which(overall.temp3$Seq.specificity >= specificityMin),]
    }else{
      overall.temp4 = overall.temp3
    }
    
    overall.temp4 = overall.temp4[order(overall.temp4$From),]
    type = str_extract_all(left.dir[1], "(SNP|Indel|snp|indel|INDEL)")[[1]][1]
    
    ## basic information outputting
    fwrite(overall.temp4, file = paste0(dir.path, "/", "Designed.primers/SNP.and.Indel.primers/", loci[i], "_", type, "_", overall$Chr[1], "_", min(overall$From), "..", max(overall$To),  ".primers.passed.filtration.csv"), row.names = F, col.names = T, sep = "\t", na = "NA")
    
    ## length selection
    length.select = data.table(matrix(nrow = 0, ncol = 11))
    names(length.select) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
    for(j in 1:(nrow(overall.temp4)-1)){
      for(k in (j+1):nrow(overall.temp4)){
        distance = overall.temp4$From[k] - overall.temp4$To[j]
        if(distance >= lengthScope[1] & distance <= lengthScope[2]){
          temp1 = data.table(matrix(nrow = 1, ncol = 11))
          names(temp1) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
          temp1$seqName1[1] = overall.temp4$Name[j]
          temp1$seq1[1] = overall.temp4$Seq[j]
          temp1$seqStart1[1] = overall.temp4$From[j]
          temp1$seqEnd1[1] = overall.temp4$To[j]
          temp1$primerStrand1[1] = overall.temp4$primerStrand[j]
          temp1$seqName2[1] = overall.temp4$Name[k]
          temp1$seq2[1] = overall.temp4$Seq[k]
          temp1$seqStart2[1] = overall.temp4$From[k]
          temp1$seqEnd2[1] = overall.temp4$To[k]
          temp1$primerStrand2[1] = overall.temp4$primerStrand[k]
          temp1$Distance[1] = distance
          length.select = rbind(length.select, temp1)
        }
      }
    }
    
    length.select = length.select[which(length.select$primerStrand1 != length.select$primerStrand2),]
    if(nrow(length.select) == 0){
      warning(paste0("The lengthScope between ", lengthScope[1], " and ", lengthScope[2], " for ", para.temp[1,2], " is too stringent, please try other values for this parameter."))
      next()
    }else{
      GCend.select = length.select
    }
    
    ## primer length filtration
    GCend.select$seq1Length = nchar(GCend.select$seq1)
    GCend.select$seq2Length = nchar(GCend.select$seq2)
    GCend.select = GCend.select[which(GCend.select$seq1Length >= primerLength[1] & GCend.select$seq1Length <= primerLength[2] & GCend.select$seq2Length >= primerLength[1] & GCend.select$seq2Length <= primerLength[2]),]
    if(nrow(GCend.select) == 0){
      warning(paste0("The primerLenth between ", primerLength[1], " and ", primerLength[2], " for ", para.temp[1,2], " is too stringent, please try other values for this parameter."))
      next;
    }else{
      GCend.select = GCend.select
    }
    GCend.select = GCend.select[,-c(grep('seq1Length', names(GCend.select)), grep('seq2Length', names(GCend.select)))]
    
    ## endMatch
    if(GCend == TRUE){
      GCend.select$seq1endBase = NA
      GCend.select$seq2startBase = NA
      for(j in 1:nrow(GCend.select)){
        GCend.select$seq1endBase[j] = strsplit(GCend.select$seq1[j], "")[[1]][length(strsplit(GCend.select$seq1[j], "")[[1]])]
        GCend.select$seq2startBase[j] = strsplit(GCend.select$seq2[j], "")[[1]][1]
      }
      setkeyv(GCend.select, names(GCend.select))
      GCend.select = GCend.select[which((GCend.select$seq1endBase == "G" | GCend.select$seq1endBase == "C") & (GCend.select$seq2startBase == "G" | GCend.select$seq2startBase == "C")),]
    }else{
      GCend.select = GCend.select
    }
    
    ## reversing R primers
    GCend.select$seq2 = as.character(reverseComplement(DNAStringSet(GCend.select$seq2)))
    names(GCend.select) = gsub("seq2", "revc.seq2", names(GCend.select))
    GCend.select = GCend.select[,-c(12,13)]
    
    ## outputting
    fwrite(GCend.select, file = paste0(dir.path, "/", "Designed.primers/SNP.and.Indel.primers/", loci[i], "_", type, "_", overall$Chr[1], "_", min(overall$From), "..", max(overall$To), ".primers.final.csv"), row.names = F, col.names = T, sep = "\t", na = "NA")
    
    ## plotting
    if(plotting == TRUE | plotting == T & nrow(GCend.select) >= 1){
      SIname = strsplit(GCend.select$seqName1[1], "_")[[1]][1]
      type = strsplit(GCend.select$seqName1[1], "_")[[1]][2]
      chr = str_extract_all(GCend.select$seqName1[1], "(Chr[0-9][0-9])")[[1]]
      Start = strsplit(strsplit(GCend.select$seqName1[1], "_")[[1]][4], "\\..")[[1]][1]
      End = strsplit(strsplit(GCend.select$seqName1[1], "_")[[1]][4], "\\..")[[1]][2]
      GCend.select$order = seq(1:nrow(GCend.select))/10
      GCend.select$primerPair = paste0("Pair_", seq(1:nrow(GCend.select)), "(", GCend.select$Distance, "bp)")
      
      p = ggplot(GCend.select, aes(x = seqStart1, y = 0.1*nrow(GCend.select))) +
        labs(title = paste0(SIname, " ", type, " ", chr, ":", Start, "..", End, " primer distrbution")) +
        xlab(paste0(chr, ":", min(overall$From), "..", max(overall$To))) +
        theme(axis.ticks.y.left = element_blank(),
              axis.ticks.y = element_blank(),
              axis.line.y = element_blank(),
              axis.line.x.top = element_blank(),
              panel.grid = element_blank(),
              axis.text.y = element_blank(),
              plot.background = element_blank(),
              panel.background = element_blank(),
              axis.title.y = element_blank(),
              axis.line = element_line(colour = "black",size = 0.5))+
        geom_rect(aes(xmin = left.max, xmax = right.min, ymin = -Inf, ymax = Inf),fill = rectFill, alpha = .2) +
        xlim(c(min(overall$From), max(overall$To))) + ylim(c(0, 0.1*nrow(GCend.select) + 0.1)) +
        geom_segment(data = GCend.select,
                     mapping = aes(x = seqEnd1, xend = seqStart2, y = order, yend = order),
                     size = 0.1, color = lcolor) +
        geom_segment(data = GCend.select,
                     mapping = aes(x = seqStart1, xend = seqEnd1, y = order, yend = order),
                     arrow = arrow(length = unit(ifelse(nrow(GCend.select) <= 2, 0.2/nrow(GCend.select), ifelse(nrow(GCend.select) > 2 & nrow(GCend.select) <= 10, 0.5/nrow(GCend.select), ifelse(nrow(GCend.select) > 10 & nrow(GCend.select) <= 100, 5/nrow(GCend.select), ifelse(nrow(GCend.select) > 100, 10/nrow(GCend.select), 10/nrow(GCend.select))))),"cm")),
                     size = ifelse(nrow(GCend.select) <= 2, 2/nrow(GCend.select), ifelse(nrow(GCend.select) > 2 & nrow(GCend.select) <= 10, 3/nrow(GCend.select), ifelse(nrow(GCend.select) > 10 & nrow(GCend.select) <= 100, 100/nrow(GCend.select), ifelse(nrow(GCend.select) > 100, 120/nrow(GCend.select), 200/nrow(GCend.select))))), color = Fcolor) + 
        geom_segment(data = GCend.select,
                     mapping = aes(x = seqEnd2, xend = seqStart2, y = order, yend = order),
                     arrow = arrow(length = unit(ifelse(nrow(GCend.select) <= 2, 0.2/nrow(GCend.select), ifelse(nrow(GCend.select) > 2 & nrow(GCend.select) <= 10, 0.5/nrow(GCend.select), ifelse(nrow(GCend.select) > 10 & nrow(GCend.select) <= 100, 5/nrow(GCend.select), ifelse(nrow(GCend.select) > 100, 10/nrow(GCend.select), 10/nrow(GCend.select))))),"cm")),
                     size = ifelse(nrow(GCend.select) <= 2, 2/nrow(GCend.select), ifelse(nrow(GCend.select) > 2 & nrow(GCend.select) <= 10, 3/nrow(GCend.select), ifelse(nrow(GCend.select) > 10 & nrow(GCend.select) <= 100, 100/nrow(GCend.select), ifelse(nrow(GCend.select) > 100, 120/nrow(GCend.select), 200/nrow(GCend.select))))), color = Rcolor) +
        geom_text(data = GCend.select, mapping = aes(x = seqEnd2, y = order, label = primerPair),
                  check_overlap = TRUE, 
                  nudge_x = ifelse(nrow(GCend.select) <= 2, 80, ifelse(nrow(GCend.select) > 2 & nrow(GCend.select) <= 10, 75, ifelse(nrow(GCend.select) > 10 & nrow(GCend.select) <= 100, 70, ifelse(nrow(GCend.select) > 100, 65, 60)))), 
                  size = ifelse(nrow(GCend.select) <= 2, 2/nrow(GCend.select), ifelse(nrow(GCend.select) > 2 & nrow(GCend.select) <= 10, 10/nrow(GCend.select), ifelse(nrow(GCend.select) > 10 & nrow(GCend.select) <= 100, 50/nrow(GCend.select), ifelse(nrow(GCend.select) > 100, 80/nrow(GCend.select), 100/nrow(GCend.select))))))
      p = p + theme(plot.margin=unit(rep(2,4),'lines'))
      pdf(paste0(dir.path, "/", "Designed.primers/SNP.and.Indel.primers/", loci[i], "_", type, "_", overall$Chr[1], "_", min(overall$From), "..", max(overall$To), ".primers.final.plot.pdf"), width = 10, height = ifelse(nrow(GCend.select) <= 2, 3, ifelse(nrow(GCend.select) > 2 & nrow(GCend.select) <= 10, 5, ifelse(nrow(GCend.select) > 10 & nrow(GCend.select) <= 100, 10, ifelse(nrow(GCend.select) > 100, 15, 20)))))
      print(p)
      dev.off()
    }
  }
  cat("\n'primer.designing.for.SNP.and.Indel' is Done!")
}





#' This is some description of this function.
#' @title to design primers for gene and fragment cloning.
#'
#' @description By using this package, you could use function of primer.designing.pipeline.for.cloning to design primers for gene and fragment cloning.
#'
#' @details see above


#' @param seqType: string to indicate type of sequence, which could one of 'Gene', "fragment'.
#' @param fragmentName: fragment name
#' @param fragmentFile: fragment file, including at least 'Fragment.ID', 'Chr', 'Start', 'End', 'Strand', 'Length', 'leftFlanking', 'rightFlanking', of which 'Fragment.ID', 'Chr', 'Start' and 'End' are required to be specified. The program would assign default value of '+', 'end - start', 200, and 200 for 'Strand', 'Length', 'leftFlanking', and 'rightFlanking' respectively. This file could be in format of *.csv, .txt, .xlsx, if .xlsx format was used parameters should be put in 'Sheet1' as default.
#' @param geneName: gene name alone or gene list file, which including two columns, namely, Gene.ID and Type. Type indicates the CDS, promoter, mRNA, gene, five_prime_UTR, three_prime_UTR or all (all types)
#' @param type: string to indiate SNP or Indel, varied format is also accepted, e.g. snp, SNP, indel, Indel, and INDEL
#' @param database: folder or file contains genome sequence in fasta format
#' @param lociName: string to specify the name of a SNP or Indel, when input file was missed, 'lociName' is reuquired.
#' @param chr: string or numeric value indicates specific chromosome, when input file was missed, 'chr' is reuquired.
#' @param start: numeric value indicates the start position of Indel, when input file was missed, 'start' is reuquired.
#' @param end: numeric value indicates the end position of Indel, when input file was missed, 'end' is reuquired.
#' @param pos: numeric value indicates the position of SNP, when input file was missed, 'pos' is reuquired.
#' @param leftFlanking: numeric value indicates left flanking region of SNP or Indel, default value is 200bp.
#' @param rightFlanking: numeric value indicates right flanking region of SNP or Indel, default value is 200bp.
#' @param inputFile: parameter setting file in '.csv' or '.xlsx' format. it should contains Type	Name	Chr	Start	End	Strand	Primer_strand	Flanking.left.bp	Flanking.right.bp	Expected.amplicon.length.bp	Aiming	Primer.name	Primer.length.bp	Tm.expected	GC.content	Sequence.specificity.min, details could be found in example input file.
#' @param database: folder contains genome sequence in fasta format
#' @param stepWise: numeric value to indicate stepWise of windows, default value is 3.
#' @param windowSize: numeric value to indicate scope of window size, could be a single number, e.g. 23, or a range, e.g. c(20,25). Default value is c(20, 25)
#' @param blastDir: the path to the local blast.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param specificityMin: numeric value to indicate the min value of sequence specificity to signify on the diagnostic plot.
#' @param nthreads: numeric value to indicate how many threads used in the analysis, default is 2
#' @param Evalue: numeric value to indicate e-value threshold in local-blast, default is 0.1 (1e-1)
#' @param outFormat: numeric value to specify -outfmt parameter in local blast, default is 6.
#' @param GCShow: logical value. whether to show GC content on the diagnostic plot, default is TRUE
#' @param TmShow: logical value.whether to show Tm value on the diagnostic plot, default is TRUE
#' @param specificiyShow: logical value.whether to show sequence specificity value on the diagnostic plot, default is TRUE
#' @param countShow: logical value.whether to show Counts on the diagnostic plot, default is TRUE
#' @param countMax: numeric value to indicates the maximum counts threshold, by which fragment to be displayed with dashed line.
#' @param segmentLinetype: numeric value indicates which line type to be used. It is inherited from basic line types in the R.
#' @param segmentColor: string indicate the color of geom_segment(), which represent fragment sequence on the chromosome in terms of location.
#' @param segmentSize: numeric value indicates line size of geom_segment(), default value is 0.2
#' @param pointShape: numeric value indicates point shape in geom_point(), default value for pointShape1 and pointShape2 are 19 and 24 respectively.
#' @param pointColor: string indicates color of geom_point(), default value for pointColor1 and pointColor2 are 'red' and 'blue' respectively.
#' @param pointSize: numeric value indicates point size in geom_point(), default value for pointSize, pointSize1, and pointSize2 are 0.5, 0.5, and 0.5 respectively.
#' @param hlineType: numeric value indicates line type in geom_hline(), default value is 2.
#' @param hlineColor: string indicates line color in geom_hline(), default value is 'blue'
#' @param hlineSize: numeric value indicates line size, default value is 0.3.
#' @param pdfWidth: numeric value indicates width of pdf file, default value is 16.
#' @param pdfHeight: numeric value indicates height of pdf file, default value is 10.
#' @param seqEvaluation: seqEvaluation folder.
#' @param plotting: logical value indicates whether to plot primers or not.
#' @param TmScope: numeric scope indicates the min and max of primer Tm, default value is 'c(40, 60)'.
#' @param GCScope: numeric scope indicates the min and max of primer GC content (%), default value is 'c(35, 65)'.
#' @param specificityMin: numeric value indicates the minimum standard of sequence specificity (%), default value is 98%.
#' @param countMax: numeric value indicates the maximum standard of counts of this primer mathched to different position on the chromosome, default value is 2.
#' @param endMatch: logical value indicates whether the primer end (3') matched to genome, default value is TRUE
#' @param GCend: logical value indicates whether the primer end (3') should be G:C or not, default value is TRUE
#' @param lengthScope: numeric scope indicates the expected min and max amplicon length of primer pairs, default value is 'c(70, 150)'.
#' @param primerLength: numeric scope indicates the min and max length of primer, default value is 'c(20, 25)'.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param primerStrand: 'F' or 'R', or c('F', 'R')
#' @param Fcolor: color value for forward primers, default is "#B2182B".
#' @param Rcolor: color value for reverse primers, default is "#2166AC".
#' @param lcolor: color value for line connecting forward and reverse primer pairs, default is 'black'.
#' @param leftRegion: the position scope for left primer.
#' @param rightRegion: the position scope for right primer.
#' @return files and folder
#' @export primer.designing.pipeline.for.cloning
#' @examples primer.designing.pipeline.for.cloning(database = "./soybean.genome/", geneName = "Glyma.01G010100", gffFile = "./Wm82.a2.v1.gene.gff", type = "gene", blastDir = "./ncbi-blast-2.12.0+/", For = "Cloning")
#' 
#' 

# primer.designing.pipeline.for.cloning(database = "./soybean.genome/", geneName = "Glyma.01G010200", gffFile = "./Wm82.a2.v1.gene.gff", seqType = "Gene", type = "gene", blastDir = "./ncbi-blast-2.12.0+/", For = "Cloning")

primer.designing.pipeline.for.cloning = function(database = NULL, geneName = NULL, blastDir = NULL, seqType = NULL, gffFile = NULL, type = NULL, promoterLength = NULL, leftFlanking = NULL, rightFlanking = NULL, For = NULL,fragmentFile = NULL, fragmentName = NULL, chr = NULL, start = NULL, end = NULL, strand = NULL, length = NULL, inputFile = NULL,  windowSize = NULL, stepWise = NULL, TmMethod = NULL, specificityMin = NULL, nthreads = NULL, Evalue = NULL, GCShow = NULL, TmShow = NULL, specificiyShow = NULL, countShow = NULL, TmScope = NULL, GCScope = NULL, countMax = NULL, segmentLinetype = NULL, segmentColor = NULL, segmentSize = NULL, pointShape1 = NULL, pointShape2 = NULL, pointColor1 = NULL, pointColor2 = NULL, pointSize = NULL, pointSize1 = NULL, pointSize2 = NULL, hlineType = NULL, hlineColor = NULL, hlineSize = NULL, pdfWidth = NULL, pdfHeight = NULL, outFormat = NULL, seqEvaluation = NULL, plotting = NULL,  endMatch = NULL, GCend = NULL, primerLength = NULL, primerStrand = NULL, Fcolor = NULL, Rcolor = NULL, lcolor = NULL, leftRegion = NULL, rightRegion = NULL, ...){
  
  library(data.table)
  library(xlsx)
  if(is.null(For)) For = "Cloning"
  if(is.null(seqType)) stop("'seqType' is required!")
  if(is.null(type)) stop("'type' is required!")
  
  dir.path = getwd()
  
  ## sequence extraction
  if(!is.null(geneName)){
    gene.seq.extraction(database = database, geneName = geneName, gffFile = gffFile, type = type, promoterLength = promoterLength, leftFlanking = leftFlanking, rightFlanking = rightFlanking, For = For)
  }
  if(!is.null(fragmentFile)){
    fragment.seq.extraction.1(database = database, fragmentFile = fragmentFile, For = For)
  }
  if(!is.null(fragmentName)){
    fragment.seq.extraction.2(database = database, fragmentName = fragmentName, chr = chr, start = start, end = end, strand = strand, length = length, leftFlanking = leftFlanking, rightFlanking = rightFlanking, For = For)
  }
  
  ## sequence evaluation
  if(is.null(inputFile)){
    if(type == "gene" | type == "Gene" | type == "GENE"){
      if(!file.exists(geneName)){
        dirList = list.files("./Sequence.extraction/Gene.sequence.extraction/")
        dirList = paste0("./Sequence.extraction/Gene.sequence.extraction/", dirList)
        dirList = dirList[grep(geneName, dirList)]
        if(length(dirList) >= 1){
          for(i in 1:length(dirList)){
            dirName = strsplit(dirList[i], "/")[[1]][length(strsplit(dirList[i], "/")[[1]])]
            inputFile = paste0(dirList[i], "/")
            if(file.exists(inputFile)){
              seq.evaluation(database = database, inputFile = inputFile, blastDir = blastDir, seqType = seqType, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
              seqEvaluation = paste0("./Sequence.evaluation/Genes/", dirName, "/") 
              if(dir.exists(seqEvaluation)){
                primer.designing.for.cloning(seqEvaluation = seqEvaluation, gffFile = gffFile, seqType = seqType, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend = GCend, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, leftRegion = leftRegion, rightRegion = rightRegion)
              }else{
                warning(paste0(dirName, " does not exist in ./Sequence.evaluation/Genes/"))
                next
              }
            }else{
              warning(paste0(dirName, " does not exist in ./Sequence.extraction/Genes/"))
              next
            }
          }
        }else{
          warning(paste0(geneName, " does not exist in ./Sequence.extraction/Genes/"))
        }
      }
      if(file.exists(geneName)){
        if(length(grep(".csv|.txt", geneName)) == 1){
          geneList = fread(file = geneName, header = T, sep = "\t", stringsAsFactors = F, fill = T)
          if(ncol(geneList) == 1){
            geneList = fread(file = geneName, header = T, sep = ",", stringsAsFactors = F, fill = T)
            if(ncol(geneList) == 1){
              geneList = fread(file = geneName, header = T, sep = " ", stringsAsFactors = F, fill = T)
            }
          }
        }
        if(length(grep(".xlsx|.xls", geneName)) == 1){
          geneList = data.frame(read.xlsx(paste0(dir.path, "/", geneName), header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
        }
        dirList = list.files("./Sequence.extraction/Gene.sequence.extraction/")
        dirList = paste0("./Sequence.extraction/Gene.sequence.extraction/", dirList)
        # i = 1;j = 1
        for(i in 1:nrow(geneList)){
          dir = dirList[grep(geneList$Gene.ID[i], dirList)]
          if(length(dir) >= 1){
            for(j in 1:length(dir)){
              dirName = strsplit(dir[j], "/")[[1]][length(strsplit(dir[j], "/")[[1]])]
              inputFile = paste0(dir[j], "/")
              if(file.exists(inputFile)){
                seq.evaluation(database = database, inputFile = inputFile, blastDir = blastDir, seqType = seqType, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
                seqEvaluation = paste0("./Sequence.evaluation/Genes/", dirName, "/")
                if(dir.exists(seqEvaluation)){
                  primer.designing.for.cloning(seqEvaluation = seqEvaluation, gffFile = gffFile, seqType = seqType, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend = GCend, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, leftRegion = leftRegion, rightRegion = rightRegion)
                }else{
                  warning(paste0(dirName, " does not exist in ./Sequence.evaluation/Genes/"))
                  next
                }
              }else{
                warning(paste0(dirName, " does not exist in ./Sequence.extraction/Genes/"))
                next
              }
            }
          }else{
            warning(paste0(geneList$Gene.ID[i], " does not exist!"))
            next
          }
        }
      }
    }
    if(type == "fragment" | type == "Fragment" | type == "FRAGMENT"){
      if(!is.null(fragmentName)){
        dirList = list.files("./Sequence.extraction/Fragment.sequence.extraction/")
        dirList = paste0("./Sequence.extraction/Fragment.sequence.extraction/", dirList)
        dirList = dirList[grep(fragmentName, dirList)]
        if(length(dirList) >= 1){
          for(i in 1:length(dirList)){
            dirName = strsplit(dirList[i], "/")[[1]][length(strsplit(dirList[i], "/")[[1]])]
            inputFile = paste0(dirList[i], "/")
            if(file.exists(inputFile)){
              seq.evaluation(database = database, inputFile = inputFile, blastDir = blastDir, seqType = seqType, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
              seqEvaluation = paste0("./Sequence.evaluation/Fragment/", dirName, "/")
              if(dir.exists(seqEvaluation)){
                primer.designing.for.cloning(seqEvaluation = seqEvaluation, gffFile = gffFile, seqType = seqType, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend = GCend, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, leftRegion = leftRegion, rightRegion = rightRegion)
              }else{
                warning(paste0(dirName, " does not exist in ./Sequence.evaluation/Fragment/"))
                next
              }
            }else{
              warning(paste0(dirName, " does not exist in ./Sequence.extraction/Fragment/"))
              next
            }
          }
        }
      }
      
      if(!is.null(fragmentFile)){
        if(length(grep(".csv|.txt", fragmentFile)) == 1){
          fragmentList = fread(file = fragmentFile, header = T, sep = "\t", stringsAsFactors = F, fill = T)
          if(ncol(fragmentList) == 1){
            fragmentList = fread(file = fragmentFile, header = T, sep = ",", stringsAsFactors = F, fill = T)
            if(ncol(geneList) == 1){
              fragmentList = fread(file = fragmentFile, header = T, sep = " ", stringsAsFactors = F, fill = T)
            }
          }
        }
        if(length(grep(".xlsx|.xls", fragmentFile)) == 1){
          fragmentList = data.frame(read.xlsx(paste0(dir.path, "/", fragmentFile), header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
        }
        
        dirList = list.files("./Sequence.extraction/Fragment.sequence.extraction/")
        dirList = paste0("./Sequence.extraction/Fragment.sequence.extraction/", dirList)
        for(i in 1:nrow(fragmentList)){
          dir = dirList[grep(fragmentList$Fragment.ID[i], dirList)]
          if(length(dir) >= 1){
            for(j in 1:length(dir)){
              dirName = strsplit(dir[j], "/")[[1]][length(strsplit(dir[j], "/")[[1]])]
              inputFile = paste0(dir[j], "/")
              if(file.exists(inputFile)){
                seq.evaluation(database = database, inputFile = inputFile, blastDir = blastDir, seqType = seqType, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
                seqEvaluation = paste0("./Sequence.evaluation/Fragment/", dirName, "/")
                if(dir.exists(seqEvaluation)){
                  primer.designing.for.cloning(seqEvaluation = seqEvaluation, gffFile = gffFile, seqType = seqType, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend = GCend, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, leftRegion = leftRegion, rightRegion = rightRegion)
                }else{
                  warning(paste0(dirName, " does not exist in ./Sequence.evaluation/Fragment/"))
                  next
                }
              }else{
                warning(paste0(dirName, " does not exist in ./Sequence.extraction/Fragment/"))
                next
              }
            }
          }
        }
      }
    }
  }
  
  cat("\nAll Done!") 
}




#' This is some description of this function.
#' @title to design primers for qRT-PCR.
#'
#' @description By using this package, you could use function of primer.designing.pipeline.for.SNP.and.indel.markers to design primers for qRT-PCR.
#'
#' @details see above
#'
#'#' @param geneName: gene name alone or gene list file, which including two columns, namely, Gene.ID and Type. Type indicates the CDS, promoter, mRNA, gene, five_prime_UTR, three_prime_UTR or all (all types)
#' @param seqEvaluation: seqEvaluation folder.
#' @param gffFile: general feature format of certain genome, it must contain at least Gene.ID, Chr, Start, End, Strand, Type.
#' @param plotting: logical value indicates whether to plot primers or not.
#' @param type: string to indicate whihch type of sequence to be extracted, e.g. mRNA, CDS, gene, five_prime_UTR, and three_prime_UTR. 
#' @param database: folder or file contains genome sequence in fasta format
#' @param geneName: string to specify the name of a SNP or Indel, when input file was missed, 'lociName' is reuquired.
#' @param chr: string or numeric value indicates specific chromosome, when input file was missed, 'chr' is reuquired.
#' @param start: numeric value indicates the start position of Indel, when input file was missed, 'start' is reuquired.
#' @param end: numeric value indicates the end position of Indel, when input file was missed, 'end' is reuquired.
#' @param pos: numeric value indicates the position of SNP, when input file was missed, 'pos' is reuquired.
#' @param leftFlanking: numeric value indicates left flanking region of SNP or Indel, default value is 200bp.
#' @param rightFlanking: numeric value indicates right flanking region of SNP or Indel, default value is 200bp.
#' @param inputFile: parameter setting file in '.csv' or '.xlsx' format. it should contains Type	Name	Chr	Start	End	Strand	Primer_strand	Flanking.left.bp	Flanking.right.bp	Expected.amplicon.length.bp	Aiming	Primer.name	Primer.length.bp	Tm.expected	GC.content	Sequence.specificity.min, details could be found in example input file.
#' @param database: folder contains genome sequence in fasta format
#' @param stepWise: numeric value to indicate stepWise of windows, default value is 3.
#' @param windowSize: numeric value to indicate scope of window size, could be a single number, e.g. 23, or a range, e.g. c(20,25). Default value is c(20, 25)
#' @param blastDir: the path to the local blast.
#' @param promoterLength: numeric value indicate the length of promoter sequence to extract, default is 2000.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param specificityMin: numeric value to indicate the min value of sequence specificity to signify on the diagnostic plot.
#' @param nthreads: numeric value to indicate how many threads used in the analysis, default is 2
#' @param Evalue: numeric value to indicate e-value threshold in local-blast, default is 0.1 (1e-1)
#' @param outFormat: numeric value to specify -outfmt parameter in local blast, default is 6.
#' @param GCShow: logical value. whether to show GC content on the diagnostic plot, default is TRUE
#' @param TmShow: logical value.whether to show Tm value on the diagnostic plot, default is TRUE
#' @param specificiyShow: logical value.whether to show sequence specificity value on the diagnostic plot, default is TRUE
#' @param countShow: logical value.whether to show Counts on the diagnostic plot, default is TRUE
#' @param countMax: numeric value to indicates the maximum counts threshold, by which fragment to be displayed with dashed line.
#' @param segmentLinetype: numeric value indicates which line type to be used. It is inherited from basic line types in the R.
#' @param segmentColor: string indicate the color of geom_segment(), which represent fragment sequence on the chromosome in terms of location.
#' @param segmentSize: numeric value indicates line size of geom_segment(), default value is 0.2
#' @param pointShape: numeric value indicates point shape in geom_point(), default value for pointShape1 and pointShape2 are 19 and 24 respectively.
#' @param pointColor: string indicates color of geom_point(), default value for pointColor1 and pointColor2 are 'red' and 'blue' respectively.
#' @param pointSize: numeric value indicates point size in geom_point(), default value for pointSize, pointSize1, and pointSize2 are 0.5, 0.5, and 0.5 respectively.
#' @param hlineType: numeric value indicates line type in geom_hline(), default value is 2.
#' @param hlineColor: string indicates line color in geom_hline(), default value is 'blue'
#' @param hlineSize: numeric value indicates line size, default value is 0.3.
#' @param pdfWidth: numeric value indicates width of pdf file, default value is 16.
#' @param pdfHeight: numeric value indicates height of pdf file, default value is 10.
#' @param seqEvaluation: seqEvaluation folder.
#' @param plotting: logical value indicates whether to plot primers or not.
#' @param TmScope: numeric scope indicates the min and max of primer Tm, default value is 'c(40, 60)'.
#' @param GCScope: numeric scope indicates the min and max of primer GC content (%), default value is 'c(35, 65)'.
#' @param specificityMin: numeric value indicates the minimum standard of sequence specificity (%), default value is 98%.
#' @param countMax: numeric value indicates the maximum standard of counts of this primer mathched to different position on the chromosome, default value is 2.
#' @param endMatch: logical value indicates whether the primer end (3') matched to genome, default value is TRUE
#' @param GCend: logical value indicates whether the primer end (3') should be G:C or not, default value is TRUE
#' @param lengthScope: numeric scope indicates the expected min and max amplicon length of primer pairs, default value is 'c(70, 150)'.
#' @param primerLength: numeric scope indicates the min and max length of primer, default value is 'c(20, 25)'.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param primerStrand: 'F' or 'R', or c('F', 'R')
#' @param Fcolor: color value for forward primers, default is "#B2182B".
#' @param Rcolor: color value for reverse primers, default is "#2166AC".
#' @param lcolor: color value for line connecting forward and reverse primer pairs, default is 'black'.
#' @param overlapMin: numeric value indicates at least how many base pairs should be acrossing different exons, to eliminate none specific matching to genome DNA. Default is 5bp.
#' @return files and folder
#' @export primer.designing.pipeline.for.qRT.PCR
#' @examples primer.designing.pipeline.for.qRT.PCR(database = "./soybean.genome/", geneName = "Glyma.01G010100", gffFile = "./Wm82.a2.v1.gene.gff", type = "gene", blastDir = "./ncbi-blast-2.12.0+/", For = "Cloning")
#' 
#' 

# promoterLength = NULL; leftFlanking = NULL; rightFlanking = NULL; For = NULL; inputFile = NULL;  windowSize = NULL; stepWise = NULL; TmMethod = NULL; specificityMin = NULL; nthreads = NULL; Evalue = NULL; GCShow = NULL; TmShow = NULL; specificiyShow = NULL; countShow = NULL; TmScope = NULL; GCScope = NULL; countMax = NULL; segmentLinetype = NULL; segmentColor = NULL; segmentSize = NULL; pointShape1 = NULL; pointShape2 = NULL; pointColor1 = NULL; pointColor2 = NULL; pointSize = NULL; pointSize1 = NULL; pointSize2 = NULL; hlineType = NULL; hlineColor = NULL; hlineSize = NULL; pdfWidth = NULL; pdfHeight = NULL; outFormat = NULL; seqEvaluation = NULL; plotting = NULL;  endMatch = NULL; GCend = NULL; primerLength = NULL; primerStrand = NULL; Fcolor = NULL; Rcolor = NULL; lcolor = NULL; leftRegion = NULL; rightRegion = NULL; lengthScope = NULL; overlapMin = NULL

#primer.designing.pipeline.for.qRT.PCR(database = "./soybean.genome/", geneName = "./gene.list.csv", gffFile = "./Wm82.a2.v1.gene.gff", blastDir = "./ncbi-blast-2.12.0+/", For = "qRT-PCR")

primer.designing.pipeline.for.qRT.PCR = function(database = NULL, geneName = NULL, type = NULL, blastDir = NULL, gffFile = NULL, seqType = NULL, promoterLength = NULL, leftFlanking = NULL, rightFlanking = NULL, For = NULL,inputFile = NULL,  windowSize = NULL, stepWise = NULL, TmMethod = NULL, specificityMin = NULL, nthreads = NULL, Evalue = NULL, GCShow = NULL, TmShow = NULL, specificiyShow = NULL, countShow = NULL, TmScope = NULL, GCScope = NULL, countMax = NULL, segmentLinetype = NULL, segmentColor = NULL, segmentSize = NULL, pointShape1 = NULL, pointShape2 = NULL, pointColor1 = NULL, pointColor2 = NULL, pointSize = NULL, pointSize1 = NULL, pointSize2 = NULL, hlineType = NULL, hlineColor = NULL, hlineSize = NULL, pdfWidth = NULL, pdfHeight = NULL, outFormat = NULL, seqEvaluation = NULL, plotting = NULL,  endMatch = NULL, GCend = NULL, primerLength = NULL, primerStrand = NULL, Fcolor = NULL, Rcolor = NULL, lcolor = NULL, leftRegion = NULL, rightRegion = NULL, lengthScope = NULL, overlapMin = NULL, ...){
  
  library(data.table)
  
  if(is.null(For)) For = "qRT-PCR"
  if(is.null(seqType)) seqType = "Gene"
  if(is.null(type)) type = "mRNA"
  
  ## sequence extraction
  if(!is.null(geneName)){
    gene.seq.extraction(database = database, geneName = geneName, gffFile = gffFile, type = type, promoterLength = promoterLength, leftFlanking = leftFlanking, rightFlanking = rightFlanking, For = For)
  }
  
  ## sequence evaluation
  if(is.null(inputFile)){
    if(seqType == "gene" | seqType == "Gene" | seqType == "GENE"){
      if(!file.exists(geneName)){
        dirList = list.files("./Sequence.extraction/Gene.sequence.extraction/")
        dirList = paste0("./Sequence.extraction/Gene.sequence.extraction/", dirList)
        dirList = dirList[grep(geneName, dirList)]
        for(i in 1:length(dirList)){
          dirName = strsplit(dirList[i], "/")[[1]][length(strsplit(dirList[i], "/")[[1]])]
          inputFile = paste0(dirList[i], "/")
          if(dir.exists(inputFile)){
            seq.evaluation(database = database, seqType = seqType, inputFile = inputFile, blastDir = blastDir, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
            seqEvaluation = paste0("./Sequence.evaluation/Genes/", dirName, "/")
            if(file.exists(seqEvaluation)){
              primer.designing.for.qRT.PCR(seqEvaluation = seqEvaluation, gffFile = gffFile, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend = GCend, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, overlapMin = overlapMin, lengthScope = lengthScope)
            }else{
              warning(paste0(dirName, " does not exist in ./Sequence.evaluation/Fragment/"))
              next
            }
          }else{
            warning(paste0(dirName, " does not exist in ./Sequence.extraction/Fragment/"))
            next
          }
        }
      }
      if(file.exists(geneName)){
        if(length(grep(".csv|.txt", geneName)) == 1){
          geneList = fread(file = geneName, header = T, sep = "\t", stringsAsFactors = F, fill = T)
          if(ncol(geneList) == 1){
            geneList = fread(file = geneName, header = T, sep = ",", stringsAsFactors = F, fill = T)
            if(ncol(geneList) == 1){
              geneList = fread(file = geneName, header = T, sep = " ", stringsAsFactors = F, fill = T)
            }
          } 
        }
        if(length(grep(".xlsx", geneName)) == 1){
          geneList = data.frame(read.xlsx(paste0(dir.path, "/", geneName), header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
        }
        dirList = list.files("./Sequence.extraction/Gene.sequence.extraction/")
        dirList = paste0("./Sequence.extraction/Gene.sequence.extraction/", dirList)
        # i = 3; j = 1
        for(i in 1:nrow(geneList)){
          dir = dirList[grep(geneList$Gene.ID[i], dirList)]
          if(length(dir) != 0){
            for(j in 1:length(dir)){
              dirName = strsplit(dir[j], "/")[[1]][length(strsplit(dir[j], "/")[[1]])]
              inputFile = paste0(dir[j], "/")
              if(file.exists(inputFile)){
                seq.evaluation(database = database, seqType = seqType, inputFile = inputFile, blastDir = blastDir, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
                seqEvaluation = paste0("./Sequence.evaluation/Genes/", dirName, "/")
                if(file.exists(seqEvaluation)){
                  primer.designing.for.qRT.PCR(seqEvaluation = seqEvaluation, gffFile = gffFile, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend = GCend, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, overlapMin = overlapMin, lengthScope = lengthScope)
                }else{
                  warning(paste0(dirName, " does not exist in ./Sequence.evaluation/Fragment/"))
                  next
                }
              }else{
                warning(paste0(dirName, " does not exist in ./Sequence.extraction/Fragment/"))
                next
              }
            }
          }else{
            warning(paste0(dirName, " does not exist!"))
            next
          }
        }
      }
    }else{warning("Only gene could be used to design qRT-PCR primers!")}
  }
  cat("\nDone!") 
}





#' This is some description of this function.
#' @title to design primers for SNP- or indel- based marker development.
#'
#' @description By using this package, you could use function of primer.designing.pipeline.for.SNP.and.indel.markers to design primers for SNP- or indel- based marker development.
#'
#' @details see above
#'
#' @param SNPFile: SNP locus file, including at least 'Fragment.ID', 'Chr', 'Start', 'End', 'Strand', 'Length', 'leftFlanking', 'rightFlanking', of which 'Fragment.ID', 'Chr', 'Start' and 'End' are required to be specified. The program would assign default value of '+', 'end - start', 200, and 200 for 'Strand', 'Length', 'leftFlanking', and 'rightFlanking' respectively. This file could be in format of *.csv, .txt, .xlsx, if .xlsx format was used parameters should be put in 'Sheet1' as default.
#' @param IndelFile: 
#' @param type: string to indiate SNP or Indel, varied format is also accepted, e.g. snp, SNP, indel, Indel, and INDEL
#' @param database: folder or file contains genome sequence in fasta format
#' @param lociName: string to specify the name of a SNP or Indel, when input file was missed, 'lociName' is reuquired.
#' @param chr: string or numeric value indicates specific chromosome, when input file was missed, 'chr' is reuquired.
#' @param start: numeric value indicates the start position of Indel, when input file was missed, 'start' is reuquired.
#' @param end: numeric value indicates the end position of Indel, when input file was missed, 'end' is reuquired.
#' @param pos: numeric value indicates the position of SNP, when input file was missed, 'pos' is reuquired.
#' @param leftFlanking: numeric value indicates left flanking region of SNP or Indel, default value is 200bp.
#' @param rightFlanking: numeric value indicates right flanking region of SNP or Indel, default value is 200bp.
#' @param inputFile: parameter setting file in '.csv' or '.xlsx' format. it should contains Type	Name	Chr	Start	End	Strand	Primer_strand	Flanking.left.bp	Flanking.right.bp	Expected.amplicon.length.bp	Aiming	Primer.name	Primer.length.bp	Tm.expected	GC.content	Sequence.specificity.min, details could be found in example input file.
#' @param database: folder contains genome sequence in fasta format
#' @param stepWise: numeric value to indicate stepWise of windows, default value is 3.
#' @param windowSize: numeric value to indicate scope of window size, could be a single number, e.g. 23, or a range, e.g. c(20,25). Default value is c(20, 25)
#' @param blastDir: the path to the local blast.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param specificityMin: numeric value to indicate the min value of sequence specificity to signify on the diagnostic plot.
#' @param nthreads: numeric value to indicate how many threads used in the analysis, default is 2
#' @param Evalue: numeric value to indicate e-value threshold in local-blast, default is 0.1 (1e-1)
#' @param outFormat: numeric value to specify -outfmt parameter in local blast, default is 6.
#' @param GCShow: logical value. whether to show GC content on the diagnostic plot, default is TRUE
#' @param TmShow: logical value.whether to show Tm value on the diagnostic plot, default is TRUE
#' @param specificiyShow: logical value.whether to show sequence specificity value on the diagnostic plot, default is TRUE
#' @param countShow: logical value.whether to show Counts on the diagnostic plot, default is TRUE
#' @param countMax: numeric value to indicates the maximum counts threshold, by which fragment to be displayed with dashed line.
#' @param segmentLinetype: numeric value indicates which line type to be used. It is inherited from basic line types in the R.
#' @param segmentColor: string indicate the color of geom_segment(), which represent fragment sequence on the chromosome in terms of location.
#' @param segmentSize: numeric value indicates line size of geom_segment(), default value is 0.2
#' @param pointShape: numeric value indicates point shape in geom_point(), default value for pointShape1 and pointShape2 are 19 and 24 respectively.
#' @param pointColor: string indicates color of geom_point(), default value for pointColor1 and pointColor2 are 'red' and 'blue' respectively.
#' @param pointSize: numeric value indicates point size in geom_point(), default value for pointSize, pointSize1, and pointSize2 are 0.5, 0.5, and 0.5 respectively.
#' @param hlineType: numeric value indicates line type in geom_hline(), default value is 2.
#' @param hlineColor: string indicates line color in geom_hline(), default value is 'blue'
#' @param hlineSize: numeric value indicates line size, default value is 0.3.
#' @param pdfWidth: numeric value indicates width of pdf file, default value is 16.
#' @param pdfHeight: numeric value indicates height of pdf file, default value is 10.
#' @param seqEvaluation: seqEvaluation folder.
#' @param plotting: logical value indicates whether to plot primers or not.
#' @param TmScope: numeric scope indicates the min and max of primer Tm, default value is 'c(40, 60)'.
#' @param GCScope: numeric scope indicates the min and max of primer GC content (%), default value is 'c(35, 65)'.
#' @param specificityMin: numeric value indicates the minimum standard of sequence specificity (%), default value is 98%.
#' @param countMax: numeric value indicates the maximum standard of counts of this primer mathched to different position on the chromosome, default value is 2.
#' @param endMatch: logical value indicates whether the primer end (3') matched to genome, default value is TRUE
#' @param GCend: logical value indicates whether the primer end (3') should be G:C or not, default value is TRUE
#' @param lengthScope: numeric scope indicates the expected min and max amplicon length of primer pairs, default value is 'c(70, 150)'.
#' @param primerLength: numeric scope indicates the min and max length of primer, default value is 'c(20, 25)'.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param primerStrand: 'F' or 'R', or c('F', 'R')
#' @param Fcolor: color value for forward primers, default is "#B2182B".
#' @param Rcolor: color value for reverse primers, default is "#2166AC".
#' @param lcolor: color value for line connecting forward and reverse primer pairs, default is 'black'.
#' @param rectFill: color value for rect shade indicating the position of SNP or Indel, default is '#FF3300'.
#' @return files and folder
#' @export primer.designing.pipeline.for.SNP.and.Indel.markers
#' @examples primer.designing.pipeline.for.SNP.and.Indel.markers(database = "./soybean.genome/", IndelFile = "./IndelList.xlsx", blastDir = "./ncbi-blast-2.12.0+/")
#' 
#' 

#primer.designing.pipeline.for.SNP.and.Indel.markers(database = "./soybean.genome/", lociName = "Indel3", type = "Indel", chr = 8, pos = 12345, start = 13246, end = 13248, blastDir = "./ncbi-blast-2.12.0+/")

#primer.designing.pipeline.for.SNP.and.Indel.markers(database = "./soybean.genome/", SNPFile = "./SNPList.xlsx", blastDir = "./ncbi-blast-2.12.0+/")

#primer.designing.pipeline.for.SNP.and.Indel.markers(database = "./soybean.genome/", IndelFile = "./IndelList.xlsx", blastDir = "./ncbi-blast-2.12.0+/")

primer.designing.pipeline.for.SNP.and.Indel.markers = function(database = NULL, SNPFile = NULL, IndelFile = NULL, seqType = NULL, type = NULL, lociName = NULL, chr = NULL, start = NULL, end = NULL, pos = NULL, leftFlanking = NULL, rightFlanking = NULL, inputFile = NULL, blastDir = NULL, windowSize = NULL, stepWise = NULL, TmMethod = NULL, specificityMin = NULL, nthreads = NULL, Evalue = NULL, GCShow = NULL, TmShow = NULL, specificiyShow = NULL, countShow = NULL, TmScope = NULL, GCScope = NULL, countMax = NULL, segmentLinetype = NULL, segmentColor = NULL, segmentSize = NULL, pointShape1 = NULL, pointShape2 = NULL, pointColor1 = NULL, pointColor2 = NULL, pointSize = NULL, pointSize1 = NULL, pointSize2 = NULL, hlineType = NULL, hlineColor = NULL, hlineSize = NULL, pdfWidth = NULL, pdfHeight = NULL, outFormat = NULL, seqEvaluation = NULL, plotting = NULL, endMatch = NULL, GCend = NULL, lengthScope = NULL, primerLength = NULL, primerStrand = NULL, Fcolor = NULL, Rcolor = NULL, lcolor = NULL, rectFill = NULL, ...){
  
  library(data.table)
  library(xlsx)
  dir.path = getwd()
  
  if(!is.null(SNPFile)){
    if(is.null(seqType)) seqType = "SNP"
    if(is.null(type)) type = "SNP"
    SNP.and.Indel.flanking.seq.extraction(database = database, SNPFile = SNPFile, IndelFile = IndelFile, type = type, lociName = lociName, chr = chr, start = start, end = end, pos = pos, leftFlanking = leftFlanking, rightFlanking = rightFlanking)
    if(length(grep(".csv|.txt", SNPFile)) == 1){
      SNP = fread(SNPFile, header = T, stringsAsFactors = F, fill = T, sep = "\t")
      if(ncol(SNP) == 1){
        SNP = fread(SNPFile, header = T, stringsAsFactors = F, fill = T, sep = ",")
        if(ncol(SNP) == 1){
          SNP = fread(SNPFile, header = T, stringsAsFactors = F, fill = T, sep = " ")
        }
      }
    }
    if(length(grep(".xlsx|.xls", SNPFile)) == 1){
      SNP = as.data.table(read.xlsx(SNPFile, header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
    }
    SNPList = list.files("./Sequence.extraction/SNP.flanking.sequence.extraction/")
    SNPList = paste0("./Sequence.extraction/SNP.flanking.sequence.extraction/", SNPList)
    for(i in 1:nrow(SNP)){
      SNPName = SNP$SNP.Name[i]
      inputFile = paste0("./Sequence.extraction/SNP.flanking.sequence.extraction/", SNPName, "/")
      if(file.exists(inputFile)){
        seq.evaluation(database = database, inputFile = inputFile, blastDir = blastDir, seqType = seqType, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
        seqEvaluation = paste0("./Sequence.evaluation/SNP/", SNPName, "/")
        if(file.exists(seqEvaluation)){
          primer.designing.for.SNP.and.Indel.markers(seqEvaluation = seqEvaluation, seqType = seqType, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend =  GCend, lengthScope = lengthScope, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, rectFill = rectFill)
        }else{
          warning(paste0(SNPName, " does not exist in ./Sequence.evaluation/SNP/"))
          next
        }
      }else{
        warning(paste0(SNPName, " does not exist in ./Sequence.evaluation/SNP.flanking.sequence.extraction/"))
        next
      }
    }
  }
  if(!is.null(IndelFile)){
    if(is.null(seqType)) seqType = "Indel"
    if(is.null(type)) type = "Indel"
    SNP.and.Indel.flanking.seq.extraction(database = database, SNPFile = SNPFile, IndelFile = IndelFile, type = type, lociName = lociName, chr = chr, start = start, end = end, pos = pos, leftFlanking = leftFlanking, rightFlanking = rightFlanking)
    if(length(grep(".csv|.txt", SNPFile)) == 1){
      Indel = fread(IndelFile, header = T, stringsAsFactors = F, fill = T, sep = "\t")
      if(ncol(Indel) == 1){
        Indel = fread(IndelFile, header = T, stringsAsFactors = F, fill = T, sep = ",")
        if(ncol(Indel) == 1){
          Indel = fread(IndelFile, header = T, stringsAsFactors = F, fill = T, sep = " ")
        }
      }
    }
    if(length(grep(".xlsx|.xls", IndelFile)) == 1){
      Indel = as.data.table(read.xlsx(IndelFile, header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
    }
    IndelList = list.files("./Sequence.extraction/Indel.flanking.sequence.extraction/")
    IndelList = paste0("./Sequence.extraction/Indel.flanking.sequence.extraction/", IndelList)
    for(i in 1:nrow(Indel)){
      IndelName = Indel$Indel.Name[i]
      inputFile = paste0("./Sequence.extraction/Indel.flanking.sequence.extraction/", IndelName, "/")
      if(file.exists(inputFile)){
        seq.evaluation(database = database, inputFile = inputFile, blastDir = blastDir, seqType = seqType, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
        seqEvaluation = paste0("./Sequence.evaluation/Indel/", IndelName, "/")
        if(file.exists(seqEvaluation)){
          primer.designing.for.SNP.and.Indel.markers(seqEvaluation = seqEvaluation, seqType = seqType, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend =  GCend, lengthScope = lengthScope, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, rectFill = rectFill)
        }else{
          warning(paste0(SNPName, " does not exist in ./Sequence.evaluation/Indel/"))
          next
        }
      }else{
        warning(paste0(SNPName, " does not exist in ./Sequence.evaluation/Indel.flanking.sequence.extraction/"))
        next
      }
    }
  }
  if(is.null(IndelFile) & is.null(SNPFile) & !is.null(lociName)){
    if(is.null(type)) stop("'type' is required when NO SNPFile, NO IndelFile, and lociName as input!")
    if(type == "SNP" | type == "snp"){
      seqType = "SNP"
    }
    if(type == "Indel" | type == "indel" | type == "INDEL"){
      seqType = "Indel"
    }
    SNP.indel.flanking.seq.extraction(database = database, SNPFile = SNPFile, IndelFile = IndelFile, type = type, lociName = lociName, chr = chr, start = start, end = end, pos = pos, leftFlanking = leftFlanking, rightFlanking = rightFlanking)
    LocusName = lociName
    inputFile = paste0("./Sequence.extraction/", seqType, ".flanking.sequence.extraction/", LocusName, "/")
    if(file.exists(inputFile)){
      seq.evaluation(database = database, inputFile = inputFile, blastDir = blastDir, seqType = seqType, windowSize = windowSize, stepWise = stepWise, TmMethod = TmMethod, specificityMin = specificityMin, nthreads = nthreads, Evalue = Evalue, GCShow = GCShow, TmShow = TmShow, specificiyShow = specificiyShow, countShow = countShow, TmScope = TmScope, GCScope = GCScope, countMax = countMax, segmentLinetype = segmentLinetype, segmentColor = segmentColor, segmentSize = segmentSize, pointShape1 = pointShape1, pointShape2 = pointShape2, pointColor1 = pointColor1, pointColor2 = pointColor2, pointSize = pointSize, pointSize1 = pointSize1, pointSize2 = pointSize2, hlineType = hlineType, hlineColor = hlineColor, hlineSize = hlineSize, pdfWidth = pdfWidth, pdfHeight = pdfHeight, outFormat = outFormat)
      seqEvaluation = paste0("./Sequence.evaluation/", seqType, "/", LocusName, "/")
      if(file.exists(seqEvaluation)){
        primer.designing.for.SNP.and.Indel.markers(seqEvaluation = seqEvaluation, seqType = seqType, plotting = plotting, TmScope = TmScope, GCScope = GCScope, specificityMin = specificityMin, countMax = countMax, endMatch = endMatch, GCend =  GCend, lengthScope = lengthScope, primerLength = primerLength, TmMethod = TmMethod, primerStrand = primerStrand, Fcolor = Fcolor, Rcolor = Rcolor, lcolor = lcolor, rectFill = rectFill)
      }else{
        warning(paste0(LocusName, " does not exist in ./Sequence.evaluation/", LocusName, "/"))
      }
    }else{
      warning(paste0(LocusName, " does not exist in ./Sequence.evaluation/", LocusName, ".flanking.sequence.extraction/"))
    }
  }
  cat("\nAll Done!")
}

