
#' This is some description of this function.
#' @title to develop molecular markers for SNP and Indel from flanking region.
#'
#' @description By using this package, you could use function of primer.designing.for.SNP.and.Indel.markers to develop molecular markers for SNP and Indel from flanking region.
#'
#' @details see above

#' @param seqType: string to indicate type of sequence, which could one of 'Indel', "SNP'.
#' @param seqEvaluation: seqEvaluation folder.
#' @param plotting: logical value indicates whether to plot primers or not.
#' @param TmScope: numeric scope indicates the min and max of primer Tm, default value is 'c(40, 60)'.
#' @param GCScope: numeric scope indicates the min and max of primer GC content (%), default value is 'c(35, 65)'.
#' @param specificityMin: numeric value indicates the minimum standard of sequence specificity (%), default value is 98%.
#' @param countMax: numeric value indicates the maximum standard of counts of this primer mathched to different position on the chromosome, default value is 2.
#' @param endMatch: logical value indicates whether the primer end (3') matched to genome, default value is TRUE
#' @param GCend: logical value indicates whether the primer end (3') should be G:C or not, default value is TRUE
#' @param lengthScope: numeric scope indicates the expected min and max amplicon length of primer pairs, default value is 'c(70, 150)'.
#' @param primerLength: numeric scope indicates the min and max length of primer, default value is 'c(20, 25)'.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param primerStrand: 'F' or 'R', or c('F', 'R')
#' @param Fcolor: color value for forward primers, default is "#B2182B".
#' @param Rcolor: color value for reverse primers, default is "#2166AC".
#' @param lcolor: color value for line connecting forward and reverse primer pairs, default is 'black'.
#' @param rectFill: color value for rect shade indicating the position of SNP or Indel, default is '#FF3300'.
#' @return files and folder
#' @export primer.designing.for.SNP.and.Indel.markers
#' @examples primer.designing.for.SNP.and.Indel.markers(seqEvaluation = "./Sequence.evaluation/")
#' 
#' 

#plotting = NULL; TmScope = NULL; GCScope = NULL; specificityMin = NULL; countMax = NULL; endMatch = NULL; GCend = NULL; lengthScope = NULL; primerLength = NULL; TmMethod = NULL; primerStrand = NULL; Fcolor = NULL; Rcolor = NULL; lcolor = NULL; rectFill = NULL; seqType = NULL


#primer.designing.for.SNP.and.Indel.markers(seqEvaluation = "./Sequence.evaluation/Indel/Indel1/", seqType = "Indel")

primer.designing.for.SNP.and.Indel.markers = function(seqEvaluation = NULL, seqType = NULL, plotting = NULL, TmScope = NULL, GCScope = NULL, specificityMin = NULL, countMax = NULL, endMatch = NULL, GCend = NULL, lengthScope = NULL, primerLength = NULL, TmMethod = NULL, primerStrand = NULL, Fcolor = NULL, Rcolor = NULL, lcolor = NULL, rectFill = NULL, ...){
  library(stringr)
  library(seqinr)
  library(Biostrings)
  library(tidyr)
  library(xlsx)
  library(WriteXLS)
  library(data.table)
  library(ggplot2)
  
  dir.path = getwd()
  
  if(!dir.exists(paste0(dir.path, "/", "Designed.primers"))){
    dir.create(paste0(dir.path, "/", "Designed.primers"))
  }
  if(!dir.exists(paste0(dir.path, "/", "Designed.primers/", "SNP.and.Indel.primers"))){
    dir.create(paste0(dir.path, "/", "Designed.primers/", "SNP.and.Indel.primers"))
  }
  
  if(is.null(seqEvaluation)) stop("'seqEvaluation' is required!")
  if(is.null(TmScope)) TmScope = c(40, 60)
  if(is.null(GCScope)) GCScope = c(35, 65)
  if(is.null(countMax)) countMax = 2
  if(is.null(specificityMin)) specificityMin = 98
  if(is.null(endMatch)) endMatch = TRUE
  if(is.null(GCend)) GCend = TRUE
  if(is.null(lengthScope)) lengthScope = c(70, 150)
  if(is.null(primerLength)) primerLength = c(20, 25)
  if(is.null(TmMethod)) TmMethod = "both"
  if(is.null(primerStrand)) primerStrand = c('F', 'R')
  if(is.null(plotting)) plotting = TRUE
  if(is.null(Fcolor)) Fcolor = "#B2182B"
  if(is.null(Rcolor)) Rcolor = "#2166AC"
  if(is.null(lcolor)) lcolor = "black"
  if(is.null(rectFill)) rectFill = '#FF3300'
  
  if(!dir.exists(seqEvaluation)){
    stop("'seqEvaluation' should be a folder contains 'Blast.output', 'Splitted.seq', 'window.size.by.*' etc., please perform seq.evaluation() analysis before primer designing!\n")
  }
  
  # file merging function
  data.merging = function(fileList = NULL, header = NULL, skipRow = NULL, ...){
    library(data.table)
    if(is.null(fileList)) stop("'fileList' in 'data.merging' is required!")
    if(is.null(header)) header = T
    if(is.null(skipRow)) skipRow = 0
    data = fread(fileList[1], header = header, stringsAsFactors = F, sep = "\t", skip = skipRow, fill = T)
    if(ncol(data) == 1){
      data = fread(fileList[1], header = header, stringsAsFactors = F, sep = ",", skip = skipRow, fill = T)
      if(ncol(data) == 1){
        data = fread(fileList[1], header = header, stringsAsFactors = F, sep = " ", skip = skipRow, fill = T)
      }
    }
    for(i in 2:length(fileList)){
      temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = "\t", skip = skipRow, fill = T)
      if(ncol(temp) == 1){
        temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = ",", skip = skipRow, fill = T)
        if(ncol(temp) == 1){
          temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = " ", skip = skipRow, fill = T)
        }
      }
      data = rbind(data, temp)
    }
    return(data)
  }
  
  ## file list path classification
  file.list = list.files(paste0(dir.path, "/", seqEvaluation), recursive = TRUE)
  dir = paste0(dir.path, "/", seqEvaluation, file.list)
  dir = dir[-grep(".pdf", dir)]
  dir = dir[-grep("blast_output|split.seq", dir)]
  seqEval.dir = dir[grep("sequence.evaluation.csv", dir)]
  SNP.dir = seqEval.dir[grep("SNP", seqEval.dir)]
  Indel.dir = seqEval.dir[grep("Indel", seqEval.dir)]
  SI.dir = c(SNP.dir, Indel.dir)
  
  
  # i = 1
  if(seqType == "SNP" | seqType == "snp"){
    SNP.dir.name = c()
    for(i in 1:length(SNP.dir)){
      temp = strsplit(strsplit(SNP.dir[i], "/")[[1]][length(strsplit(SNP.dir[i], "/")[[1]])], "_")[[1]]
      SNP.dir.name = c(SNP.dir.name, temp[1])
    }
    loci = unique(SNP.dir.name)
  }
  if(seqType == "Indel" | seqType == "indel" | seqType == "indel"){
    Indel.dir.name = c()
    for(i in 1:length(Indel.dir)){
      temp = strsplit(strsplit(Indel.dir[i], "/")[[1]][length(strsplit(Indel.dir[i], "/")[[1]])], "_")[[1]]
      Indel.dir.name = c(Indel.dir.name, temp[1])
    }
    loci = unique(Indel.dir.name)
  }
  # i = 1
  for(i in 1:length(loci)){
    loci.dir = SI.dir[grep(loci[i], SI.dir)]
    left.dir = loci.dir[grep("left", loci.dir)]
    right.dir = loci.dir[grep("right", loci.dir)]
    left = data.merging(fileList = left.dir)
    left$primerStrand = primerStrand[1]
    right = data.merging(fileList = right.dir)
    right$primerStrand = primerStrand[2]
    left.max = max(left$To)
    right.min = min(right$From)
    overall = rbind(left, right)
    names(overall) = gsub("\\(.?\\)|\\(5'-3'\\)", "", names(overall))
    setkeyv(left, names(left))
    setkeyv(right, names(right))
    setkeyv(overall, names(overall))
    
    ## primer selection
    ## Tm filtration
    if(TmMethod == "both"){
      overall.temp1 = overall[which((overall$Tm1 >= TmScope[1] & overall$Tm1 <= TmScope[2]) | (overall$Tm2 >= TmScope[2] & overall$Tm2 <= TmScope[2])),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("\nThe TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation.\n"))
        next
      }
    }
    if(TmMethod == 1){
      overall.temp1 = overall[which(overall$Tm1 >= TmScope[1] & overall$Tm1 <= TmScope[2]),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("\nThe TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation.\n"))
        next
      }
    }
    if(TmMethod == 2){
      overall.temp1 = overall[which(overall$Tm2 >= TmScope[2] & overall$Tm2 <= TmScope[2]),]
      if(nrow(overall.temp1) == 0){
        warning(paste0("\nThe TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation.\n"))
        next()
      }
    }
    
    ## GC content filtration
    overall.temp2 = overall.temp1[which(overall.temp1$GC.content >= GCScope[1] & overall.temp1$GC.content <= GCScope[2]),]
    if(nrow(overall.temp2) == 0){
      warning(paste0("\nThe GCScope between ", GCScope[1], " and ", GCScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation.\n"))
      next()
    }
    
    ## count filtration
    if(!is.null(countMax)){
      overall.temp3 = overall.temp2[which(overall.temp2$Counts <= countMax),]
    }else{
      overall.temp3 = overall.temp2
    }
    
    ## sequence specificity
    if(!is.null(specificityMin)){
      overall.temp4 = overall.temp3[which(overall.temp3$Seq.specificity >= specificityMin),]
    }else{
      overall.temp4 = overall.temp3
    }
    
    overall.temp4 = overall.temp4[order(overall.temp4$From),]
    type = str_extract_all(left.dir[1], "(SNP|Indel|snp|indel|INDEL)")[[1]][1]
    
    ## basic information outputting
    fwrite(overall.temp4, file = paste0(dir.path, "/", "Designed.primers/SNP.and.Indel.primers/", loci[i], "_", type, "_", overall$Chr[1], "_", min(overall$From), "..", max(overall$To),  ".primers.passed.filtration.csv"), row.names = F, col.names = T, sep = "\t", na = "NA")
    
    ## length selection
    length.select = data.table(matrix(nrow = 0, ncol = 11))
    names(length.select) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
    for(j in 1:(nrow(overall.temp4)-1)){
      for(k in (j+1):nrow(overall.temp4)){
        distance = overall.temp4$From[k] - overall.temp4$To[j]
        if(distance >= lengthScope[1] & distance <= lengthScope[2]){
          temp1 = data.table(matrix(nrow = 1, ncol = 11))
          names(temp1) = c("seqName1", "seq1", "seqStart1", "seqEnd1", "primerStrand1", "seqName2", "seq2","seqStart2", "seqEnd2", "primerStrand2", "Distance")
          temp1$seqName1[1] = overall.temp4$Name[j]
          temp1$seq1[1] = overall.temp4$Seq[j]
          temp1$seqStart1[1] = overall.temp4$From[j]
          temp1$seqEnd1[1] = overall.temp4$To[j]
          temp1$primerStrand1[1] = overall.temp4$primerStrand[j]
          temp1$seqName2[1] = overall.temp4$Name[k]
          temp1$seq2[1] = overall.temp4$Seq[k]
          temp1$seqStart2[1] = overall.temp4$From[k]
          temp1$seqEnd2[1] = overall.temp4$To[k]
          temp1$primerStrand2[1] = overall.temp4$primerStrand[k]
          temp1$Distance[1] = distance
          length.select = rbind(length.select, temp1)
        }
      }
    }
    
    length.select = length.select[which(length.select$primerStrand1 != length.select$primerStrand2),]
    if(nrow(length.select) == 0){
      warning(paste0("\nThe lengthScope between ", lengthScope[1], " and ", lengthScope[2], " for ", loci[i], " is too stringent, please try other values for this parameter.\n"))
      next()
    }else{
      GCend.select = length.select
    }
    
    ## primer length filtration
    GCend.select$seq1Length = nchar(GCend.select$seq1)
    GCend.select$seq2Length = nchar(GCend.select$seq2)
    GCend.select = GCend.select[which(GCend.select$seq1Length >= primerLength[1] & GCend.select$seq1Length <= primerLength[2] & GCend.select$seq2Length >= primerLength[1] & GCend.select$seq2Length <= primerLength[2]),]
    if(nrow(GCend.select) == 0){
      warning(paste0("\nThe primerLenth between ", primerLength[1], " and ", primerLength[2], " for ", loci[i], " is too stringent, please try other values for this parameter.\n"))
      next;
    }else{
      GCend.select = GCend.select
    }
    GCend.select = GCend.select[,-c(grep('seq1Length', names(GCend.select)), grep('seq2Length', names(GCend.select)))]
    
    ## endMatch
    if(GCend == TRUE){
      GCend.select$seq1endBase = NA
      GCend.select$seq2startBase = NA
      for(j in 1:nrow(GCend.select)){
        GCend.select$seq1endBase[j] = strsplit(GCend.select$seq1[j], "")[[1]][length(strsplit(GCend.select$seq1[j], "")[[1]])]
        GCend.select$seq2startBase[j] = strsplit(GCend.select$seq2[j], "")[[1]][1]
      }
      setkeyv(GCend.select, names(GCend.select))
      GCend.select = GCend.select[which((GCend.select$seq1endBase == "G" | GCend.select$seq1endBase == "C") & (GCend.select$seq2startBase == "G" | GCend.select$seq2startBase == "C")),]
    }else{
      GCend.select = GCend.select
    }
    
    ## reversing R primers
    GCend.select$seq2 = as.character(reverseComplement(DNAStringSet(GCend.select$seq2)))
    names(GCend.select) = gsub("seq2", "revc.seq2", names(GCend.select))
    GCend.select = GCend.select[,-c(12,13)]
    
    ## outputting
    fwrite(GCend.select, file = paste0(dir.path, "/", "Designed.primers/SNP.and.Indel.primers/", loci[i], "_", type, "_", overall$Chr[1], "_", min(overall$From), "..", max(overall$To), ".primers.final.csv"), row.names = F, col.names = T, sep = "\t", na = "NA")
    
    ## plotting
    if(plotting == TRUE | plotting == T & nrow(GCend.select) >= 1){
      SIname = strsplit(GCend.select$seqName1[1], "_")[[1]][1]
      type = strsplit(GCend.select$seqName1[1], "_")[[1]][2]
      chr = str_extract_all(GCend.select$seqName1[1], "(Chr[0-9][0-9])")[[1]]
      Start = strsplit(strsplit(GCend.select$seqName1[1], "_")[[1]][4], "\\..")[[1]][1]
      End = strsplit(strsplit(GCend.select$seqName1[1], "_")[[1]][4], "\\..")[[1]][2]
      GCend.select$order = seq(1:nrow(GCend.select))/10
      GCend.select$primerPair = paste0("Pair_", seq(1:nrow(GCend.select)), "(", GCend.select$Distance, "bp)")
      
      p = ggplot(GCend.select, aes(x = seqStart1, y = 0.1*nrow(GCend.select))) +
          labs(title = paste0(SIname, " ", type, " ", chr, ":", Start, "..", End, " primer distribution")) +
          xlab(paste0(chr, ":", min(overall$From), "..", max(overall$To))) +
          theme(axis.ticks.y.left = element_blank(),
                  axis.ticks.y = element_blank(),
                  axis.line.y = element_blank(),
                  axis.line.x.top = element_blank(),
                  panel.grid = element_blank(),
                  axis.text.y = element_blank(),
                  plot.background = element_blank(),
                  panel.background = element_blank(),
                  axis.title.y = element_blank(),
                  axis.line = element_line(colour = "black",size = 0.5))+
          geom_rect(aes(xmin = left.max, xmax = right.min, ymin = -Inf, ymax = Inf),fill = rectFill, alpha = .2) +
          xlim(c(min(overall$From), max(overall$To))) + ylim(c(0, 0.1*nrow(GCend.select) + 0.1)) +
          geom_segment(data = GCend.select,
                     mapping = aes(x = seqEnd1, xend = seqStart2, y = order, yend = order),
                     size = 0.1, color = lcolor) +
          geom_segment(data = GCend.select,
                     mapping = aes(x = seqStart1, xend = seqEnd1, y = order, yend = order),
                     arrow = arrow(length = unit(ifelse(nrow(GCend.select) <= 2, 0.2/nrow(GCend.select), ifelse(nrow(GCend.select) > 2 & nrow(GCend.select) <= 10, 0.5/nrow(GCend.select), ifelse(nrow(GCend.select) > 10 & nrow(GCend.select) <= 100, 5/nrow(GCend.select), ifelse(nrow(GCend.select) > 100, 10/nrow(GCend.select), 10/nrow(GCend.select))))),"cm")),
                     size = ifelse(nrow(GCend.select) <= 2, 2/nrow(GCend.select), ifelse(nrow(GCend.select) > 2 & nrow(GCend.select) <= 10, 3/nrow(GCend.select), ifelse(nrow(GCend.select) > 10 & nrow(GCend.select) <= 100, 100/nrow(GCend.select), ifelse(nrow(GCend.select) > 100, 120/nrow(GCend.select), 200/nrow(GCend.select))))), color = Fcolor) + 
          geom_segment(data = GCend.select,
                     mapping = aes(x = seqEnd2, xend = seqStart2, y = order, yend = order),
                     arrow = arrow(length = unit(ifelse(nrow(GCend.select) <= 2, 0.2/nrow(GCend.select), ifelse(nrow(GCend.select) > 2 & nrow(GCend.select) <= 10, 0.5/nrow(GCend.select), ifelse(nrow(GCend.select) > 10 & nrow(GCend.select) <= 100, 5/nrow(GCend.select), ifelse(nrow(GCend.select) > 100, 10/nrow(GCend.select), 10/nrow(GCend.select))))),"cm")),
                     size = ifelse(nrow(GCend.select) <= 2, 2/nrow(GCend.select), ifelse(nrow(GCend.select) > 2 & nrow(GCend.select) <= 10, 3/nrow(GCend.select), ifelse(nrow(GCend.select) > 10 & nrow(GCend.select) <= 100, 100/nrow(GCend.select), ifelse(nrow(GCend.select) > 100, 120/nrow(GCend.select), 200/nrow(GCend.select))))), color = Rcolor) +
          geom_text(data = GCend.select, mapping = aes(x = seqEnd2, y = order, label = primerPair),
                  check_overlap = TRUE, 
                  nudge_x = ifelse(nrow(GCend.select) <= 2, 80, ifelse(nrow(GCend.select) > 2 & nrow(GCend.select) <= 10, 75, ifelse(nrow(GCend.select) > 10 & nrow(GCend.select) <= 100, 70, ifelse(nrow(GCend.select) > 100, 65, 60)))), 
                  size = ifelse(nrow(GCend.select) <= 2, 2/nrow(GCend.select), ifelse(nrow(GCend.select) > 2 & nrow(GCend.select) <= 10, 10/nrow(GCend.select), ifelse(nrow(GCend.select) > 10 & nrow(GCend.select) <= 100, 50/nrow(GCend.select), ifelse(nrow(GCend.select) > 100, 80/nrow(GCend.select), 100/nrow(GCend.select))))))
        p = p + theme(plot.margin=unit(rep(2,4),'lines'))
        pdf(paste0(dir.path, "/", "Designed.primers/SNP.and.Indel.primers/", loci[i], "_", type, "_", overall$Chr[1], "_", min(overall$From), "..", max(overall$To), ".primers.final.plot.pdf"), width = 10, height = ifelse(nrow(GCend.select) <= 2, 3, ifelse(nrow(GCend.select) > 2 & nrow(GCend.select) <= 10, 5, ifelse(nrow(GCend.select) > 10 & nrow(GCend.select) <= 100, 10, ifelse(nrow(GCend.select) > 100, 15, 20)))))
        print(p)
        dev.off()
    }
  }
  #cat("\n'primer.designing.for.SNP.and.Indel' is Done!")
}
  
  
  
