
#' This is some description of this function.
#' @title to extract flanking sequence of certain length based on file input or parameters inputted manually to define SNPs or Indels
#'
#' @description By using this package, you could use function of SNP.indel.flanking.seq.extraction to extract flanking sequence of certain length based on file input or parameters inputted manually to define SNPs or Indels
#'
#' @details see above
#'
#' @param SNPFile: SNP file, including at least 'Type', 'Name', 'Chr', 'Start', 'End', 'Strand', 'Length', 'leftFlanking', 'rightFlanking', of which 'Type', 'Name', 'Chr', 'Start' and 'End' are required to be specified. The program would assign default value of '+', 'end - start', 200, and 200 for 'Strand', 'Length', 'leftFlanking', and 'rightFlanking' respectively. This file could be in format of *.csv, .txt, .xlsx, if .xlsx format was used parameters should be put in 'Sheet1' as default.
#' @param IndelFile: Indel file, which is similar as SNPFile.
#' @param type: string to indiate SNP or Indel, varied format is also accepted, e.g. snp, SNP, indel, Indel, and INDEL
#' @param database: folder or file contains genome sequence in fasta format
#' @param lociName: string to specify the name of a SNP or Indel, when input file was missed, 'lociName' is reuquired.
#' @param chr: string or numeric value indicates specific chromosome, when input file was missed, 'chr' is reuquired.
#' @param start: numeric value indicates the start position of Indel, when input file was missed, 'start' is reuquired.
#' @param end: numeric value indicates the end position of Indel, when input file was missed, 'end' is reuquired.
#' @param pos: numeric value indicates the position of SNP, when input file was missed, 'pos' is reuquired.
#' @param leftFlanking: numeric value indicates left flanking region of SNP or Indel, default value is 200bp.
#' @param rightFlanking: numeric value indicates right flanking region of SNP or Indel, default value is 200bp.
#' @return fasta files, log file stored in ".../Sequence.extraction/Fragment.sequence.extraction/"
#' @export SNP.and.Indel.flanking.seq.extraction
#' @examples SNP.indel.flanking.seq.extraction(database = "./soybean.genome/", lociName = "SNP1", type = "SNP", chr = 13, pos = 12345, start = 13246, end = 13248)
#' 

###### NOTES ######
# SNP.indel.flanking.seq.extraction.R is to extract flanking sequence of SNP or Indel loci, based on parameters defined either by a file or manually inputted.
######  END  ######

# SNP.indel.flanking.seq.extraction(database = "./soybean.genome/", lociName = "Indel1", type = "Indel", chr = 13, pos = 12345, start = 13246, end = 13248)

# SNP.indel.flanking.seq.extraction(database = "./soybean.genome/", SNPFile = "./SNPList.xlsx", type = "SNP")
# SNP.indel.flanking.seq.extraction(database = "./soybean.genome/", IndelFile = "./SNPList.xlsx", type = "Indel")

SNP.and.Indel.flanking.seq.extraction = function(database = NULL, SNPFile = NULL, IndelFile = NULL, type = NULL, lociName = NULL, chr = NULL, start = NULL, end = NULL, pos = NULL, leftFlanking = NULL, rightFlanking = NULL, ...){
  
  library(data.table)
  library(Biostrings)
  library(stringr)
  
  dir.path = getwd()
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction"))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction"))
  }
  
  if(is.null(type)){
    stop("'type' is required!")
  }
  if(is.null(SNPFile)) SNPFile = "NA"
  if(is.null(IndelFile)) IndelFile = "NA"
  
  ## database read in 
  if(dir.exists(database)){
    database.dir = paste0(dir.path, "/", database, list.files(paste0(dir.path, "/", database)))
    if(length(database.dir) == 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
    }
    if(length(database.dir) > 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
      for(i in 2:length(database.dir)){
        temp = readDNAStringSet(database.dir[i], format = "fasta")
        DNAseq = append(DNAseq, temp)
      }
    }
  }
  if(!dir.exists(database)){
    DNAseq = readDNAStringSet(database, format = "fasta")
  }
  
  ## SNP from file
  if(file.exists(SNPFile)){
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "SNP"))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/", "SNP"))
    }
    # file read in
    if(length(grep(".csv|.txt", SNPFile)) == 1){
      SNP = fread(SNPFile, header = T, stringsAsFactors = F, fill = T, sep = "\t")
      if(ncol(SNP) == 1){
        SNP = fread(SNPFile, header = T, stringsAsFactors = F, fill = T, sep = ",")
        if(ncol(SNP) == 1){
          SNP = fread(SNPFile, header = T, stringsAsFactors = F, fill = T, sep = " ")
        }
      }
    }
    if(length(grep(".xlsx|.xls", SNPFile)) == 1){
      SNP = as.data.table(read.xlsx(SNPFile, header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
    }
    SNPFile.name = gsub(".csv|.txt|.xlsx|.xls", "", strsplit(SNPFile, "/")[[1]][length(strsplit(SNPFile, "/")[[1]])])
    # file checking
    if(length(grep("SNP.Name|Chr|Pos|leftFlanking|rightFlanking", names(SNP))) != 5){
      warning("The column name of 'SNPFile' should at least contain: SNP.Name, Chr, Pos, leftFlanking, rightFlanking, please check input file!\n")
    }else{
      cat("The format of 'SNPFile' is correct!\n")
    }
    
    # sequence extraction
    for(i in 1:nrow(SNP)){
      SNP.temp = SNP[i,]
      if(is.null(SNP.temp$SNP.Name[1]) | setequal(NA, SNP.temp$SNP.Name[1])){
        stop(paste0("'SNP.Name' of ", SNPFile.name, " is missing!"))
      }else{
        SNPName = SNP.temp$SNP.Name[1]
      }
      if(is.null(SNP.temp$Chr[1]) | setequal(NA, SNP.temp$Chr[1])){
        stop(paste0("'Chr' of ", SNPFile.name, " is missing!"))
      }else{
        chr = SNP$Chr[i]
        chr.format = names(DNAseq)[1]
        chr.format = str_extract_all(chr.format, "(Chr|Gm)")[[1]]
        if(length(grep(chr.format, chr)) == 0){
          if(is.numeric(chr)){
            chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
          }else{
            chr = as.numeric(gsub("Chr|Gm", "", chr))
            chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
          }
        }
      }
      if(is.null(SNP.temp$Pos[1]) | setequal(NA, SNP.temp$Pos[1])){
        stop(paste0("'Pos' of ", SNPFile.name, " is missing!"))
      }else{
        pos = SNP.temp$Pos[1]
      }
      if(is.null(SNP.temp$leftFlanking[1]) | setequal(NA, SNP.temp$leftFlanking[1])){
        warning(paste0("'leftFlanking' of ", SNPFile.name, " is missing!", " Default value of 200bp is assigned to 'leftFlanking'!\n"))
        leftFlanking = 200
      }else{
        leftFlanking = as.numeric(SNP.temp$leftFlanking[1])
      }
      if(is.null(SNP.temp$rightFlanking[1]) | setequal(NA, SNP.temp$rightFlanking[1])){
        warning(paste0("'rightFlanking' of ", SNPFile.name, " is missing!", " Default value of 200bp is assigned to 'rightFlanking'!\n"))
        rightFlanking = 200
      }else{
        rightFlanking = as.numeric(SNP.temp$rightFlanking[1])
      }
      
      if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "SNP/", SNPName))){
        dir.create(paste0(dir.path, "/", "Sequence.extraction/", "SNP/", SNPName))
      }
      
      # Chromosome separation
      DNAseq.chr = DNAseq[chr]
      if(length(DNAseq.chr) == 0){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "SNP.sequence.extraction/", "SNP.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0('Program is stopped!', "please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!"))
        writeLines("######## THE END  ########")
        sink(type = "output")
        stop("please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!\n")
      } 
      
      # seq extraction
      seq.left = as.character(subseq(DNAseq.chr, start = (pos - leftFlanking), end = pos))
      seq.left = DNAStringSet(seq.left)
      names(seq.left) = paste0(SNPName, "_SNP_", chr, "_", (pos - leftFlanking), "..", pos, "_leftFlanking.", leftFlanking)
      writeXStringSet(seq.left, filepath = paste0(dir.path, "/", "Sequence.extraction/", "SNP/", SNPName, "/", SNPName, "_SNP_", chr, "_", (pos - leftFlanking), "..", pos, "_leftFlanking.", leftFlanking, ".fasta"), compress = FALSE)
      
      seq.right = as.character(subseq(DNAseq.chr, start = pos, end = (pos + rightFlanking)))
      seq.right = DNAStringSet(seq.right)
      names(seq.right) = paste0(SNPName, "_SNP_", chr, "_", pos, "..", (pos + rightFlanking), "_rightFlanking.", rightFlanking)
      writeXStringSet(seq.right, filepath = paste0(dir.path, "/", "Sequence.extraction/", "SNP/",SNPName, "/", SNPName, "_SNP_", chr, "_", pos, "..", (pos + rightFlanking), "_rightFlanking.", rightFlanking, ".fasta"), compress = FALSE)
    }
  }
  
  # SNP from input
  if(SNPFile == "NA" & (type == "SNP" | type == "snp")){
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "SNP"))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/", "SNP"))
    }
    if(is.null(lociName)){
      stop("'lociName' is required when there is no SNPFile as input, all parameters defining a SNP locus should not be 'NULL'!\n")
    }else{
      SNPName = lociName
    }
    if(is.null(chr)){
      stop("'chr' is required when there is no SNPFile as input, all parameters defining a SNP locus should not be 'NULL'!\n")
    }else{
      chr.format = names(DNAseq)[1]
      chr.format = str_extract_all(chr.format, "(Chr|Gm)")[[1]]
      if(length(grep(chr.format, chr)) == 0){
        if(is.numeric(chr)){
          chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
        }else{
          chr = as.numeric(gsub("Chr|Gm", "", chr))
          chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
        }
      }
    }
    if(is.null(pos)){
      stop("'locusPos' is required when there is no SNPFile as input, all parameters defining a SNP locus should not be 'NULL'!\n")
    }else{
      pos = pos
    }
    if(is.null(leftFlanking)) leftFlanking = 200
    if(is.null(rightFlanking)) rightFlanking = 200
    
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "SNP/", SNPName))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/", "SNP/", SNPName))
    }
    
    # Chromosome separation
    DNAseq.chr = DNAseq[chr]
    if(length(DNAseq.chr) == 0){
      sink(paste0(dir.path, "/", "Sequence.extraction/", "SNP/", "SNP.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0('Program is stopped!', "please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!"))
      writeLines("######## THE END  ########")
      sink(type = "output")
      stop("please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!\n")
    } 
    
    # seq extraction
    seq.left = as.character(subseq(DNAseq.chr, start = (pos - leftFlanking), end = pos))
    seq.left = DNAStringSet(seq.left)
    names(seq.left) = paste0(SNPName, "_SNP_", chr, "_", (pos - leftFlanking), "..", pos, "_leftFlanking.", leftFlanking)
    writeXStringSet(seq.left, filepath = paste0(dir.path, "/", "Sequence.extraction/", "SNP/", SNPName, "/", SNPName, "_SNP_", chr, "_", (pos - leftFlanking), "..", pos, "_leftFlanking.", leftFlanking, ".fasta"), compress = FALSE)
    
    seq.right = as.character(subseq(DNAseq.chr, start = pos, end = (pos + rightFlanking)))
    seq.right = DNAStringSet(seq.right)
    names(seq.right) = paste0(SNPName, "_SNP_", chr, "_", pos, "..", (pos + rightFlanking), "_rightFlanking.", rightFlanking)
    writeXStringSet(seq.right, filepath = paste0(dir.path, "/", "Sequence.extraction/", "SNP/", SNPName, "/", SNPName, "_SNP_", chr, "_", pos, "..", (pos + rightFlanking), "_rightFlanking.", rightFlanking, ".fasta"), compress = FALSE)
  }
  
  ## Indel from file
  if(file.exists(IndelFile) & (type == "Indel" | type == "INDEL" | type == "indel")){
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Indel"))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Indel"))
    }
    # file read in
    if(length(grep(".csv|.txt", IndelFile)) == 1){
      Indel = fread(IndelFile, header = T, stringsAsFactors = F, fill = T, sep = "\t")
      if(ncol(Indel) == 1){
        Indel = fread(IndelFile, header = T, stringsAsFactors = F, fill = T, sep = ",")
        if(ncol(SNP) == 1){
          Indel = fread(IndelFile, header = T, stringsAsFactors = F, fill = T, sep = " ")
        }
      }
    }
    if(length(grep(".xlsx|.xls", IndelFile)) == 1){
      Indel = as.data.table(read.xlsx(IndelFile, header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
    }
    IndelFile.name = gsub(".csv|.txt|.xlsx|.xls", "", strsplit(IndelFile, "/")[[1]][length(strsplit(IndelFile, "/")[[1]])])
    # file checking
    if(length(grep("Indel.Name|Chr|Start|End|leftFlanking|rightFlanking", names(Indel))) != 6){
      warning("\nThe column name of 'IndelFile' should at least contain: Indel.Name, Chr, Start, End, leftFlanking, rightFlanking, please check input file!\n")
    }else{
      cat("The format of 'IndelFile' is correct!\n")
    }
    
    # sequence extraction
    for(i in 1:nrow(Indel)){
      Indel.temp = Indel[i,]
      if(is.null(Indel.temp$Indel.Name[1]) | setequal(NA, Indel.temp$Indel.Name[1])){
        stop(paste0("'Indel.Name' of ", IndelFile.name, " is missing!"))
      }else{
        IndelName = Indel.temp$Indel.Name[1]
      }
      if(is.null(Indel.temp$Chr[1]) | setequal(NA, Indel.temp$Chr[1])){
        stop(paste0("'Chr' of ", IndelFile.name, " is missing!"))
      }else{
        chr = Indel$Chr[i]
        chr.format = names(DNAseq)[1]
        chr.format = str_extract_all(chr.format, "(Chr|Gm)")[[1]]
        if(length(grep(chr.format, chr)) == 0){
          if(is.numeric(chr)){
            chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
          }else{
            chr = as.numeric(gsub("Chr|Gm", "", chr))
            chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
          }
        }
      }
      if(is.null(Indel.temp$Start[1]) | setequal(NA, Indel.temp$Start[1])){
        stop(paste0("'Start' of ", IndelFile.name, " is missing!"))
      }else{
        start = Indel.temp$Start[1]
      }
      if(is.null(Indel.temp$End[1]) | setequal(NA, Indel.temp$End[1])){
        stop(paste0("'End' of ", IndelFile.name, " is missing!"))
      }else{
        end = Indel.temp$End[1]
      }
      if(is.null(Indel.temp$leftFlanking[1]) | setequal(NA, Indel.temp$leftFlanking[1])){
        warning(paste0("\n'leftFlanking' of ", IndelFile.name, " is missing!", " Default value of 200bp is assigned to 'leftFlanking'!\n"))
        leftFlanking = 200
      }else{
        leftFlanking = as.numeric(Indel.temp$leftFlanking[1])
      }
      if(is.null(Indel.temp$rightFlanking[1]) | setequal(NA, Indel.temp$rightFlanking[1])){
        warning(paste0("\n'rightFlanking' of ", IndelFile.name, " is missing!", " Default value of 200bp is assigned to 'rightFlanking'!\n"))
        rightFlanking = 200
      }else{
        rightFlanking = as.numeric(Indel.temp$rightFlanking[1])
      }
      
      if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Indel/", IndelName))){
        dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Indel/", IndelName))
      }
      
      # Chromosome separation
      DNAseq.chr = DNAseq[chr]
      if(length(DNAseq.chr) == 0){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Indel/", "Indel.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0('Program is stopped!', "please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!"))
        writeLines("######## THE END  ########")
        sink(type = "output")
        stop("please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!\n")
      } 
      
      # seq extraction
      seq.left = as.character(subseq(DNAseq.chr, start = (start - leftFlanking), end = start))
      seq.left = DNAStringSet(seq.left)
      names(seq.left) = paste0(IndelName, "_Indel_", chr, "_", (start - leftFlanking), "..", start, "_leftFlanking.", leftFlanking)
      writeXStringSet(seq.left, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Indel/", IndelName, "/", IndelName, "_Indel_", chr, "_", (start - leftFlanking), "..", start, "_leftFlanking.", leftFlanking, ".fasta"), compress = FALSE)
      
      seq.right = as.character(subseq(DNAseq.chr, start = end, end = (end + rightFlanking)))
      seq.right = DNAStringSet(seq.right)
      names(seq.right) = paste0(IndelName, "_Indel_", chr, "_", end, "..", (end + rightFlanking), "_rightFlanking.", rightFlanking)
      writeXStringSet(seq.right, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Indel/", IndelName, "/", IndelName, "_Indel_", chr, "_", end, "..", (end + rightFlanking), "_rightFlanking.", rightFlanking, ".fasta"), compress = FALSE)
    }
  }
  
  # Indel from input
  if(IndelFile == "NA" & (type == "Indel" | type == "INDEL" | type == "indel")){
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Indel"))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Indel"))
    }
    if(is.null(lociName)){
      stop("'lociName' is required when there is no IndelFile as input, all parameters defining a Indel locus should not be 'NULL'!\n")
    }else{
      IndelName = lociName
    }
    if(is.null(chr)){
      stop("'chr' is required when there is no IndelFile as input, all parameters defining a Indel locus should not be 'NULL'!\n")
    }else{
      chr.format = names(DNAseq)[1]
      chr.format = str_extract_all(chr.format, "(Chr|Gm)")[[1]]
      if(length(grep(chr.format, chr)) == 0){
        if(is.numeric(chr)){
          chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
        }else{
          chr = as.numeric(gsub("Chr|Gm", "", chr))
          chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
        }
      }
    }
    if(is.null(start)){
      stop("'start' is required when there is no IndelFile as input, all parameters defining a Indel locus should not be 'NULL'!\n")
    }else{
      start = start
    }
    if(is.null(end)){
      stop("'end' is required when there is no IndelFile as input, all parameters defining a Indel locus should not be 'NULL'!\n")
    }else{
      end = end
    }
    if(is.null(leftFlanking)) leftFlanking = 200
    if(is.null(rightFlanking)) rightFlanking = 200
    
    if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Indel/", IndelName))){
      dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Indel/", IndelName))
    }
    
    # Chromosome separation
    DNAseq.chr = DNAseq[chr]
    if(length(DNAseq.chr) == 0){
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Indel/", "Indel.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0('Program is stopped!', "please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!"))
      writeLines("######## THE END  ########")
      sink(type = "output")
      stop("please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!\n")
    } 
    
    # seq extraction
    seq.left = as.character(subseq(DNAseq.chr, start = (start - leftFlanking), end = start))
    seq.left = DNAStringSet(seq.left)
    names(seq.left) = paste0(IndelName, "_Indel_", chr, "_", (start - leftFlanking), "..", start, "_leftFlanking.", leftFlanking)
    writeXStringSet(seq.left, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Indel/", IndelName, "/", IndelName, "_Indel_", chr, "_", (start - leftFlanking), "..", start, "_leftFlanking.", leftFlanking, ".fasta"), compress = FALSE)
    
    seq.right = as.character(subseq(DNAseq.chr, start = end, end = (end + rightFlanking)))
    seq.right = DNAStringSet(seq.right)
    names(seq.right) = paste0(IndelName, "_Indel_", chr, "_", end, "..", (end + rightFlanking), "_rightFlanking.", rightFlanking)
    writeXStringSet(seq.right, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Indel/", IndelName, "/", IndelName, "_Indel_", chr, "_", end, "..", (end + rightFlanking), "_rightFlanking.", rightFlanking, ".fasta"), compress = FALSE)
  }
  cat("'SNP.and.Indel.flanking.seq.extraction is DONE!\n")
}


