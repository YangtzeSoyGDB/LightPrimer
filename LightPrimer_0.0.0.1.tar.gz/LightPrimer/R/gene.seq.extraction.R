
#' This is some description of this function.
#' @title to extract sequence related to gene
#'
#' @description By using this package, you could use function of gene.seq.extraction to extract sequence related to gene
#'
#' @details see above
#'
#' @param geneName: gene name alone or gene list file, which including two columns, namely, Gene.ID and Type. Type indicates the CDS, promoter, mRNA, gene, five_prime_UTR, three_prime_UTR or all (all types)
#' @param database: folder contains genome sequence in fasta format
#' @param gffFile: source data stores gene models and gene location on chromosome
#' @param type: a string to indicate the type of geneName, if no type has been assigned in the geneName file or for gene alone, default is 'all'. If 
#' @param promoterLength: numeric value indicates the length of promoter sequence to extract, default is 2000bp.
#' @param leftFlanking: numeric value indicates the left flanking region, default value is 200bp.
#' @param rightFlanking: numeric value indicates the right flanking region, default value is 200bp.
#' @param For: string to indicate purpose of sequence, e.g. Cloning, qRT-PCR, marker.development.
#' @return files and folder
#' @export gene.seq.extraction
#' @examples gene.seq.extraction(database = "./soybean.genome/", gffFile = "./Wm82.a2.v1.gene.gff", geneName = "./gene.list.csv")
#' 

# gene.seq.extraction(database = "./soybean.genome/", gffFile = "./Wm82.a2.v1.gene.gff", geneName = "Glyma.20G148100", For = "Cloning")

# gene.seq.extraction(database = "./soybean.genome/", gffFile = "./Wm82.a2.v1.gene.gff", geneName = "./gene.list.csv")

gene.seq.extraction = function(database = NULL, geneName = NULL, gffFile = NULL, type = NULL, promoterLength = NULL, leftFlanking = NULL, rightFlanking = NULL, For = NULL, ...){
  
  library(data.table)
  library(Biostrings)
  library(stringr)
  
  dir.path = getwd()
  
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction"))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction"))
  }
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Gene"))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Gene"))
  }
  
  sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
  writeLines("\n######## Gene Sequence Extraction  ########")
  writeLines(paste0("\nDate: ", date()))
  if(file.exists(geneName)){
    writeLines(paste0("Information source: File\n"))
  }else{
    writeLines(paste0("Information source: parameters input manually\n"))
  }
  sink(type = "output")
  
  if(is.null(geneName)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Program is stopped! 'geneName'' is required!"))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'geneName' is required!")
  } 
  if(is.null(database)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Program is stopped! 'database' is required!"))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'database' is required!")
  } 
  if(is.null(gffFile)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Program is stopped! 'gffFile' is required!"))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'gffFile' is required!")
  } 

  if(is.null(promoterLength)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Warning: ", " 'promoterLength' is missing!", ". Dafault value of 2000bp is assigned to 'promoterLength'!"))
    sink(type = "output")
    promoterLength = 2000
  } 
  if(is.null(leftFlanking)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Warning: ", " 'leftFlanking' is missing!", ". Dafault value of 200bp is assigned to 'leftFlanking'!"))
    sink(type = "output")
    leftFlanking = 200
  } 
  if(is.null(rightFlanking)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Warning: ", " 'rightFlanking' is missing!", ". Dafault value of 200bp is assigned to 'rightFlanking'!"))
    sink(type = "output")
    rightFlanking = 200
  }

  
  # gff file read in
  gff = fread(gffFile, header = T, sep = "\t", fill = TRUE)
  if(ncol(gff) == 1){
    gff = fread(gffFile, header = T, sep = ",", fill = TRUE)
    if(ncol(gff) == 1){
      gff = fread(gffFile, header = T, sep = " ", fill = TRUE)
    }
  }

  if(length(grep("(Gene.ID|Chr|Start|End|Strand|Type)", names(gff))) == 6){
    gff = gff[,c("Gene.ID", "Chr", "Start", "End", "Strand", "Type")]
    type.length = length(unique(gff$Type))
    types = unique(gff$Type)[1]
    for(i in 2:length(unique(gff$Type))){
      types = paste0(types, ", ", unique(gff$Type)[i])
    }
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("gffFile contains ", nrow(gff), " rows, ", type.length, " types, including ", types))
    sink(type = "output")
  }else{
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("Program is stopped!", " gff file should contain at least the following columns: 'Gene.ID', 'Chr', 'Start', 'End', 'Strand', and 'Type'! Please check your gff file format!"))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("gff file should contain at least the following columns: 'Gene.ID', 'Chr', 'Start', 'End', 'Strand', and 'Type'! Please check your gff file format!")
  }
  gff$Start = as.integer(gff$Start);gff$End = as.integer(gff$End)
  
  ## database read in 
  if(dir.exists(database)){
    database.dir = paste0(dir.path, "/", database, list.files(paste0(dir.path, "/", database)))
    if(length(database.dir) == 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
    }
    if(length(database.dir) > 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
      for(i in 2:length(database.dir)){
        temp = readDNAStringSet(database.dir[i], format = "fasta")
        DNAseq = append(DNAseq, temp)
      }
    }
  }
  
  ## sequence extraction
  if(file.exists(geneName)){
    if(length(grep(".csv|.txt", geneName)) == 1){
      geneList = fread(paste0(dir.path, "/", geneName), header = T, fill = TRUE)
    }
    if(length(grep(".xlsx", geneName)) == 1){
      geneList = data.frame(read.xlsx(paste0(dir.path, "/", geneName), header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
    }
    
    # file checking
    if(length(grep("^Gene.ID$", names(geneList))) != 1){
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0("Program is stopped!", " The geneName file should contain 'Gene.ID', please check your input data!"))
      writeLines("######## THE END  ########")
      sink(type = "output")
      stop("The geneName file should contain 'Gene.ID', please check your input data!")
    } 
    if(length(grep("^Type$", names(geneList))) != 1){
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0("Program is stopped!", " The geneName file should contain 'Type', which defines the type of sequence you want to extract, e.g. CDS, promoter, mRNA, all, or NA (equals to all), please check your input data!"))
      writeLines("######## THE END  ########")
      sink(type = "output")
      stop("The geneName file should contain 'Type', which defines the type of sequence you want to extract, e.g. CDS, promoter, mRNA, all, or NA (equals to all), please check your input data!")
    } 
    if(length(grep("^For$", names(geneList))) != 1){
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0("Program is stopped!", " The geneName file should contain 'For', which defines the purpose of sequence you want to extract, e.g. cloning, marker-development, qRT.PCR, please check your input data!"))
      writeLines("######## THE END  ########")
      sink(type = "output")
      stop("The geneName file should contain 'For', which defines the purpose of sequence you want to extract, e.g. cloning, marker-development, qRT.PCR, please check your input data!")
    }
    
    if(nrow(geneList) >= 1){
      # i = 3; j = 1
      for(i in 1:nrow(geneList)){
        gff.temp = gff[grep(geneList$Gene.ID[i], gff$Gene.ID),]
        
        if(!is.null(geneName)){
          if(is.null(For)){
            For = geneList$For[i]
          }else{
            For = For
          }
        }
        
        if(nrow(gff.temp) >= 1){
          temp.list = unique(gff.temp$Gene.ID)
          transcript.list = temp.list[which(nchar(temp.list) == 17)]
          gene.name = temp.list[which(nchar(temp.list) == 15)]
          gff.temp.gene = gff.temp[which(gff.temp$Gene.ID == gene.name),]
          for(j in 1:length(transcript.list)){
            if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j]))){
              dir.create(paste0(dir.path, "/", "Sequence.extraction/","Gene/", transcript.list[j]))
            }
            gff.temp.1 = gff.temp[grep(transcript.list[j], gff.temp$Gene.ID),]
            gff.temp.five_UTR = gff.temp.1[which(gff.temp.1$Type == "five_prime_UTR"), ]
            gff.temp.three_UTR = gff.temp.1[which(gff.temp.1$Type == "three_prime_UTR"), ]
            gff.temp.CDS = gff.temp.1[which(gff.temp.1$Type == "CDS"), ]
            gff.temp.mRNA = gff.temp.1[which(gff.temp.1$Type == "mRNA"), ]
            if(nrow(gff.temp.mRNA) >= 1){
              gff.temp.promoter = gff.temp.mRNA
            }else{
              gff.temp.promoter = gff.temp.gene
            }
            gff.temp.promoter$Type[1] = "promoter"
            if(nrow(gff.temp.mRNA) >= 1){
              if(gff.temp.promoter$Strand[1] == "+"){
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = min(gff.temp.five_UTR$Start) - promoterLength - 1
                  gff.temp.promoter$End[1] = min(gff.temp.five_UTR$Start) - 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.mRNA$Start[1] - promoterLength - 1
                  gff.temp.promoter$End[1] = gff.temp.mRNA$Start[1] - 1
                }
              }else{
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = max(gff.temp.five_UTR$End) + 1
                  gff.temp.promoter$End[1] = max(gff.temp.five_UTR$End) + promoterLength + 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.mRNA$End[1] + 1
                  gff.temp.promoter$End[1] = gff.temp.mRNA$End[1] + promoterLength + 1
                }
              }
            }else{
              if(gff.temp.promoter$Strand[1] == "+"){
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = min(gff.temp.five_UTR$Start) - promoterLength - 1
                  gff.temp.promoter$End[1] = min(gff.temp.five_UTR$Start) - 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.gene$Start[1] - promoterLength - 1
                  gff.temp.promoter$End[1] = gff.temp.gene$Start[1] - 1
                }
              }else{
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = max(gff.temp.five_UTR$End) + 1
                  
                  gff.temp.promoter$End[1] = max(gff.temp.five_UTR$End) + promoterLength + 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.gene$End[1] + 1
                  gff.temp.promoter$End[1] = gff.temp.gene$End[1] + promoterLength + 1
                }
              }
            }
            
            if(!is.null(geneName)){
              if(is.null(type)){
                type = as.character(geneList[i,2])
              }else{
                type = type
              }
            }
            
            if(For == "qRT-PCR" & type != "mRNA"){
              type = "mRNA"
              cat(paste0("\n'For' of ", geneList[i,1], " is 'qRT-PCR', which DOES NOT match by 'type' ", type, " so, 'type' has been corrected into 'mRNA'"))
            }
            
            ## CDS extraction
            if(length(grep("CDS", type)) == 1 | type == "all"){
              if(nrow(gff.temp.CDS) >= 1){
                gff.temp.CDS = gff.temp.CDS[order(gff.temp.CDS$Start),]
                DNAseq.temp = DNAseq[gff.temp.CDS$Chr[1]]
                cds = as.character(subseq(DNAseq.temp, start = gff.temp.CDS$Start[1], end = gff.temp.CDS$End[1]))
                # k = 2
                if(nrow(gff.temp.CDS) >= 2){
                  for(k in 2:nrow(gff.temp.CDS)){
                    cds.temp = as.character(subseq(DNAseq.temp, start = gff.temp.CDS$Start[k], end = gff.temp.CDS$End[k]))
                    cds = paste0(cds, cds.temp)
                  }
                }
                cds.left = as.character(subseq(DNAseq.temp, start = min(gff.temp.CDS$Start) - leftFlanking, end = min(gff.temp.CDS$Start)))
                cds.right = as.character(subseq(DNAseq.temp, start = max(gff.temp.CDS$End), end = max(gff.temp.CDS$End) + rightFlanking))
                cds = paste0(cds.left, cds, cds.right)
                if(gff.temp.gene$Strand[1] == "+"){
                  cds = DNAStringSet(cds)
                }else{
                  cds = reverseComplement(DNAStringSet(cds))
                }
                names(cds) = paste0(transcript.list[j], "_CDS_", gff.temp.CDS$Chr[1], "_", min(gff.temp.CDS$Start), "..", max(gff.temp.CDS$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(cds, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j], "/", transcript.list[j], "_CDS_", gff.temp.CDS$Chr[1], "_", min(gff.temp.CDS$Start), "..", max(gff.temp.CDS$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.CDS$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The CDS of ", transcript.list[j], " has not been defined by GFF file!"))
                sink(type = "output")
                warning(paste0("\nThe CDS of ", transcript.list[j], " has not been defined by GFF file!\n"))
              }
            }
            
            ## mRNA
            if(length(grep("mRNA", type)) == 1 | type == "all"){
              if(nrow(gff.temp.mRNA) >= 1){
                gff.temp.mRNA = rbind(gff.temp.five_UTR, gff.temp.three_UTR, gff.temp.CDS)
                gff.temp.mRNA = gff.temp.mRNA[order(gff.temp.mRNA$Start),]
                DNAseq.temp = DNAseq[gff.temp.mRNA$Chr[1]]
                mRNA = as.character(subseq(DNAseq.temp, start = gff.temp.mRNA$Start[1], end = gff.temp.mRNA$End[1]))
                for(k in 2:nrow(gff.temp.mRNA)){
                  mRNA.temp = as.character(subseq(DNAseq.temp, start = gff.temp.mRNA$Start[k], end = gff.temp.mRNA$End[k]))
                  mRNA = paste0(mRNA, mRNA.temp)
                }
                mRNA.left = as.character(subseq(DNAseq.temp, start = min(gff.temp.mRNA$Start) - leftFlanking, end = min(gff.temp.mRNA$Start)))
                mRNA.right = as.character(subseq(DNAseq.temp, start = max(gff.temp.mRNA$End), end = max(gff.temp.mRNA$End) + rightFlanking))
                mRNA = paste0(mRNA.left, mRNA, mRNA.right)
                if(gff.temp.gene$Strand[1] == "+"){
                  mRNA = DNAStringSet(mRNA)
                }else{
                  mRNA = reverseComplement(DNAStringSet(mRNA))
                }
                names(mRNA) = paste0(transcript.list[j], "_mRNA_", gff.temp.mRNA$Chr[1], "_", min(gff.temp.mRNA$Start), "..", max(gff.temp.mRNA$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(mRNA, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j], "/", transcript.list[j], "_mRNA_", gff.temp.mRNA$Chr[1], "_", min(gff.temp.mRNA$Start), "..", max(gff.temp.mRNA$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.mRNA$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The mRNA of ", transcript.list[j], " has not been defined by GFF file, probably CDS sequence of this gene could be regarded as mRNA!"))
                sink(type = "output")
                warning(paste0("\nThe mRNA of ", transcript.list[j], " has not been defined by GFF file, probably CDS sequence of this gene could be regarded as mRNA!"))
              }
            }
            
            ## gene sequence
            if(length(grep("gene", type)) == 1 | type == "all"){
              if(nrow(gff.temp.gene) >= 1){
                DNAseq.temp = DNAseq[gff.temp.gene$Chr[1]]
                gene = as.character(subseq(DNAseq.temp, start = gff.temp.gene$Start[1], end = gff.temp.gene$End[1]))
                gene.left = as.character(subseq(DNAseq.temp, start = gff.temp.gene$Start[1] - leftFlanking, end = gff.temp.gene$Start[1]))
                gene.right = as.character(subseq(DNAseq.temp, start = gff.temp.gene$End[1], end = gff.temp.gene$End[1] + rightFlanking))
                gene = paste0(gene.left, gene, gene.right)
                if(gff.temp.gene$Strand[1] == "+"){
                  gene = DNAStringSet(gene)
                }else{
                  gene = reverseComplement(DNAStringSet(gene))
                }
                names(gene) = paste0(transcript.list[j], "_gene_", gff.temp.gene$Chr[1], "_", gff.temp.gene$Start[1], "..", gff.temp.gene$End[1], "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(gene, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j], "/", transcript.list[j], "_gene_", gff.temp.gene$Chr[1], "_", gff.temp.gene$Start[1], "..", gff.temp.gene$End[1], "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.gene$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The 'gene' of ", transcript.list[j], " has not been defined by GFF file, probably something went wrong!"))
                sink(type = "output")
                warning(paste0("\nThe 'gene' of ", transcript.list[j], " has not been defined by GFF file, probably something went wrong!"))
              }
            }
            
            ## promoter sequence
            if(length(grep("promoter", type)) == 1 | type == "all"){
              if(nrow(gff.temp.promoter) >= 1){
                DNAseq.temp = DNAseq[gff.temp.promoter$Chr[1]]
                promoter = as.character(subseq(DNAseq.temp, start = gff.temp.promoter$Start[1] - leftFlanking, end = gff.temp.promoter$End[1] + rightFlanking))
                if(gff.temp.promoter$Strand[1] == "+"){
                  promoter = DNAStringSet(promoter)
                }else{
                  promoter = reverseComplement(DNAStringSet(promoter))
                }
                names(promoter) = paste0(transcript.list[j], "_promoter_", gff.temp.promoter$Chr[1], "_", min(gff.temp.promoter$Start), "..", max(gff.temp.promoter$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(promoter, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j], "/", transcript.list[j], "_promoter_", gff.temp.promoter$Chr[1], "_", min(gff.temp.promoter$Start), "..", max(gff.temp.promoter$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.promoter$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The promoter of ", transcript.list[j], " could not be defined based on GFF file, probably something went wrong!"))
                sink(type = "output")
                warning(paste0("\nThe promoter of ", transcript.list[j], " could not be defined based on GFF file, probably something went wrong!"))
              }
            }
              
              ## five prime UTR
              if(length(grep("five_prime_UTR", type)) == 1 | type == "all"){
                if(nrow(gff.temp.five_UTR) >= 1){
                  gff.temp.five_UTR = gff.temp.five_UTR[order(gff.temp.five_UTR$Start),]
                  DNAseq.temp = DNAseq[gff.temp.five_UTR$Chr[1]]
                  five = as.character(subseq(DNAseq.temp, start = gff.temp.five_UTR$Start[1], end = gff.temp.five_UTR$End[1]))
                  if(nrow(gff.temp.five_UTR) >= 2){
                    for(k in 2:nrow(gff.temp.five_UTR)){
                      five.temp = as.character(subseq(DNAseq.temp, start = gff.temp.five_UTR$Start[k], end = gff.temp.five_UTR$End[k]))
                      five = paste0(five, five.temp)
                    }
                  }
                  five.left = as.character(subseq(DNAseq.temp, start = min(gff.temp.five_UTR$Start) - leftFlanking, end = min(gff.temp.five_UTR$Start)))
                  five.right = as.character(subseq(DNAseq.temp, start = max(gff.temp.five_UTR$End), end = max(gff.temp.five_UTR$End) + rightFlanking))
                  five = paste0(five.left, five, five.right)
                  if(gff.temp.five_UTR$Strand[1] == "+"){
                    five = DNAStringSet(five)
                  }else{
                    five = reverseComplement(DNAStringSet(five))
                  }
                  names(five) = paste0(transcript.list[j], "_five.prime.UTR_", gff.temp.five_UTR$Chr[1], "_", min(gff.temp.five_UTR$Start), "..", max(gff.temp.five_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                  writeXStringSet(five, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j], "/", transcript.list[j], "_five.prime.UTR_", gff.temp.five_UTR$Chr[1], "_", min(gff.temp.five_UTR$Start), "..", max(gff.temp.five_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.five_UTR$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
                }else{
                  sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                  writeLines(paste0("Warning: ", "The five_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
                  sink(type = "output")
                  warning(paste0("\nThe five_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
                }
              }
              
              ## three prime UTR
              if(length(grep("three_prime_UTR", type)) == 1 | type == "all"){
                if(nrow(gff.temp.three_UTR) >= 1){
                  gff.temp.three_UTR = gff.temp.three_UTR[order(gff.temp.three_UTR$Start),]
                  DNAseq.temp = DNAseq[gff.temp.three_UTR$Chr[1]]
                  three = as.character(subseq(DNAseq.temp, start = gff.temp.three_UTR$Start[1], end = gff.temp.three_UTR$End[1]))
                  if(nrow(gff.temp.three_UTR) >= 2){
                    for(k in 2:nrow(gff.temp.three_UTR)){
                      three.temp = as.character(subseq(DNAseq.temp, start = gff.temp.three_UTR$Start[k], end = gff.temp.three_UTR$End[k]))
                      three = paste0(three, three.temp)
                    }
                  }
                  three.left = as.character(subseq(DNAseq.temp, start = min(gff.temp.three_UTR$Start) - leftFlanking, end = min(gff.temp.three_UTR$Start)))
                  three.right = as.character(subseq(DNAseq.temp, start = max(gff.temp.three_UTR$End), end = max(gff.temp.three_UTR$End) + rightFlanking))
                  three = paste0(three.left, three, three.right)
                  if(gff.temp.three_UTR$Strand[1] == "+"){
                    three = DNAStringSet(three)
                  }else{
                    three = reverseComplement(DNAStringSet(three))
                  }
                  names(three) = paste0(transcript.list[j], "_three.prime.UTR_", gff.temp.three_UTR$Chr[1], "_", min(gff.temp.three_UTR$Start), "..", max(gff.temp.three_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                  writeXStringSet(three, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j], "/", transcript.list[j], "_three.prime.UTR_", gff.temp.three_UTR$Chr[1], "_", min(gff.temp.three_UTR$Start), "..", max(gff.temp.three_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.three_UTR$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
                }else{
                  sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                  writeLines(paste0("Warning: ", "The three_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
                  sink(type = "output")
                  warning(paste0("\nThe three_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
                }
              }
            }
        }else{
          sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
          writeLines(paste0("Warning: ", "The ", geneList$Gene.ID[i], " has not been defined by GFF file!"))
          sink(type = "output")
          warning(paste0("\nThe ", geneList$Gene.ID[i], " has not been defined by GFF file!"))
          next;
         }
        }
      }
    }

  if(!file.exists(geneName)){
    gene.temp = str_extract_all(geneName, "Glyma.[0-9][0-9]G[0-9][0-9][0-9][0-9][0-9][0-9]")
    if(is.null(For)) For = "Cloning"
    if(is.null(type)){
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0("Warning: ", " 'type' is missing!", ". Dafault value of 'all' is assigned to 'type'!"))
      sink(type = "output")
      type = "all"
    } 
    
    geneList = c()
    geneList.c = c()
    for(i in 1:length(gene.temp)){
      geneList = c(geneList, gene.temp[[i]])
      geneList.c = paste0(geneList.c, "; ", gene.temp[[i]])
    }
    geneList.c = gsub("^; ", "", geneList.c)
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0("\nGene List: ", geneList.c))
    writeLines(paste0("\tType: ", type))
    writeLines(paste0("\tPromoterLength: ", promoterLength, "bp"))
    writeLines(paste0("\tleftFlanking: ", leftFlanking, "bp"))
    writeLines(paste0("\trightFlanking: ", rightFlanking, "bp"))
    sink(type = "output")
    
    if(length(geneList) >= 1){
      # i = 1; j = 1
      for(i in 1:length(geneList)){
        gff.temp = gff[grep(geneList[i], gff$Gene.ID),]
        if(For == "qRT-PCR" & type != "mRNA"){
          type = "mRNA"
          cat(paste0("'For' of ", geneList[i,1], " is 'qRT-PCR', which DOES NOT match by 'type' ", type, " so, 'type' has been corrected into 'mRNA'"))
        }
        if(nrow(gff.temp) >= 1){
          temp.list = unique(gff.temp$Gene.ID)
          transcript.list = temp.list[which(nchar(temp.list) == 17)]
          gene.name = temp.list[which(nchar(temp.list) == 15)]
          gff.temp.gene = gff.temp[which(gff.temp$Gene.ID == gene.name),]
          for(j in 1:length(transcript.list)){
            if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j]))){
              dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j]))
            }
            gff.temp.1 = gff.temp[grep(transcript.list[j], gff.temp$Gene.ID),]
            gff.temp.five_UTR = gff.temp.1[which(gff.temp.1$Type == "five_prime_UTR"), ]
            gff.temp.three_UTR = gff.temp.1[which(gff.temp.1$Type == "three_prime_UTR"), ]
            gff.temp.CDS = gff.temp.1[which(gff.temp.1$Type == "CDS"), ]
            gff.temp.mRNA = gff.temp.1[which(gff.temp.1$Type == "mRNA"), ]
            if(nrow(gff.temp.mRNA) >= 1){
              gff.temp.promoter = gff.temp.mRNA
            }else{
              gff.temp.promoter = gff.temp.gene
            }
            gff.temp.promoter$Type = "promoter"
            if(nrow(gff.temp.mRNA) >= 1){
              if(gff.temp.promoter$Strand[1] == "+"){
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = min(gff.temp.five_UTR$Start) - promoterLength - 1
                  gff.temp.promoter$End[1] = min(gff.temp.five_UTR$Start) - 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.mRNA$Start[1] - promoterLength - 1
                  gff.temp.promoter$End[1] = gff.temp.mRNA$Start[1] - 1
                }
              }else{
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = max(gff.temp.five_UTR$End) + 1
                  
                  gff.temp.promoter$End[1] = max(gff.temp.five_UTR$End) + promoterLength + 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.mRNA$End[1] + 1
                  gff.temp.promoter$End[1] = gff.temp.mRNA$End[1] + promoterLength + 1
                }
              }
            }else{
              if(gff.temp.promoter$Strand[1] == "+"){
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = min(gff.temp.five_UTR$Start) - promoterLength - 1
                  gff.temp.promoter$End[1] = min(gff.temp.five_UTR$Start) - 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.gene$Start[1] - promoterLength - 1
                  gff.temp.promoter$End[1] = gff.temp.gene$Start[1] - 1
                }
              }else{
                if(length(grep("five_prime_UTR", gff.temp.five_UTR$Type)) >= 1){
                  gff.temp.promoter$Start[1] = max(gff.temp.five_UTR$End) + 1
                  
                  gff.temp.promoter$End[1] = max(gff.temp.five_UTR$End) + promoterLength + 1
                }else{
                  gff.temp.promoter$Start[1] = gff.temp.gene$End[1] + 1
                  gff.temp.promoter$End[1] = gff.temp.gene$End[1] + promoterLength + 1
                }
              }
            }
            
            ## CDS extraction
            if(length(grep("CDS", type)) == 1 | type == "all"){
              if(nrow(gff.temp.CDS) >= 1){
                gff.temp.CDS = gff.temp.CDS[order(gff.temp.CDS$Start),]
                DNAseq.temp = DNAseq[gff.temp.CDS$Chr[1]]
                cds = as.character(subseq(DNAseq.temp, start = gff.temp.CDS$Start[1], end = gff.temp.CDS$End[1]))
                # k = 2
                if(nrow(gff.temp.CDS) >= 2){
                  for(k in 2:nrow(gff.temp.CDS)){
                    cds.temp = as.character(subseq(DNAseq.temp, start = gff.temp.CDS$Start[k], end = gff.temp.CDS$End[k]))
                    cds = paste0(cds, cds.temp)
                  }
                }
                cds.left = as.character(subseq(DNAseq.temp, start = gff.temp.CDS$Start[k] - leftFlanking, end = gff.temp.CDS$Start[k]))
                cds.right = as.character(subseq(DNAseq.temp, start = gff.temp.CDS$End[k], end = gff.temp.CDS$End[k] + rightFlanking))
                cds = paste0(cds.left, cds, cds.right)
                if(gff.temp.gene$Strand[1] == "+"){
                  cds = DNAStringSet(cds)
                }else{
                  cds = reverseComplement(DNAStringSet(cds))
                }
                names(cds) = paste0(transcript.list[j], "_CDS_", gff.temp.CDS$Chr[1], "_", min(gff.temp.CDS$Start), "..", max(gff.temp.CDS$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(cds, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j], "/", transcript.list[j], "_CDS_", gff.temp.CDS$Chr[1], "_", min(gff.temp.CDS$Start), "..", max(gff.temp.CDS$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.CDS$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The CDS of ", transcript.list[j], " has not been defined by GFF file!"))
                sink(type = "output")
                warning(paste0("\nThe CDS of ", transcript.list[j], " has not been defined by GFF file!"))
              }
            }
            
            ## mRNA
            if(length(grep("mRNA", type)) == 1 | type == "all"){
              if(nrow(gff.temp.mRNA) >= 1){
                gff.temp.mRNA = rbind(gff.temp.five_UTR, gff.temp.three_UTR, gff.temp.CDS)
                gff.temp.mRNA = gff.temp.mRNA[order(gff.temp.mRNA$Start),]
                gff.temp.mRNA$Start = as.integer(gff.temp.mRNA$Start)
                gff.temp.mRNA$End = as.integer(gff.temp.mRNA$End)
                DNAseq.temp = DNAseq[gff.temp.mRNA$Chr[1]]
                mRNA = as.character(subseq(DNAseq.temp, start = gff.temp.mRNA$Start[1], end = gff.temp.mRNA$End[1]))
                for(k in 2:nrow(gff.temp.mRNA)){
                  mRNA.temp = as.character(subseq(DNAseq.temp, start = gff.temp.mRNA$Start[k], end = gff.temp.mRNA$End[k]))
                  mRNA = paste0(mRNA, mRNA.temp)
                }
                mRNA.left = as.character(subseq(DNAseq.temp, start = min(gff.temp.mRNA$Start) - leftFlanking, end = min(gff.temp.mRNA$Start)))
                mRNA.right = as.character(subseq(DNAseq.temp, start = max(gff.temp.mRNA$End), end = max(gff.temp.mRNA$End) + rightFlanking))
                mRNA = paste0(mRNA.left, mRNA, mRNA.right)
                if(gff.temp.gene$Strand[1] == "+"){
                  mRNA = DNAStringSet(mRNA)
                }else{
                  mRNA = reverseComplement(DNAStringSet(mRNA))
                }
                names(mRNA) = paste0(transcript.list[j], "_mRNA_", gff.temp.mRNA$Chr[1], "_", min(gff.temp.mRNA$Start), "..", max(gff.temp.mRNA$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(mRNA, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j], "/", transcript.list[j], "_mRNA_", gff.temp.mRNA$Chr[1], "_", min(gff.temp.mRNA$Start), "..", max(gff.temp.mRNA$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.mRNA$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The mRNA of ", transcript.list[j], " has not been defined by GFF file, probably CDS sequence of this gene could be regarded as mRNA!"))
                sink(type = "output")
                warning(paste0("\nThe mRNA of ", transcript.list[j], " has not been defined by GFF file, probably CDS sequence of this gene could be regarded as mRNA!"))
              }
            }
            
            ## gene sequence
            if(length(grep("gene", type)) == 1 | type == "all"){
              if(nrow(gff.temp.gene) >= 1){
                DNAseq.temp = DNAseq[gff.temp.gene$Chr[1]]
                gene = as.character(subseq(DNAseq.temp, start = gff.temp.gene$Start[1], end = gff.temp.gene$End[1]))
                gene.left = as.character(subseq(DNAseq.temp, start = gff.temp.gene$Start[1] - leftFlanking, end = gff.temp.gene$Start[1]))
                gene.right = as.character(subseq(DNAseq.temp, start = gff.temp.gene$End[1], end = gff.temp.gene$End[1] + rightFlanking))
                gene = paste0(gene.left, gene, gene.right)
                if(gff.temp.gene$Strand[1] == "+"){
                  gene = DNAStringSet(gene)
                }else{
                  gene = reverseComplement(DNAStringSet(gene))
                }
                names(gene) = paste0(transcript.list[j], "_gene_", gff.temp.gene$Chr[1], "_", gff.temp.gene$Start[1], "..", gff.temp.gene$End[1], "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(gene, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j], "/", transcript.list[j], "_gene_", gff.temp.gene$Chr[1], "_", gff.temp.gene$Start[1], "..", gff.temp.gene$End[1], "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.gene$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The gene of ", transcript.list[j], " has not been defined by GFF file, probably something went wrong!"))
                sink(type = "output")
                warning(paste0("\nThe gene of ", transcript.list[j], " has not been defined by GFF file, probably something went wrong!"))
              }
            }
            
            ## promoter sequence
            if(length(grep("promoter", type)) == 1 | type == "all"){
              if(nrow(gff.temp.promoter) >= 1){
                DNAseq.temp = DNAseq[gff.temp.promoter$Chr[1]]
                promoter = as.character(subseq(DNAseq.temp, start = gff.temp.promoter$Start[1], end = gff.temp.promoter$End[1]))
                promoter = as.character(subseq(DNAseq.temp, start = gff.temp.promoter$Start[1] - leftFlanking, end = gff.temp.promoter$End[1] + rightFlanking))
                if(gff.temp.promoter$Strand[1] == "+"){
                  promoter = DNAStringSet(promoter)
                }else{
                  promoter = reverseComplement(DNAStringSet(promoter))
                }
                names(promoter) = paste0(transcript.list[j], "_promoter_", gff.temp.promoter$Chr[1], "_", min(gff.temp.promoter$Start), "..", max(gff.temp.promoter$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(promoter, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j], "/", transcript.list[j], "_promoter_", gff.temp.promoter$Chr[1], "_", min(gff.temp.promoter$Start), "..", max(gff.temp.promoter$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.promoter$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The promoter of ", transcript.list[j], " could not be defined based on GFF file, probably something went wrong!"))
                sink(type = "output")
                warning(paste0("\nThe promoter of ", transcript.list[j], " could not be defined based on GFF file, probably something went wrong!"))
              }
            }
            
            ## five prime UTR
            if(length(grep("five_prime_UTR", type)) == 1 | type == "all"){
              if(nrow(gff.temp.five_UTR) >= 1){
                gff.temp.five_UTR = gff.temp.five_UTR[order(gff.temp.five_UTR$Start),]
                DNAseq.temp = DNAseq[gff.temp.five_UTR$Chr[1]]
                five = as.character(subseq(DNAseq.temp, start = min(gff.temp.five_UTR$Start[1]), end = max(gff.temp.five_UTR$End[1])))
                if(nrow(gff.temp.five_UTR) >= 2){
                  for(k in 2:nrow(gff.temp.five_UTR)){
                    five.temp = as.character(subseq(DNAseq.temp, start = min(gff.temp.five_UTR$Start[k]), end = max(gff.temp.five_UTR$End[k])))
                    five = paste0(five, five.temp)
                  }
                }
                five.left = as.character(subseq(DNAseq.temp, start = min(gff.temp.five_UTR$Start) - leftFlanking, end = min(gff.temp.five_UTR$Start)))
                five.right = as.character(subseq(DNAseq.temp, start = max(gff.temp.five_UTR$End), end = max(gff.temp.five_UTR$End) + rightFlanking))
                five = paste0(five.left, five, five.right)
                if(gff.temp.five_UTR$Strand[1] == "+"){
                  five = DNAStringSet(five)
                }else{
                  five = reverseComplement(DNAStringSet(five))
                }
                names(five) = paste0(transcript.list[j], "_five.prime.UTR_", gff.temp.five_UTR$Chr[1], "_", min(gff.temp.five_UTR$Start), "..", max(gff.temp.five_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(five, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j], "/", transcript.list[j], "_five.prime.UTR_", gff.temp.five_UTR$Chr[1], "_", min(gff.temp.five_UTR$Start), "..", max(gff.temp.five_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.five_UTR$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The five_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
                sink(type = "output")
                warning(paste0("\nThe five_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
              }
            }
            
            ## three prime UTR
            if(length(grep("three_prime_UTR", type)) == 1 | type == "all"){
              if(nrow(gff.temp.three_UTR) >= 1){
                gff.temp.three_UTR = gff.temp.three_UTR[order(gff.temp.three_UTR$Start),]
                DNAseq.temp = DNAseq[gff.temp.three_UTR$Chr[1]]
                three = as.character(subseq(DNAseq.temp, start = gff.temp.three_UTR$Start[1], end = gff.temp.three_UTR$End[1]))
                if(nrow(gff.temp.three_UTR) >= 2){
                  for(k in 2:nrow(gff.temp.three_UTR)){
                    three.temp = as.character(subseq(DNAseq.temp, start = gff.temp.three_UTR$Start[k], end = gff.temp.three_UTR$End[k]))
                    three = paste0(three, three.temp)
                  }
                }
                three.left = as.character(subseq(DNAseq.temp, start = min(gff.temp.three_UTR$Start) - leftFlanking, end = min(gff.temp.three_UTR$Start)))
                three.right = as.character(subseq(DNAseq.temp, start = max(gff.temp.three_UTR$End), end = max(gff.temp.three_UTR$End) + rightFlanking))
                three = paste0(three.left, three, three.right)
                if(gff.temp.three_UTR$Strand[1] == "+"){
                  three = DNAStringSet(three)
                }else{
                  three = reverseComplement(DNAStringSet(three))
                }
                names(three) = paste0(transcript.list[j], "_three.prime.UTR_", gff.temp.three_UTR$Chr[1], "_", min(gff.temp.three_UTR$Start), "..", max(gff.temp.three_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_for.", For)
                writeXStringSet(three, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Gene/", transcript.list[j], "/", transcript.list[j], "_three.prime.UTR_", gff.temp.three_UTR$Chr[1], "_", min(gff.temp.three_UTR$Start), "..", max(gff.temp.three_UTR$End), "_leftFlanking.", leftFlanking, "_rightFlanking.", rightFlanking, "_strand(", gff.temp.three_UTR$Strand[1], ")", "_for.", For, ".fasta"), compress = FALSE)
              }else{
                sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
                writeLines(paste0("Warning: ", "The three_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
                sink(type = "output")
                warning(paste0("\nThe three_prime_UTR of ", transcript.list[j], " has not been defined by GFF file!"))
              }
            }
          }
        }else{
          sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
          writeLines(paste0("Warning: ", "The ", geneList[i], " has not been defined by GFF file!"))
          sink(type = "output")
          warning(paste0("\nThe ", geneList[i], " has not been defined by GFF file!"))
          next;
        }
      }
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0("\nSequence extraction parameters for: ", geneList[i]))
      writeLines(paste0("\tType: ", type))
      sink(type = "output")
    }
  }
  sink(paste0(dir.path, "/", "Sequence.extraction/", "Gene/", "gene.seq.extraction.log"), type = "output", append = TRUE)
  writeLines("\n######## THE END  ########")
  sink(type = "output")
  cat("\nCongratulation! gene.seq.extraction is DONE!\n")
}
