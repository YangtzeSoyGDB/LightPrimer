
#' This is some description of this function.
#' @title to extract fragment sequence from genome based on an input file defining certain parameters. 
#'
#' @description By using this package, you could use function of fragment.seq.extraction.1 to extract fragment sequence from genome based on an input file defining certain parameters. 'fragment' is defined as a fragment sequence other than annotated gene, however a annotated gene could be regarded as a fragment as well.
#'
#' @details see above
#'
#' @param fragmentFile: fragment file, including at least 'Fragment.ID', 'Chr', 'Start', 'End', 'Strand', 'Length', 'leftFlanking', 'rightFlanking', of which 'Fragment.ID', 'Chr', 'Start' and 'End' are required to be specified. The program would assign default value of '+', 'end - start', 200, and 200 for 'Strand', 'Length', 'leftFlanking', and 'rightFlanking' respectively. This file could be in format of *.csv, .txt, .xlsx, if .xlsx format was used parameters should be put in 'Sheet1' as default.
#' @param database: folder or file contains genome sequence in fasta format.
#' @param For: string to indicate the purpose of sequence extraction. Default value is 'Cloning'.
#' @return fasta files, log file stored in ".../Sequence.extraction/Fragment/"
#' @export fragment.seq.extraction.1
#' @examples fragment.seq.extraction.1(database = "./soybean.genome/", fragmentFile = "./fragment.seq.extraction.parameter.xlsx")
#' 

###### NOTES ######
# fragment.seq.extraction.1.R is to extract sequence from database from a file
######  END  ######


# fragment.seq.extraction.1(database = "./soybean.genome/", fragmentFile = "./fragment.seq.extraction.parameter.xlsx")

fragment.seq.extraction.1 = function(database = NULL, fragmentFile = NULL, For = NULL, ...){
  
  library(data.table)
  library(Biostrings)
  library(stringr)
  
  dir.path = getwd()
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction"))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction"))
  }
  if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/", "Fragment"))){
    dir.create(paste0(dir.path, "/", "Sequence.extraction/", "Fragment"))
  }
  
  sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
  writeLines("\n######## Fragment Sequence Extraction  ########")
  writeLines(paste0("\nDate: ", date()))
  writeLines(paste0("Information source: fragment file\n"))
  sink(type = "output")
  
  if(is.null(fragmentFile)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0('Program is stopped! fragmentFile is required!'))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'fragmentFile' is required!")
  } 
  if(is.null(database)){
    sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
    writeLines(paste0('Program is stopped! Database is required!'))
    writeLines("######## THE END  ########")
    sink(type = "output")
    stop("'database' is required!\n")
  } 
  if(is.null(For)) For = "Cloning"
  
  ## database read in 
  if(dir.exists(database)){
    database.dir = paste0(dir.path, "/", database, list.files(paste0(dir.path, "/", database)))
    if(length(database.dir) == 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
    }
    if(length(database.dir) > 1){
      DNAseq = readDNAStringSet(database.dir[1], format = "fasta")
      for(i in 2:length(database.dir)){
        temp = readDNAStringSet(database.dir[i], format = "fasta")
        DNAseq = append(DNAseq, temp)
      }
    }
  }
  if(!dir.exists(database)){
    DNAseq = readDNAStringSet(database, format = "fasta")
  }
  
  ## fragmentFile read in 
  if(file.exists(fragmentFile)){
    if(length(grep(".csv|.txt", fragmentFile)) == 1){
      fragmentList = fragmentList = fread(paste0(dir.path, "/", fragmentFile), header = T, sep = "\t", fill = TRUE)
      if(ncol(fragmentList) == 1){
        fragmentList = fread(paste0(dir.path, "/", fragmentFile), header = T, sep = ",", fill = TRUE)
        if(ncol(fragmentList) == 1){
          fragmentList = fread(paste0(dir.path, "/", fragmentFile), header = T, sep = " ", fill = TRUE)
        }
      }
    }
    if(length(grep(".xlsx", fragmentFile)) == 1){
      fragmentList = data.frame(read.xlsx(paste0(dir.path, "/", fragmentFile), header = T, stringsAsFactors = F, sheetName= "Sheet1", encoding="UTF-8"))
    }
    if(length(grep("Fragment.ID|Chr|Start|End", names(fragmentList))) != 4){
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0('Program is stopped! The fragmentFile should contain at least: Fragment.ID, Chr, Start, End, Strand, Length, leftFlanking, rightFlanking, please check your input data!'))
      writeLines("######## THE END  ########")
      sink(type = "output")
      stop("the 'fragmentFile' should contain at least 'Fragment.ID', 'Chr', 'Start', and 'End', please check your input data!\n")
    }else{
      cat("The format of 'fragmentFile' file is correct!\n")
    }
  }
  
  fragmentFile.name = gsub(".csv|.txt|.xlsx", "", strsplit(fragmentFile, "/")[[1]][length(strsplit(fragmentFile, "/")[[1]])])
  
  ## sequence extraction
  if(nrow(fragmentList) >= 1){
      # i = 1
    for(i in 1:nrow(fragmentList)){
      # parameter checking
      if(is.null(fragmentList$Fragment.ID[i])  | setequal(NA, fragmentList$Fragment.ID[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0('Program is stopped!', " 'Fragment.ID' is missing in row ", i, " of ", fragmentFile.name, "."))
        writeLines("######## THE END  ########")
        sink(type = "output")
       stop(paste0("'Fragment.ID' is missing in row ", i, " of ", fragmentFile.name, "\n"))
      }else{
        fragmentID = fragmentList$Fragment.ID[i]
        if(!dir.exists(paste0(dir.path, "/", "Sequence.extraction/Fragment/", fragmentID))){
          dir.create(paste0(dir.path, "/", "Sequence.extraction/Fragment/", fragmentID))
        }
      }
      
      if(is.null(fragmentList$Chr[i]) | setequal(NA, fragmentList$Chr[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0('Program is stopped!', " 'Chr' is missing in row ", i, " of ", fragmentFile.name, "."))
        writeLines("######## THE END  ########")
        sink(type = "output")
        stop(paste0("'Chr' is missing in row ", i, " of ", fragmentFile.name, "\n"))
      }else{
        chr = fragmentList$Chr[i]
        chr.format = names(DNAseq)[1]
        chr.format = str_extract_all(chr.format, "(Chr|Gm)")[[1]]
        if(length(grep(chr.format, chr)) == 0){
          if(is.numeric(chr)){
            chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
          }else{
            chr = as.numeric(gsub("Chr|Gm", "", chr))
            chr = paste0(chr.format, ifelse(chr < 10, paste0("0", chr), chr))
          }
        }
      }
      
      if(is.null(fragmentList$Start[i]) | setequal(NA, fragmentList$Start[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0('Program is stopped!', " 'Start' is missing in row ", i, " of ", fragmentFile.name, "."))
        writeLines("######## THE END  ########")
        sink(type = "output")
        stop(paste0("'Start' is missing in row ", i, " of ", fragmentFile.name, "\n"))
      }else{start = fragmentList$Start[i]}
      
      if(is.null(fragmentList$End[i]) | setequal(NA, fragmentList$End[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0('Program is stopped!', " 'End' is missing in row ", i, " of ", fragmentFile.name, "."))
        writeLines("######## THE END  ########")
        sink(type = "output")
        stop(paste0("'End' is missing in row ", i, " of ", fragmentFile.name, "\n"))
      }else{end = fragmentList$End[i]}
      
      if(is.null(fragmentList$Strand[i])  | setequal(NA, fragmentList$Strand[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0("Warning: ", "'Strand' is missing in row ", i, " of ", fragmentFile.name, ". Default value of '+' has been assigned to strand!"))
        sink(type = "output")
        warning(paste0("\n'Strand' is missing in row ", i, " of ", fragmentFile.name, ". Default value of '+' has been assigned to strand!\n"))
        strand = "+"
      }else{strand = fragmentList$Strand[i]}
      if(is.null(fragmentList$Length[i]) | setequal(NA,fragmentList$Length[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0("Warning: ", "'Length' is missing in row ", i, " of ", fragmentFile.name, ". Default value of 'Length' is calculated by 'end - start'!"))
        sink(type = "output")
        warning(paste0("\n'Length' is missing in row ", i, " of ", fragmentFile.name, ". Default value of 'Length' is calculated by 'end - start'!\n"))
        length = as.numeric(end) - as.numeric(start)
      }else{length = fragmentList$Length[i]}
      if(is.null(fragmentList$leftFlanking[i]) | setequal(NA, fragmentList$leftFlanking[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0("Warning: ", "'leftFlanking' is missing in row ", i, " of ", fragmentFile.name, ". Default value of 200 has been assigned to leftFlanking of certain fragment!"))
        sink(type = "output")
        warning(paste0("\n'leftFlanking' is missing in row ", i, " of ", fragmentFile.name, ". Default value of 200 has been assigned to leftFlanking of certain fragment!\n"))
        leftFlanking = 200
      }else{
        leftFlanking = fragmentList$leftFlanking[i]
      }
      if(is.null(fragmentList$rightFlanking[i]) | setequal(NA, fragmentList$rightFlanking[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0("Warning: ", "'rightFlanking' is missing in row ", i, " of ", fragmentFile.name, ". Default value of 200 has been assigned to rightFlanking of certain fragment!"))
        sink(type = "output")
        warning(paste0("\n'rightFlanking' is missing in row ", i, " of ", fragmentFile.name, ". Default value of 200 has been assigned to rightFlanking of certain fragment!\n"))
        rightFlanking = 200
      }else{
        rightFlanking = fragmentList$rightFlanking[i]
      }
      if(is.null(fragmentList$For[i]) | setequal(NA, fragmentList$For[i])){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0("Warning: ", "'For' is missing in row ", i, " of ", fragmentFile.name, ". 'Cloning' has been assigned to 'For' as default!"))
        sink(type = "output")
        warning(paste0("\n'For' is missing in row ", i, " of ", fragmentFile.name, ". 'Cloning' has been assigned to 'For' as default!\n"))
        For = "Cloning"
      }else{
        For = fragmentList$For[i]
      }
      
      
      ## specific chromosome sequence separation
      DNAseq.chr = DNAseq[chr]
      if(length(DNAseq.chr) == 0){
        sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
        writeLines(paste0('\nProgram is stopped!', "please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!\n"))
        writeLines("######## THE END  ########")
        sink(type = "output")
        stop("please check whether the 'Chr' parameter in fragmentFile is exactly the same as that of database!\n")
      } 
      
      # seq extraction
      seq = as.character(subseq(DNAseq.chr, start = start - leftFlanking, end = end + rightFlanking))
      seq = DNAStringSet(seq)
      if(strand == "-"){
        seq = reverseComplement(seq)
      }
      names(seq) = paste0(fragmentID, "_", chr, "_", start, "..", end, "_leftFlanking.", leftFlanking,"_rightFlanking.", rightFlanking, "_length.", length, "_for.", For)
      writeXStringSet(seq, filepath = paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", fragmentID, "/", fragmentID, "_", chr, "_", start, "..", end, "_leftFlanking.", leftFlanking,"_rightFlanking.", rightFlanking,  "_length.", length, "_strand(", strand, ")", "_for.", For, ".fasta"), compress = FALSE)
      
      sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
      writeLines(paste0("\nSequence extraction parameters for ", fragmentID, ":"))
      writeLines(paste0("\tChr: ", chr))
      writeLines(paste0("\tStart: ", start))
      writeLines(paste0("\tEnd: ", end))
      writeLines(paste0("\tStrand: ", strand))
      writeLines(paste0("\tLength: ", length))
      writeLines(paste0("\tleftFlanking: ", leftFlanking))
      writeLines(paste0("\trightFlanking: ", rightFlanking))
      writeLines(paste0("\tFor: ", For, "\n"))
      sink(type = "output")
    }
  }
  sink(paste0(dir.path, "/", "Sequence.extraction/", "Fragment/", "fragment.seq.extraction.log"), type = "output", append = TRUE)
  writeLines("\n######## THE END  ########")
  sink(type = "output")
  cat("\nCongratulation! fragment.seq.extraction is DONE!\n")
}


