
#' This is some description of this function.
#' @title to design primers for cloning of certain sequence either genes or fragments
#'
#' @description By using this package, you could use function of primer.designing.for.cloning to design primers for cloning of certain sequence either genes or fragments
#'
#' @details see above
#' 
#' @param seqType: string to indicate type of sequence, which could one of 'Gene', "fragment'.
#' @param seqEvaluation: seqEvaluation folder.
#' @param plotting: logical value indicates whether to plot primers or not.
#' @param TmScope: numeric scope indicates the min and max of primer Tm, default value is 'c(40, 60)'.
#' @param GCScope: numeric scope indicates the min and max of primer GC content (%), default value is 'c(35, 65)'.
#' @param specificityMin: numeric value indicates the minimum standard of sequence specificity (%), default value is 98%.
#' @param countMax: numeric value indicates the maximum standard of counts of this primer mathched to different position on the chromosome, default value is 2.
#' @param endMatch: logical value indicates whether the primer end (3') matched to genome, default value is TRUE
#' @param GCend: logical value indicates whether the primer end (3') should be G:C or not, default value is TRUE
#' @param primerLength: numeric scope indicates the min and max length of primer, default value is 'c(20, 25)'.
#' @param TmMethod: the method to calculate Tm value, which is one or both of 1, or/and 2. 1 presents (G+C)X2+(T+C)X1, wile 2 represents 81.5 + 0.41XGC.content - 600/seq.length. default is both 1 and 2.
#' @param primerStrand: 'F' or 'R', or c('F', 'R')
#' @param Fcolor: color value for forward primers, default is "#B2182B".
#' @param Rcolor: color value for reverse primers, default is "#2166AC".
#' @param lcolor: color value for line connecting forward and reverse primer pairs, default is 'black'.
#' @param leftRegion: the position scope for left primer.
#' @param rightRegion: the position scope for right primer.
#' @return files and folder
#' @export primer.designing.for.cloning
#' @examples primer.designing.for.cloning(seqEvaluation = "./Sequence.evaluation/Genes/Glyma.20G148100.1/", seqType = "Gene", gffFile = "./Wm82.a2.v1.gene.gff")
#' 
#' 

#primer.designing.for.cloning(seqEvaluation = "./Sequence.evaluation/Genes/Glyma.01G010200.1/", seqType = "Gene", gffFile = "./Wm82.a2.v1.gene.gff")

primer.designing.for.cloning = function(seqEvaluation = NULL, gffFile = NULL, plotting = NULL, seqType = NULL, TmScope = NULL, GCScope = NULL, specificityMin = NULL, countMax = NULL, endMatch = NULL, GCend = NULL, primerLength = NULL, TmMethod = NULL, primerStrand = NULL, Fcolor = NULL, Rcolor = NULL, lcolor = NULL, leftRegion = NULL, rightRegion = NULL, ...) {
  
  library(stringr)
  library(seqinr)
  library(Biostrings)
  library(tidyr)
  library(xlsx)
  library(WriteXLS)
  library(data.table)
  library(ggplot2)
  
  dir.path = getwd()
  
  if(!dir.exists(paste0(dir.path, "/", "Designed.primers"))){
    dir.create(paste0(dir.path, "/", "Designed.primers"))
  }
  if(!dir.exists(paste0(dir.path, "/", "Designed.primers/", "Cloning.primers"))){
    dir.create(paste0(dir.path, "/", "Designed.primers/", "Cloning.primers"))
  }
  

  if(is.null(seqEvaluation)) stop("'seqEvaluation' is required!")
  if(is.null(seqType)) stop("'seqType' is required!")
  if(is.null(plotting)) plotting = TRUE
  if(is.null(TmScope)) TmScope = c(40, 60)
  if(is.null(GCScope)) GCScope = c(35, 65)
  if(is.null(countMax)) countMax = 2
  if(is.null(specificityMin)) specificityMin = 98
  if(is.null(endMatch)) endMatch = TRUE
  if(is.null(GCend)) GCend = TRUE
  if(is.null(primerLength)) primerLength = c(20, 25)
  if(is.null(TmMethod)) TmMethod = "both"
  if(is.null(primerStrand)) primerStrand = c('F', 'R')
  if(is.null(plotting)) plotting = TRUE
  if(is.null(Fcolor)) Fcolor = "#B2182B"
  if(is.null(Rcolor)) Rcolor = "#2166AC"
  if(is.null(lcolor)) lcolor = "black"

  
  
  if(!dir.exists(seqEvaluation)){
    stop("'seqEvaluation' should be a folder contains 'Blast.output', 'Splitted.seq', etc., please perform seq.evaluation() analysis before primer designing!\n")
  }
  
  ## file list path classification
  file.list = list.files(paste0(dir.path, "/", seqEvaluation), recursive = TRUE)
  dir = paste0(dir.path, "/", seqEvaluation, file.list)
  dir = dir[-grep(".pdf", dir)]
  seqEval.dir = dir[grep("sequence.evaluation.csv", dir)]
  cloning.dir = seqEval.dir[grep("Cloning|clone|cloning", seqEval.dir)]
  fileName = c()
  # i = 1
  for(i in 1:length(cloning.dir)){
    temp = strsplit(cloning.dir[i], "/")[[1]][length(strsplit(cloning.dir[i], "/")[[1]])]
    temp = strsplit(temp, "_")[[1]][1:2]
    temp = paste0(temp[1], "_", temp[2])
    fileName = c(fileName, temp)
  }
  fileName = unique(fileName)
  
  ## gff file read in
  if(seqType == "Gene" | seqType == "gene" | seqType == "GENE"){
    if(is.null(gffFile)) stop("'gffFile' is required for 'GENE'!")
    gff = fread(gffFile, header = T, fill = T, stringsAsFactors = F, sep = "\t")
    if(ncol(gff) == 1){
      gff = fread(gffFile, header = T, fill = T, stringsAsFactors = F, sep = ",")
      if(ncol(gff) == 1){
        gff = fread(gffFile, header = T, fill = T, stringsAsFactors = F, sep = " ")
      }
    }
  }
  
  # file merging function
  data.merging = function(fileList = NULL, header = NULL, skipRow = NULL, ...){
    library(data.table)
    if(is.null(fileList)) stop("'fileList' in 'data.merging' is required!")
    if(is.null(header)) header = T
    if(is.null(skipRow)) skipRow = 0
    data = fread(fileList[1], header = header, stringsAsFactors = F, sep = "\t", skip = skipRow, fill = T)
    if(ncol(data) == 1){
      data = fread(fileList[1], header = header, stringsAsFactors = F, sep = ",", skip = skipRow, fill = T)
      if(ncol(data) == 1){
        data = fread(fileList[1], header = header, stringsAsFactors = F, sep = " ", skip = skipRow, fill = T)
      }
    }
    for(i in 2:length(fileList)){
      temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = "\t", skip = skipRow, fill = T)
      if(ncol(temp) == 1){
        temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = ",", skip = skipRow, fill = T)
        if(ncol(temp) == 1){
          temp = fread(fileList[i], header = header, stringsAsFactors = F, sep = " ", skip = skipRow, fill = T)
        }
      }
      data = rbind(data, temp)
    }
    return(data)
  }
  # i = 1; j = 3
  for(i in 1:length(fileName)){
    dir.1 = cloning.dir[grep(fileName[i], cloning.dir)]
      overall =  data.merging(fileList = dir.1)
      overall = overall[!duplicated(overall),]
      names(overall) = gsub("\\(.?\\)|\\(5'-3'\\)", "", names(overall))
      setkeyv(overall, names(overall))
      overall.NA = overall[is.na(overall$To),]
      overall = overall[!is.na(overall$From),]
      setkeyv(overall, names(overall))
      
      input.name = strsplit(dir.1[1], "/")[[1]][length(strsplit(dir.1[1], "/")[[1]])]
      input.name = strsplit(input.name, "_")[[1]]
      leftFlanking = as.numeric(strsplit(input.name[grep("leftFlanking", input.name)], "\\.")[[1]][2])
      rightFlanking = as.numeric(strsplit(input.name[grep("rightFlanking", input.name)], "\\.")[[1]][2])
      pos.left = as.numeric(strsplit(input.name[grep("\\.\\.", input.name)], "\\.\\.")[[1]][1])
      pos.right = as.numeric(strsplit(input.name[grep("\\.\\.", input.name)], "\\.\\.")[[1]][2])
      if(is.null(leftRegion)) leftRegion = c(pos.left - leftFlanking, pos.left)
      if(is.null(rightRegion)) rightRegion = c(pos.right, pos.right + rightFlanking)
      
      ## primer selection
      ## Tm filtration
      if(TmMethod == "both"){
        overall.temp1 = overall[which((overall$Tm1 >= TmScope[1] & overall$Tm1 <= TmScope[2]) | (overall$Tm2 >= TmScope[2] & overall$Tm2 <= TmScope[2])),]
        if(nrow(overall.temp1) == 0){
          warning(paste0("\nThe TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation.\n"))
          next
        }
      }
      if(TmMethod == 1){
        overall.temp1 = overall[which(overall$Tm1 >= TmScope[1] & overall$Tm1 <= TmScope[2]),]
        if(nrow(overall.temp1) == 0){
          warning(paste0("\nThe TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation.\n"))
          next
        }
      }
      if(TmMethod == 2){
        overall.temp1 = overall[which(overall$Tm2 >= TmScope[2] & overall$Tm2 <= TmScope[2]),]
        if(nrow(overall.temp1) == 0){
          warning(paste0("\nThe TmScope between ", TmScope[1], " and ", TmScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation.\n"))
          next()
        }
      }
      
      ## GC content filtration
      overall.temp2 = overall.temp1[which(overall.temp1$GC.content >= GCScope[1] & overall.temp1$GC.content <= GCScope[2]),]
      if(nrow(overall.temp2) == 0){
        warning(paste0("\nThe GCScope between ", GCScope[1], " and ", GCScope[2], " is too stringent, a wider scope would be better if it was reasonable in your situation.\n"))
        next()
      }
      
      ## count filtration
      if(!is.null(countMax)){
        overall.temp3 = overall.temp2[which(overall.temp2$Counts <= countMax),]
      }else{
        overall.temp3 = overall.temp2
      }
      
      ## sequence specificity
      if(!is.null(specificityMin)){
        overall.temp4 = overall.temp3[which(overall.temp3$Seq.specificity >= specificityMin),]
      }else{
        overall.temp4 = overall.temp3
      }
      
      overall.temp4 = overall.temp4[order(overall.temp4$From),]
      
      ## basic information outputting
      fwrite(overall.temp4, file = paste0(dir.path, "/", "Designed.primers/Cloning.primers/", fileName[i], "_", overall$Chr[1], "_", min(overall$From), "..", max(overall$To),  ".cloning.primers.passed.filtration.csv"), row.names = F, col.names = T, sep = "\t", na = "NA")
      
      ## region selection
      left = overall.temp4[which(overall.temp4$From >= leftRegion[1] & overall.temp4$To <= leftRegion[2]),]
      right = overall.temp4[which(overall.temp4$From >= rightRegion[1] & overall.temp4$To <= rightRegion[2]),]
      
      if(nrow(left) == 0){
        cat(paste0("\nThere is no primer candidates identified in the left region defined for ", fileName[i], "!\n"))
      }
      if(nrow(right) == 0){
        cat(paste0("\nThere is no primer candidates identified in the right region defined for ", fileName[i], "!\n"))
      }
      
      if(nrow(left) >= 1 & nrow(right) >= 1){
        left = left[,c(1:5)];names(left) = c("seqName1", "seq1", "Chr1", "seqStart1", "seqEnd1")
        right = right[,c(1:5)]; names(right) = c("seqName2", "seq2", "Chr2", "seqStart2", "seqEnd2")
        primer.final = cbind(left, right)
        primer.final$Distance = primer.final$seqStart2 - primer.final$seqEnd1
        if(nrow(primer.final) >= 1){
          if(GCend == TRUE){
            primer.final$seq1endBase = NA
            primer.final$seq2startBase = NA
            for(j in 1:nrow(primer.final)){
              primer.final$seq1endBase[j] = strsplit(primer.final$seq1[j], "")[[1]][length(strsplit(primer.final$seq1[j], "")[[1]])]
              primer.final$seq2startBase[j] = strsplit(primer.final$seq2[j], "")[[1]][1]
            }
            setkeyv(primer.final, names(primer.final))
            primer.final = primer.final[(which(primer.final$seq1endBase == "G" | primer.final$seq1endBase == "C") & (primer.final$seq2startBase == "G" | primer.final$seq2startBase== "C")),]
          }else{
            primer.final = primer.final
          }
        }
        
        primer.final$seq2 = as.character(reverseComplement(DNAStringSet(primer.final$seq2)))
        names(primer.final) = gsub("seq2", "revc.seq2", names(primer.final))
        
        if(nrow(primer.final) >= 1){
          if(primer.final$seqStart1[1] >= primer.final$seqEnd1[1]){
            temp = primer.final$seqStart1
            primer.final$seqStart1 = primer.final$seqEnd1
            primer.final$seqEnd1 = temp
          }
          if(primer.final$seqStart2[1] >= primer.final$seqEnd2[1]){
            temp = primer.final$seqStart2
            primer.final$seqStart2 = primer.final$seqEnd2
            primer.final$seqEnd2 = temp
          }
          ## outputting
          fwrite(primer.final, file = paste0(dir.path, "/", "Designed.primers/Cloning.primers/", fileName[i], "_", overall$Chr[1], "_", min(overall$From), "..", max(overall$To), ".Cloning.primers.final.csv"), row.names = F, col.names = T, sep = "\t", na = "NA")
        }

      ## plotting
      if(plotting == TRUE | plotting == T & nrow(primer.final) >= 1){
        seqName = strsplit(primer.final$seqName1[1], "_")[[1]][1]
        chr = str_extract_all(primer.final$seqName1[1], "(Chr[0-9][0-9])")[[1]]
        if(seqType == "Gene" | seqType == "gene" | seqType == "GENE"){
          Start = as.numeric(strsplit(strsplit(primer.final$seqName1[1], "_")[[1]][4], "\\..")[[1]][1])
          End = as.numeric(strsplit(strsplit(primer.final$seqName1[1], "_")[[1]][4], "\\..")[[1]][2])
          gff.temp1 = gff[which(gff$Gene.ID == seqName & gff$Type != "mRNA"),]
          gff.temp1 = gff.temp1[,c(6,2,3,4)]
          names(gff.temp1) = c("Fragment.Name", "Chr", "Start", "End")
          gff.temp = data.frame(matrix(nrow = 2, ncol = 4))
          names(gff.temp) = c("Fragment.Name", "Chr", "Start", "End")
          gff.temp$Fragment.Name[1:2] = c("leftFlanking", "rightFlanking")
          gff.temp$Chr[1:2] = chr
          gff.temp$Start = c(Start-leftFlanking-1, End+1)
          gff.temp$End = c(Start-1, End + rightFlanking +1)
          gff.temp = rbind(gff.temp, gff.temp1)
          gff.temp = gff.temp[order(gff.temp$Start),]
        }
        if(seqType == "fragment" | seqType == "Fragment" | seqType == "FRAGMENT"){
          Start = as.numeric(strsplit(strsplit(primer.final$seqName1[1], "_")[[1]][3], "\\..")[[1]][1])
          End = as.numeric(strsplit(strsplit(primer.final$seqName1[1], "_")[[1]][3], "\\..")[[1]][2])
          gff.temp = data.frame(matrix(nrow = 3, ncol = 4))
          names(gff.temp) = c("Fragment.Name", "Chr", "Start", "End")
          gff.temp$Fragment.Name[1:3] = c("leftFlanking", seqName, "rightFlanking")
          gff.temp$Chr[1:3] = chr
          gff.temp$Start = c(Start-leftFlanking-1, Start, End+1)
          gff.temp$End = c(Start-1, End, End + rightFlanking +1)
        }
        primer.final$order = seq(1:nrow(primer.final))/10
        primer.final$primerPair = paste0("Pair_", seq(1:nrow(primer.final)), "(", primer.final$Distance, "bp)")
        
        p = ggplot(primer.final, aes(x = seqStart1, y = 0.1*nrow(primer.final))) +
          labs(title = paste0(seqName, " ", chr, ":", Start, "..", End, " cloning primer candidates distribution")) +
          xlab(paste0(chr, ":", min(overall$From), "..", max(overall$To))) +
          theme(axis.ticks.y.left = element_blank(),
                axis.ticks.y = element_blank(),
                axis.line.y = element_blank(),
                axis.line.x.top = element_blank(),
                panel.grid = element_blank(),
                axis.text.y = element_blank(),
                plot.background = element_blank(),
                panel.background = element_blank(),
                axis.title.y = element_blank(),
                axis.line = element_line(colour = "black",size = 0.5))+
          xlim(c(min(overall$From)-leftFlanking, max(overall$To)+rightFlanking)) + ylim(c(-0.1, 0.1*nrow(primer.final) + 0.1)) +
          geom_segment(data = gff.temp, 
                       mapping = aes(x = Start, xend = End, y = -0.1, yend = -0.1, color = Fragment.Name), 
                       size = 4) + 
          geom_segment(data = primer.final,
                       mapping = aes(x = seqEnd1, xend = seqStart2, y = order, yend = order),
                       size = 0.1, color = lcolor) +
          geom_segment(data = primer.final,
                       mapping = aes(x = seqStart1, xend = seqEnd1, y = order, yend = order),
                       arrow = arrow(length = unit(ifelse(nrow(primer.final) <= 2, 0.2/nrow(primer.final), ifelse(nrow(primer.final) > 2 & nrow(primer.final) <= 10, 0.5/nrow(primer.final), ifelse(nrow(primer.final) > 10 & nrow(primer.final) <= 100, 2/nrow(primer.final), ifelse(nrow(primer.final) > 100, 5/nrow(primer.final), 10/nrow(primer.final))))),"cm")),
                       size = ifelse(nrow(primer.final) <= 2, 2/nrow(primer.final), ifelse(nrow(primer.final) > 2 & nrow(primer.final) <= 10, 3/nrow(primer.final), ifelse(nrow(primer.final) > 10 & nrow(primer.final) <= 50, 10/nrow(primer.final), ifelse(nrow(primer.final) > 50, 20/nrow(primer.final), 200/nrow(primer.final))))), color = Fcolor) + 
          geom_segment(data = primer.final,
                       mapping = aes(x = seqEnd2, xend = seqStart2, y = order, yend = order),
                       arrow = arrow(length = unit(ifelse(nrow(primer.final) <= 2, 0.2/nrow(primer.final), ifelse(nrow(primer.final) > 2 & nrow(primer.final) <= 10, 0.5/nrow(primer.final), ifelse(nrow(primer.final) > 10 & nrow(primer.final) <= 100, 2/nrow(primer.final), ifelse(nrow(primer.final) > 100, 5/nrow(primer.final), 10/nrow(primer.final))))),"cm")),
                       size = ifelse(nrow(primer.final) <= 2, 2/nrow(primer.final), ifelse(nrow(primer.final) > 2 & nrow(primer.final) <= 10, 3/nrow(primer.final), ifelse(nrow(primer.final) > 10 & nrow(primer.final) <= 50, 10/nrow(primer.final), ifelse(nrow(primer.final) > 50, 20/nrow(primer.final), 200/nrow(primer.final))))), color = Rcolor) +
          geom_text(data = primer.final, mapping = aes(x = seqEnd2, y = order, label = primerPair),
                    check_overlap = TRUE, 
                    nudge_x = ifelse(nrow(primer.final) <= 2, 120, ifelse(nrow(primer.final) > 2 & nrow(primer.final) <= 10, 75, ifelse(nrow(primer.final) > 10 & nrow(primer.final) <= 100, 70, ifelse(nrow(primer.final) > 100, 65, 60)))), 
                    size = ifelse(nrow(primer.final) <= 2, 2/nrow(primer.final), ifelse(nrow(primer.final) > 2 & nrow(primer.final) <= 10, 10/nrow(primer.final), ifelse(nrow(primer.final) > 10 & nrow(primer.final) <= 100, 50/nrow(primer.final), ifelse(nrow(primer.final) > 100, 80/nrow(primer.final), 100/nrow(primer.final))))))
        p = p + theme(plot.margin=unit(rep(2,4),'lines'))
        pdf(paste0(dir.path, "/", "Designed.primers/Cloning.primers/", fileName[i], "_", overall$Chr[1], "_", min(overall$From), "..", max(overall$To), ".cloning.primers.final.plot.pdf"), width = 10, height = ifelse(nrow(primer.final) <= 2, 3, ifelse(nrow(primer.final) > 2 & nrow(primer.final) <= 10, 5, ifelse(nrow(primer.final) > 10 & nrow(primer.final) <= 100, 10, ifelse(nrow(primer.final) > 100, 15, 20)))))
        print(p)
        dev.off()
      }
        }
      if(plotting == TRUE & nrow(overall.temp4) != 0){
        seqName = strsplit(overall.temp4$Name[1], "_")[[1]][1]
        chr = str_extract_all(overall.temp4$Name[1], "(Chr[0-9][0-9])")[[1]]
        if(seqType == "Gene" | seqType == "gene" | seqType == "GENE"){
          Start = as.numeric(strsplit(strsplit(overall.temp4$Name[1], "_")[[1]][4], "\\..")[[1]][1])
          End = as.numeric(strsplit(strsplit(overall.temp4$Name[1], "_")[[1]][4], "\\..")[[1]][2])
          gff.temp1 = gff[which(gff$Gene.ID == seqName & gff$Type != "mRNA"),]
          gff.temp1 = gff.temp1[,c(6,2,3,4)]
          names(gff.temp1) = c("Fragment.Name", "Chr", "Start", "End")
          gff.temp = data.frame(matrix(nrow = 2, ncol = 4))
          names(gff.temp) = c("Fragment.Name", "Chr", "Start", "End")
          gff.temp$Fragment.Name[1:2] = c("leftFlanking", "rightFlanking")
          gff.temp$Chr[1:2] = chr
          gff.temp$Start = c(Start-leftFlanking-1, End+1)
          gff.temp$End = c(Start-1, End + rightFlanking +1)
          gff.temp = rbind(gff.temp, gff.temp1)
          gff.temp = gff.temp[order(gff.temp$Start),]
        }
        if(seqType == "fragment" | seqType == "Fragment" | seqType == "FRAGMENT"){
          Start = as.numeric(strsplit(strsplit(overall.temp4$Name[1], "_")[[1]][3], "\\..")[[1]][1])
          End = as.numeric(strsplit(strsplit(overall.temp4$Name[1], "_")[[1]][3], "\\..")[[1]][2])
          gff.temp = data.frame(matrix(nrow = 3, ncol = 4))
          names(gff.temp) = c("Fragment.Name", "Chr", "Start", "End")
          gff.temp$Fragment.Name[1:3] = c("leftFlanking", seqName, "rightFlanking")
          gff.temp$Chr[1:3] = chr
          gff.temp$Start = c(Start-leftFlanking-1, Start, End+1)
          gff.temp$End = c(Start-1, End, End + rightFlanking +1)
        }
        overall.temp4$order = seq(1:nrow(overall.temp4))/10
        #overall.temp4$primerPair = paste0("Pair_", seq(1:nrow(overall.temp4)), "(", overall.temp4$Distance, "bp)")
        
        p = ggplot(overall.temp4, aes(x = seqStart1, y = 0.1*nrow(overall.temp4))) +
          labs(title = paste0(seqName, " ", chr, ":", Start, "..", End, " potential primers distribution")) +
          xlab(paste0(chr, ":", min(overall$From), "..", max(overall$To))) +
          theme(axis.ticks.y.left = element_blank(),
                axis.ticks.y = element_blank(),
                axis.line.y = element_blank(),
                axis.line.x.top = element_blank(),
                panel.grid = element_blank(),
                axis.text.y = element_blank(),
                plot.background = element_blank(),
                panel.background = element_blank(),
                axis.title.y = element_blank(),
                axis.line = element_line(colour = "black",size = 0.5))+
          xlim(c(min(overall$From)-leftFlanking, max(overall$To)+rightFlanking)) + ylim(c(-0.1, 0.1*nrow(overall.temp4) + 0.1)) +
          geom_segment(data = gff.temp, 
                       mapping = aes(x = Start, xend = End, y = -0.1, yend = -0.1, color = Fragment.Name), 
                       size = 4) + 
          geom_segment(data = overall.temp4,
                       mapping = aes(x = From, xend = To, y = order, yend = order),
                       size = 0.2, color = Fcolor)
          
        p = p + theme(plot.margin=unit(rep(2,4),'lines'))
        pdf(paste0(dir.path, "/", "Designed.primers/Cloning.primers/", fileName[i], "_", overall$Chr[1], "_", min(overall$From), "..", max(overall$To), ".all.primers.distribution.plot.pdf"), width = 10, height = ifelse(nrow(overall.temp4) <= 2, 3, ifelse(nrow(overall.temp4) > 2 & nrow(overall.temp4) <= 10, 5, ifelse(nrow(overall.temp4) > 10 & nrow(overall.temp4) <= 100, 10, ifelse(nrow(overall.temp4) > 100, 15, 20)))))
        print(p)
        dev.off()
      }
  }
  #cat("\nPrimer.designing.for.cloning is Done!")  
}





